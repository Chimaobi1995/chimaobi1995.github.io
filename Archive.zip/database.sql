-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 22, 2021 at 02:27 PM
-- Server version: 10.3.31-MariaDB-log-cll-lve
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flipejsy_etnb_db123`
--

-- --------------------------------------------------------

--
-- Table structure for table `captcha_text`
--

CREATE TABLE `captcha_text` (
  `cap_id` int(11) NOT NULL,
  `captcha` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `credit_debit_history`
--

CREATE TABLE `credit_debit_history` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL DEFAULT '',
  `amount_transfered` varchar(200) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `type_` varchar(200) NOT NULL DEFAULT '',
  `date_` varchar(200) NOT NULL DEFAULT '',
  `time_` varchar(200) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `id` int(10) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `pass` varchar(200) DEFAULT NULL,
  `salt` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`id`, `email`, `pass`, `salt`) VALUES
(2, 'fund@etnb.online', 'zone1', 'zone1');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `owner` varchar(200) NOT NULL DEFAULT '',
  `date` varchar(200) NOT NULL DEFAULT '',
  `sender` varchar(200) NOT NULL DEFAULT '',
  `subject_` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `isread` varchar(200) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pipul`
--

CREATE TABLE `pipul` (
  `aid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `accountnumber` varchar(20) NOT NULL DEFAULT '',
  `firstname` varchar(100) NOT NULL DEFAULT '',
  `middlename` varchar(100) NOT NULL DEFAULT '',
  `lastname` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(200) NOT NULL DEFAULT '',
  `occupation` varchar(20) NOT NULL DEFAULT '',
  `dob` varchar(20) NOT NULL DEFAULT '',
  `maritalstatus` varchar(20) NOT NULL DEFAULT '',
  `gender` varchar(10) NOT NULL DEFAULT '',
  `address` text DEFAULT NULL,
  `accountype` varchar(50) NOT NULL DEFAULT '',
  `registrationdate` varchar(50) NOT NULL DEFAULT '',
  `totalbalance` varchar(100) NOT NULL DEFAULT '0',
  `accountbalance` varchar(100) NOT NULL DEFAULT '0',
  `currency` varchar(10) NOT NULL DEFAULT '',
  `cotcode` varchar(100) NOT NULL DEFAULT '',
  `taxcode` varchar(100) NOT NULL DEFAULT '',
  `imfcode` varchar(100) NOT NULL DEFAULT '',
  `logincount` int(11) NOT NULL DEFAULT 0,
  `status` varchar(200) NOT NULL DEFAULT 'pending',
  `otp` varchar(10) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticketmessage`
--

CREATE TABLE `ticketmessage` (
  `id` int(11) NOT NULL,
  `ticketid` int(11) NOT NULL,
  `owner` varchar(200) NOT NULL DEFAULT '',
  `from_` varchar(200) NOT NULL DEFAULT '',
  `message` text DEFAULT NULL,
  `date` varchar(30) NOT NULL,
  `read_` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `owner` varchar(300) NOT NULL DEFAULT '',
  `subject` varchar(200) DEFAULT NULL,
  `message` text NOT NULL,
  `status` varchar(20) DEFAULT 'open',
  `date` varchar(30) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `sender` varchar(200) NOT NULL DEFAULT '',
  `amount` varchar(200) NOT NULL DEFAULT '',
  `sent_to_number` varchar(200) NOT NULL DEFAULT '',
  `sent_to_bank` varchar(200) NOT NULL DEFAULT '',
  `sent_to_name` varchar(200) NOT NULL DEFAULT '',
  `remarks` text DEFAULT NULL,
  `date` varchar(200) NOT NULL DEFAULT '',
  `time` varchar(20) NOT NULL DEFAULT '',
  `type_` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `captcha_text`
--
ALTER TABLE `captcha_text`
  ADD PRIMARY KEY (`cap_id`);

--
-- Indexes for table `credit_debit_history`
--
ALTER TABLE `credit_debit_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pipul`
--
ALTER TABLE `pipul`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `ticketmessage`
--
ALTER TABLE `ticketmessage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `captcha_text`
--
ALTER TABLE `captcha_text`
  MODIFY `cap_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `credit_debit_history`
--
ALTER TABLE `credit_debit_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pipul`
--
ALTER TABLE `pipul`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticketmessage`
--
ALTER TABLE `ticketmessage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
