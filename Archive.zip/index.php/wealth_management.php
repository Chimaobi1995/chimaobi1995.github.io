<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/wealth_management. Date: Mon, 14 Sep 2020 23:37:44 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="content" description="<?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants">
<title><?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants</title>

<link rel="apple-touch-icon" sizes="57x57" href="../assets/landing/images/fav-icon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/landing/images/fav-icon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/landing/images/fav-icon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/landing/images/fav-icon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/landing/images/fav-icon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/landing/images/fav-icon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/landing/images/fav-icon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/landing/images/fav-icon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/landing/images/fav-icon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/../assets/landing/images/fav-iconandroid-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/landing/images/fav-icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/landing/images/fav-icon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/landing/images/fav-icon/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/landing/images/fav-icon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/bootstrap/bootstrap.css" media="screen">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Alegreya:400,400italic,700,900,700italic,900italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="../assets/landing/fonts/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/fonts/flat-icon/flaticon.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/settings.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/layers.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/navigation.css">

<link rel="stylesheet" href="../assets/landing/css/owl.carousel.css">
<link rel="stylesheet" href="../assets/landing/css/owl.theme.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/jquery-css/jquery-ui.css">


<link rel="stylesheet" type="text/css" href="../assets/landing/css/custom/style.css">

<link type="text/css" rel="stylesheet" id="jssDefault" href="../assets/landing/css/custom/theme-2.css" />

<link rel="stylesheet" type="text/css" href="../assets/landing/css/responsive/responsive.css">
<link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/font-awesome.css">
</head>
<body class="home layout_changer">
<!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

<div class="body_wrapper">

<div id="loader-wrapper">
<div id="loader"></div>
</div>

<?php include "topmenu.php"; ?>
<?php include "main_menu.php"; ?>

<section class="inner_banner">
<div class="container">
<div class="banner-title">
<h1>Investment Planning</h1>
<span class="decor-equal"></span>
</div>
</div>
</section>


<section class="breadcrumb_sec breadcrumb_fix">
<div class="container">
<div class="row">
<div class="col-lg-8 col-md-6 col-sm-6 col-xs-3">
<h5>Services</h5>
</div>
<div class="col-lg-4 col-md-6 col-sm-6 col-xs-9" style="text-align:right;">
<ul>
<li><a href="index">Home</a></li>
<li class="dot"></li>
<li><a href="services">Services</a></li>
<li class="dot"></li>
<li>Wealth Management</li>
</ul>
</div>
</div>
</div>
</section>


<section class="service_single_page_content">
<div class="container">
<div class="row">
<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
<div class="tab_nav_holder">

<ul class="nav nav-tabs tabs-left">
<li><a href="wealth_management.html#investment" data-toggle="tab">Investment Planning<i class="fa fa-angle-right"></i></a></li>
<li><a href="wealth_management.html#childrens" data-toggle="tab">Childrens Planning <i class="fa fa-angle-right"></i></a></li>
<li><a href="wealth_management.html#retirement" data-toggle="tab">Retirement Planning <i class="fa fa-angle-right"></i></a></li>
<li><a href="wealth_management.html#insurance" data-toggle="tab">Insurance Planning <i class="fa fa-angle-right"></i></a></li>
<li><a href="wealth_management.html#tax" data-toggle="tab">Tax Planning <i class="fa fa-angle-right"></i></a></li>
<li><a href="wealth_management.html#commodities" data-toggle="tab">Commodities Trading <i class="fa fa-angle-right"></i></a></li>
<li><a href="wealth_management.html#mutual" data-toggle="tab">Mutual Funds <i class="fa fa-angle-right"></i></a></li>
<li class="active"><a href="wealth_management.html#wealth" data-toggle="tab">Wealth Management <i class="fa fa-angle-right"></i></a></li>
</ul>
</div>
</div>
<div class="col-lg-9 col-md-8 col-sm-6 col-xs-12">
<div class="tab_details">

<div class="tab-content">
<div class="tab-pane row" id="investment">
<img class="img-responsive col-lg-8 col-md-7 col-sm-12 col-xs-12" src="../assets/landing/images/services/4.jpg" alt="image">
<div class="slider_container col-lg-4 col-md-5 col-sm-12 col-xs-12">
<div id="services-single-slider" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#services-single-slider" data-slide-to="0" class="active"></li>
<li data-target="#services-single-slider" data-slide-to="1"></li>
<li data-target="#services-single-slider" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span>We Have Essential Plans For Your Future Investment.</span>
<a href="wealth_management.html#">1. Investment Planning</a>
<p>Secure your future now, let us work with you to guarantee you a secured and stress free future.</p>
</div>
<div class="item">
<span>Consult the Experts.</span>
<a href="wealth_management.html#">2. Secured Planning</a>
<p>Let pur Experts advice you on your happiness.</p>
</div>
</div> 
</div> 
</div> 
<div class="title_container clear_fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4>About Investment Planning</h4>
<span class="decor_default"></span>
</div>
<div class="text col-lg-12 col-md-12 col-sm-12 col-xs-12">
<p>We Offer Investment Planning.
A systematic investment plan (SIP) is a plan where investors make regular, equal payments into a mutual fund, trading account or retirement account, such as a 401(k), and benefit from the long-term advantages of dollar-cost averaging (DCA) and the convenience of saving regularly without taking any actions except the initial setup of the SIP. Because dollar-cost averaging involves buying a fixed-dollar amount of a security regardless of its price, shares are bought at various prices, the average cost per share of the security decreases over time and the risk of investing a large amount of money into a security lessens.</p>
</div>
</div>
<div class="tab-pane fade row" id="childrens">
<img class="img-responsive col-lg-8 col-md-7 col-sm-12 col-xs-12" src="../assets/landing/images/services/1.jpg" alt="image">
<div class="slider_container col-lg-4 col-md-5 col-sm-12 col-xs-12">
<div id="services-single-slider2" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#services-single-slider2" data-slide-to="0" class="active"></li>
<li data-target="#services-single-slider2" data-slide-to="1"></li>
<li data-target="#services-single-slider2" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span>We Have Essential Plans For Childrens Future.</span>
<a href="wealth_management.html#">1. Educational Plan</a>
<p>Give your children/wards the best by providing a secured valuable education for them.</p>
</div>
</div> 
</div> 
</div> 
<div class="title_container clear_fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4>About Childrens Planning</h4>
<span class="decor_default"></span>
</div>
<div class="text col-lg-12 col-md-12 col-sm-12 col-xs-12">
<p>Involving your children in your family's financial planning process is important because everyone involved benefits from the experience, including your financial planner. We've always encouraged people with children to engage their children in learning about finances, We got you and your kids covered.</p>
</div>
</div>
<div class="tab-pane fade row" id="retirement">
<img class="img-responsive col-lg-8 col-md-7 col-sm-12 col-xs-12" src="../assets/landing/images/services/6.jpg" alt="image">
<div class="slider_container col-lg-4 col-md-5 col-sm-12 col-xs-12">
<div id="services-single-slider3" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#services-single-slider3" data-slide-to="0" class="active"></li>
<li data-target="#services-single-slider3" data-slide-to="1"></li>
<li data-target="#services-single-slider3" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span>We Have Essential Plans For Retirement Planning.</span>
<a href="wealth_management.html#">1. Retirement Planning</a>
<p>Plan your Retirement now.</p>
</div>
<div class="item">
<span>We Have Essential Plans For Retirement Planning.</span>
<a href="wealth_management.html#">2. Retirement Planning</a>
<p>Live better after Retirement.</p>
</div>
</div> 
</div> 
</div> 
<div class="title_container clear_fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4>About Retirement Planning</h4>
<span class="decor_default"></span>
</div>
<div class="text col-lg-12 col-md-12 col-sm-12 col-xs-12">
<p>Retirement planning is the process of determining retirement income goals and the actions and decisions necessary to achieve those goals. Retirement planning includes identifying sources of income, estimating expenses, implementing a savings program and managing assets. Future cash flows are estimated to determine if the retirement income goal will be achieved.</p>
</div>
</div>
<div class="tab-pane fade row" id="insurance">
<img class="img-responsive col-lg-8 col-md-7 col-sm-12 col-xs-12" src="../assets/landing/images/services/3.jpg" alt="image">
<div class="slider_container col-lg-4 col-md-5 col-sm-12 col-xs-12">
<div id="services-single-slider4" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#services-single-slider4" data-slide-to="0" class="active"></li>
<li data-target="#services-single-slider4" data-slide-to="1"></li>
<li data-target="#services-single-slider4" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span>We Have Essential Plans For Insurance Planning.</span>
<a href="wealth_management.html#">1. Insurance Planning</a>
<p>Get Covered.</p>
</div>
</div> 
</div> 
</div> 
<div class="title_container clear_fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4>About Insurance Planning</h4>
<span class="decor_default"></span>
</div>
<div class="text col-lg-12 col-md-12 col-sm-12 col-xs-12">
<p>Health insurance is a type of insurance coverage that pays for medical and surgical expenses incurred by the insured. Health insurance can reimburse the insured for expenses incurred from illness or injury, or pay the care provider directly. It is often included in employer benefit packages as a means of enticing quality employees. The cost of health insurance premiums is deductible to the payer, and benefits received are tax-free.</p>
</div>
</div>
<div class="tab-pane fade row" id="tax">
<img class="img-responsive col-lg-8 col-md-7 col-sm-12 col-xs-12" src="../assets/landing/images/services/7.jpg" alt="image">
<div class="slider_container col-lg-4 col-md-5 col-sm-12 col-xs-12">
<div id="services-single-slider5" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#services-single-slider5" data-slide-to="0" class="active"></li>
<li data-target="#services-single-slider5" data-slide-to="1"></li>
<li data-target="#services-single-slider5" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span>We Have Essential Plans For Tax Planning.</span>
<a href="wealth_management.html#">1. Tax Planning</a>
<p>Let us handle your tax plans and issues.</p>
</div>
</div> 
</div> 
</div> 
<div class="title_container clear_fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4>About Tax Planning</h4>
<span class="decor_default"></span>
</div>
<div class="text col-lg-12 col-md-12 col-sm-12 col-xs-12">
<p>Tax planning is the analysis of a financial situation, or plan, from a tax perspective. The purpose of tax planning is to ensure tax efficiency. Through tax planning, all elements of the financial plan work together in the most tax-efficient manner possible. Tax planning is an essential part of a financial plan. Reduction of tax liability and maximizing the ability to contribute to retirement plans are crucial for success.</p>
</div>
</div>
<div class="tab-pane fade row" id="commodities">
<img class="img-responsive col-lg-8 col-md-7 col-sm-12 col-xs-12" src="../assets/landing/images/services/2.jpg" alt="image">
<div class="slider_container col-lg-4 col-md-5 col-sm-12 col-xs-12">
<div id="services-single-slider6" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#services-single-slider6" data-slide-to="0" class="active"></li>
<li data-target="#services-single-slider6" data-slide-to="1"></li>
<li data-target="#services-single-slider6" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span>We Have Essential Plans For Commodities Trading.</span>
<a href="wealth_management.html#">1. Commodities Trading</a>
<p>Value Commodity Trading.</p>
</div>
</div> 
</div> 
</div> 
<div class="title_container clear_fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4>About Commodities Trading</h4>
<span class="decor_default"></span>
</div>
<div class="text col-lg-12 col-md-12 col-sm-12 col-xs-12">
<p>A commodity is a basic good used in commerce that is interchangeable with other commodities of the same type. Commodities are most often used as inputs in the production of other goods or services. The quality of a given commodity may differ slightly, but it is essentially uniform across producers. When they are traded on an exchange, commodities must also meet specified minimum standards, also known as a basis grade.
The basic idea is that there is little differentiation between a commodity coming from one producer and the same commodity from another producer. A barrel of oil is basically the same product, regardless of the producer. By contrast, for electronics merchandise, the quality and features of a given product may be completely different depending on the producer. Some traditional examples of commodities include grains, gold, beef, oil and natural gas. More recently, the definition has expanded to include financial products, such as foreign currencies and indexes. Technological advances have also led to new types of commodities being exchanged in the marketplace. For example, cell phone minutes and bandwidth.
Commodities Buyers and Producers
The sale and purchase of commodities are usually carried out through futures contracts on exchanges that standardize the quantity and minimum quality of the commodity being traded. For example, the Chicago Board of Trade stipulates that one wheat contract is for 5,000 bushels and also states what grades of wheat can be used to satisfy the contract.
There are two types of traders that trade commodity futures. The first are buyers and producers of commodities that use commodity futures contracts for the hedging purposes for which they were originally intended. Theses traders actually make or take delivery of the actual commodity when the futures contract expires. For example, the wheat farmer that plants a crop can hedge against the risk of losing money if the price of wheat falls before the crop is harvested. The farmer can sell wheat futures contracts when the crop is planted and guarantee a predetermined price for the wheat at the time it is harvested.</p>
</div>
</div>
<div class="tab-pane fade row" id="mutual">
<img class="img-responsive col-lg-8 col-md-7 col-sm-12 col-xs-12" src="../assets/landing/images/services/5.jpg" alt="image">
<div class="slider_container col-lg-4 col-md-5 col-sm-12 col-xs-12">
<div id="services-single-slider7" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#services-single-slider7" data-slide-to="0" class="active"></li>
<li data-target="#services-single-slider7" data-slide-to="1"></li>
<li data-target="#services-single-slider7" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span>We Have Essential Plans For Mutual Funds.</span>
<a href="wealth_management.html#">1. Mutual Funds</a>
<p>Mutual Bonds and Funding has never been easier.</p>
</div>
</div> 
</div> 
</div> 
<div class="title_container clear_fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4>About Mutual Funds</h4>
<span class="decor_default"></span>
</div>
<div class="text col-lg-12 col-md-12 col-sm-12 col-xs-12">
<p>A mutual fund is at its core a managed portfolio of stocks and/or bonds. You can think of a mutual fund as a company that brings together a large group of people and invests their money on their behalf in this portfolio. Each investor owns shares of the mutual fund, which represent a portion of its holdings.
Investing in a share of a mutual fund is different from investing in shares of stock. Unlike stock, mutual fund shares do not give its holders any voting rights. A share of a mutual fund represents investments in many different stocks (or other securities) instead of just one holding.
Investors typically earn a return from a mutual fund in three ways:
1. Income is earned from dividends on stocks and interest on bonds held in the fund’s portfolio. A fund pays out nearly all of the income it receives over the year to fund owners in the form of a distribution. Funds often give investors a choice either to receive a check for distributions or to reinvest the earnings and get more shares
2. If the fund sells securities that have increased in price, the fund has a capital gain. Most funds also pass on these gains to investors in a distribution.
3. If fund holdings increase in price but are not sold by the fund manager, the fund's shares increase in price. You can then sell your mutual fund shares for a profit in the market.
Mutual funds have some clear advantages for investors, but also some limitations and drawbacks. Here is an overview of the pros and cons:</p>
</div>
</div>
<div class="tab-pane active row" id="wealth">
<img class="img-responsive col-lg-8 col-md-7 col-sm-12 col-xs-12" src="../assets/landing/images/services/8.jpg" alt="image">
<div class="slider_container col-lg-4 col-md-5 col-sm-12 col-xs-12">
<div id="services-single-slider8" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#services-single-slider8" data-slide-to="0" class="active"></li>
<li data-target="#services-single-slider8" data-slide-to="1"></li>
<li data-target="#services-single-slider8" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span>We Have Essential Plans For Wealth Management.</span>
<a href="wealth_management.html#">1. Wealth Management</a>
<p>Long Lasting Wealth with risk free investments.</p>
</div>
</div> 
</div> 
</div> 
<div class="title_container clear_fix col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h4>About Wealth Management</h4>
<span class="decor_default"></span>
</div>
<div class="text col-lg-12 col-md-12 col-sm-12 col-xs-12">
<p>Wealth management is a high-level professional service that combines financial and investment advice, accounting and tax services, retirement planning and legal or estate planning for one set fee. Clients work with a single wealth manager who coordinates input from financial experts and can include coordinating advice from the client's own attorney, accountants, and insurance agent. Some wealth managers also provide banking services or advice on philanthropic activities.
Wealth management is more than just investment advice, as it can encompass all parts of a person's financial life. The idea is that rather than trying to integrate pieces of advice and various products from a series of professionals, high net worth individuals benefit from a holistic approach in which a single manager coordinates all the services needed to manage their money and plan for their own or their family's current and future needs.
While the use of a wealth manager is based on the theory that they can provide services in any aspect of the financial field, some choose to specialize in particular areas. This may be based on the expertise of the wealth manager in question, or the primary focus of the business within which the wealth manager operates.
Wealth Management Example
For example, those in the direct employ of a firm known for investments may have more knowledge in the area of market strategy, while those working in the employ of a large bank may focus on areas such as the management of trusts and available credit options, overall estate planning or insurance options. The position is considered consultative in nature as the primary focus is providing needed guidance to those using the wealth management service.
Wealth Management Business Structures
Wealth managers may work as part of a small-scale business or as part of a larger firm, one generally associated with the finance industry. Depending on the business, wealth managers may function under different titles including financial consultant or financial advisor. A client may receive services from a single designated wealth manager or may have access to members of a specified wealth management team.</p>
</div>
</div>
</div>
</div> 
</div>
</div> 
<div class="row">
<?php include "modalpart.php"; ?>
<div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 pull-right brochures">
<div class="title_container">
<h4>Our Brochures</h4>
<span class="decor_default"></span>
</div>
<a href="contact" class="pdf_download transition3s">
Support
<span class="transition3s"><i class="fa fa-user"></i></span>
</a>
<a href="contact" class="doc_download transition3s">
Inquiries
<span class="transition3s"><i class="fa fa-file-text-o"></i></span>
</a>
</div>
</div>
</div> 
</section> 


<?php include "footer.php"; ?>



<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="../assets/landing/js/jquery-2.1.4.js"></script>
<script src="../assets/landing/ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript" src="../assets/landing/js/bootstrap.min.js"></script>


<script type="text/javascript" src="../assets/landing/js/jQuery.style.switcher.min.js"></script>

<script src="../assets/landing/js/jquery.themepunch.tools.min.js"></script>
<script src="../assets/landing/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.navigation.min.js"></script>

<script src="../assets/landing/js/owl.carousel.min.js"></script>

<script src="../assets/landing/js/jquery.appear.js"></script>

<script type="text/javascript" src="../assets/landing/js/jquery-ui.min.js"></script>

<script src="../assets/landing/js/jquery.countTo.js"></script>
<script src="../assets/landing/js/validate.js"></script>
<script type="text/javascript" src="../assets/landing/js/main.js"></script>
</div> 
</body>

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/wealth_management. Date: Mon, 14 Sep 2020 23:37:44 GMT -->
</html>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5de1747543b1d1fce83/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
