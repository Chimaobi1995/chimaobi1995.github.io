<?php
$title = "ETNB";
$myphone = "+1 (856) 512-0567";
$myaddress = "393 Springfield Ave Summit, Nj 07901";
$myemail = "support@etnb.online";

