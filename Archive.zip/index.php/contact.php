<?php
session_start();
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/contact. Date: Mon, 14 Sep 2020 23:38:07 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="content" description="<?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants">
<title><?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants</title>

<link rel="apple-touch-icon" sizes="57x57" href="../assets/landing/images/fav-icon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/landing/images/fav-icon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/landing/images/fav-icon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/landing/images/fav-icon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/landing/images/fav-icon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/landing/images/fav-icon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/landing/images/fav-icon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/landing/images/fav-icon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/landing/images/fav-icon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="../assets/landing/images/fav-icon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/landing/images/fav-icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/landing/images/fav-icon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/landing/images/fav-icon/favicon-16x16.png">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/bootstrap/bootstrap.css" media="screen">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Alegreya:400,400italic,700,900,700italic,900italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="../assets/landing/fonts/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/fonts/flat-icon/flaticon.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/settings.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/layers.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/navigation.css">

<link rel="stylesheet" href="../assets/landing/css/owl.carousel.css">
<link rel="stylesheet" href="../assets/landing/css/owl.theme.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/jquery-css/jquery-ui.css">


<link rel="stylesheet" type="text/css" href="../assets/landing/css/custom/style.css">

<link type="text/css" rel="stylesheet" id="jssDefault" href="../assets/landing/css/custom/theme-2.css" />

<link rel="stylesheet" type="text/css" href="../assets/landing/css/responsive/responsive.css">
<link rel='stylesheet' id='financepress_custom-style-css' href="../assets/landing/wp-content/themes/finance_press/css/custom4e7f4e7f.css" type='text/css' media='all' />
<link rel='stylesheet' id='carshire-theme-slug-fonts-css' href='https://fonts.googleapis.com/css?family=Alegreya%3A400%2C400italic%2C700%2C900%2C700italic%2C900italic%7CMontserrat%3A400%2C700%7COpen+Sans%3A400%2C300%2C300italic%2C400italic%2C600%2C600italic%2C700%2C700italic&amp;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css' href="../assets/landing/wp-content/plugins/js_composer/assets/css/js_composer.mina752a752.css" type='text/css' media='all' />
<script type='text/javascript' src="../assets/landing/wp-includes/js/jquery/jqueryb8ffb8ff.js"></script>
<script type='text/javascript' src="../assets/landing/wp-includes/js/jquery/jquery-migrate.min330a330a.js"></script>
<link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/font-awesome.css">
</head>
<body class="home layout_changer">
<!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->


<?php include "topmenu.php"; ?>

<?php include "main_menu.php"; ?>

<div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column col-md-12">
<section class="contact_container">
<div class="container">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 contact_text">
<div class="title_container">
<h4>Warm Welcome to FinancePress Customer Support Team.</h4>
<img src="../assets/landing/wp-content/themes/finance_press/images/home/decor-title.png" alt="image" style="padding-top:10px;">
</div>
<p></p>
<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution.</p>
<p>You can intaract with our customer support team in toll free number <?php echo $myphone; ?> they will help you 24/7. and also mail with "</span><?php echo $myemail; ?></a></li>
<p></p>
<div class="contact_num" style="background-image: url('wp-content/themes/finance_pressimages/contact/1.html)%20no-repeat%20right%20top');">
<img src="../assets/landing/wp-content/uploads/2016/06/2-1.jpg" alt="image">
<p>Please Make a Call For Sales Enquiries <span><?php echo $myphone; ?></span></p>
</div> 
<div class="meet_office">
<h4>Meet Us In Our Office:</h4>
<div class="address contact_information">
<h5>Address :</h5>
<p><?php echo $myaddress; ?></p>
</div> 
<div class="mail contact_information">
<h5>Mail Us</h5>
<a href="../cdn-cgi/l/email-protection.html#c0b3b5b0b0afb2b480b3b4a1aea4a1b2a4a6a9aea1aea3a5a3afb2b0eea3afad"></span><?php echo $myemail; ?></a></li>
</div> 
<div class="clear_fix"></div>
</div> 
</div> 
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 lets_talk_to_us">
<div role="form" class="wpcf7" id="wpcf7-f168-p164-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="send_contact.php" method="post" class="wpcf7-form" novalidate="novalidate">

<div class="title_container">
<h4>Let’s Talk To Us</h4>
<p> <img src="../assets/landing/wp-content/themes/finance_press/images/home/decor-title.png" alt="image">
</div>
<?php if(isset($_SESSION['msg'])){ echo $_SESSION['msg']; unset($_SESSION['msg']); } ?>
<label>Your Name (Required)</label></p>
<div class="input-group">
<span class="wpcf7-form-control-wrap text-481">
<input type="text" name="yourname" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control" aria-required="true" aria-invalid="false" /></span><span class="input-group-addon" id="basic-addon2"><i class="fa fa-user"></i></span>
</div>

<label>Your Phone (Required)</label></p>
<div class="input-group">
<span class="wpcf7-form-control-wrap text-481">
<input type="text" name="yourphone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control" aria-required="true" aria-invalid="false" /></span><span class="input-group-addon" id="basic-addon2"><i class="fa fa-phone"></i></span>
</div>


<p> <label>Email (Required)</label></p>
<div class="input-group">
<span class="wpcf7-form-control-wrap email-63"><input type="email" name="youremail" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email form-control" aria-required="true" aria-invalid="false" /></span><span class="input-group-addon" id="basic-addon3"><i class="fa fa-envelope"></i></span>
</div>
<p> <label>How Can We Help You?</label></p>
<div class="dropdown">
</p>
<select class="form-control" aria-labelledby="dropdownMenu2" name="enquiryType">
<option value="">Select</option>
<option>Commodities Enquiries</option>
<option>Account On Hold</option>
<option>Account Disabled</option>
<option>Account Suspend</option>
<option>Account Dormant/Inactive</option>
<option>Commodities Enquiries</option>
<option>Commodities Help</option>
</select>

</div>
<p> <br />
<label>Tell Us More</label></p>
<div class="input-group input_group_textarea">
<span class="wpcf7-form-control-wrap textarea-586"><textarea placeholder="Please Send all Inquiries" name="message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span><span class="input-group-addon" id="basic-addon4"><i class="fa fa-comments"></i></span>
</div>
<p> <input type="submit" value="Submit Now" class="wpcf7-form-control wpcf7-submit button-main submit_now" />
</p>
<p> </p>
<div class="wpcf7-response-output wpcf7-display-none"></div>
</form>
</div>
</div>
</div> 
</div> 
</section> 
</div>
</div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column col-md-12">

<div class="map">

</div>

</div>
</div><p></p>

<?php include "footer.php"; ?>


<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="../assets/landing/js/jquery-2.1.4.js"></script>
<script src="../assets/landing/ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript" src="../assets/landing/js/bootstrap.min.js"></script>


<script type="text/javascript" src="../assets/landing/js/jQuery.style.switcher.min.js"></script>

<script src="../assets/landing/js/jquery.themepunch.tools.min.js"></script>
<script src="../assets/landing/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.navigation.min.js"></script>

<script src="../assets/landing/js/owl.carousel.min.js"></script>

<script src="../assets/landing/js/jquery.appear.js"></script>

<script type="text/javascript" src="../assets/landing/js/jquery-ui.min.js"></script>

<script src="../assets/landing/js/jquery.countTo.js"></script>
<script src="../assets/landing/js/validate.js"></script>
<script type="text/javascript" src="../assets/landing/js/main.js"></script>
</div> 
</body>

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/contact. Date: Mon, 14 Sep 2020 23:38:17 GMT -->
</html>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5de1747543b1d1fce83/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
