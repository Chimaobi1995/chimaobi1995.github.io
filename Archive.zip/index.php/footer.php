<footer>
<div class="container">
<div class="main_footer">
<div class="row">
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 footer_logo">
<a href="index" class="logo"><img src="../logo-w.png" style="width:150px"/></a>
<p><?php echo $title; ?> financial Solution is the trading name of Brent Shrine Credit Union Ltd. Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority. Reference number 213146. Member of Association of British Credit Unions Limited.</p>
<a href="about_us" class="button-main hvr-sweep-to-rightB read_more transition3s">Read more</a>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 useful_links">
<div class="footer_widget_title">
<h4>Useful Links</h4>
<span class="decor_white"></span>
</div>
<div class="links">
<div class="row">
<ul class="col-lg-5 col-md-6 col-sm-6 col-xs-6">
<li><a href="index">-&nbsp; Home</a></li>
<li><a href="about_us">-&nbsp; About Us</a></li>
<li><a href="tax_planning">-&nbsp;Tax Planning</a></li>

<li><a href="about_us">-&nbsp; careers</a></li>

</ul>
<ul class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
<li><a href="financial_plannning">-&nbsp; Financial Planning</a></li>
<li><a href="auth/">-&nbsp; Private Banking</a></li>
<li><a href="commodities_planning">-&nbsp; Commodities</a></li>
<li><a href="retirement_planning">-&nbsp; Stock Holders</a></li>
<li><a href="mutual_funds">-&nbsp; Mutual Fund</a></li>
<li><a href="wealth_management">-&nbsp; Stock Trading</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 subscribe_us">
<div class="footer_widget_title">
<h4>Subscribe Us</h4>
<span class="decor_white"></span>
</div>
<p>Sign up for our mailing list to get latest updates and offers.</p>
<form action="index.html#">
<input type="email" placeholder="Email address">
<button type="submit" class="hvr-sweep-to-right-white transition3s">Go</button>
</form>
<span class="confidential_mail">Your mail id is Confidential</span>
<ul class="media_icon">
<li><a href="https://facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
<li><a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a></li>
<li><a href="https://vimeo.com/" target="_blank"><i class="fa fa-vimeo"></i></a></li>
<li><a href="https://plus.google.com/" target="_blank"><i class="fa fa-google-plus"></i></a></li>
<li><a href="https://linkedin.com/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
</ul>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 contact_us">
<div class="footer_widget_title">
<h4>Contact Us</h4>
<span class="decor_white"></span>
</div>
<ul>
<li><span>Address :</span><?php echo $myaddress; ?> </li>
<li><span>Mail Us </span><?php echo $myemail; ?></a></li>
<li><span>Any Enquiries</span><a href="tel:<?php echo $myphone; ?>" class="transition3s"><?php echo $myphone; ?></a></li>
</ul>
</div>
</div>
</div> 
<div class="bottom_footer">
<div class="row">
<div class="col-lg-8 col-md-6 col-sm-12 col-xs-12">
<p>Copyrights &copy; <?php echo date("Y"); ?> || All Rights Reserved by <?php echo $title; ?> financial Solution </p>
</div>	
<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 left_space_fix">
<a href="terms" class="transition3s">Terms Of Use</a>
<a href="privacy-policy" class="transition3s">Privacy & Security Statement</a>
</div>
</div>
</div> 
</div>
</footer>
