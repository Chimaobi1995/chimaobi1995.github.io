<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/privacy-policy. Date: Mon, 14 Sep 2020 23:40:01 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="content" description="<?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants">
<title><?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants</title>

<link rel="apple-touch-icon" sizes="57x57" href="../assets/landing/images/fav-icon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/landing/images/fav-icon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/landing/images/fav-icon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/landing/images/fav-icon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/landing/images/fav-icon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/landing/images/fav-icon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/landing/images/fav-icon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/landing/images/fav-icon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/landing/images/fav-icon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/../assets/landing/images/fav-iconandroid-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/landing/images/fav-icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/landing/images/fav-icon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/landing/images/fav-icon/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/landing/images/fav-icon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/bootstrap/bootstrap.css" media="screen">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Alegreya:400,400italic,700,900,700italic,900italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="../assets/landing/fonts/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/fonts/flat-icon/flaticon.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/settings.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/layers.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/navigation.css">

<link rel="stylesheet" href="../assets/landing/css/owl.carousel.css">
<link rel="stylesheet" href="../assets/landing/css/owl.theme.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/jquery-css/jquery-ui.css">


<link rel="stylesheet" type="text/css" href="../assets/landing/css/custom/style.css">

<link type="text/css" rel="stylesheet" id="jssDefault" href="../assets/landing/css/custom/theme-2.css" />

<link rel="stylesheet" type="text/css" href="../assets/landing/css/responsive/responsive.css">
<link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/font-awesome.css">
</head>
<body class="home layout_changer">
<!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

<div class="body_wrapper">

<div id="loader-wrapper">
<div id="loader"></div>
</div>
<?php include "topmenu.php"; ?>
<?php include "main_menu.php"; ?>

<section class="inner_banner">
<div class="container">
<div class="banner-title">
<h1>PRIVACY POLICY</h1>
<span class="decor-equal"></span>
</div>
</div>
</section>


<section class="breadcrumb_sec">
<div class="container">
<div class="row">
<div class="col-lg-8 col-md-6 col-sm-6 col-xs-3">
<h5>Policy</h5>
</div>
<div class="col-lg-4 col-md-6 col-sm-6 col-xs-9" style="text-align:right;">
<ul>
<li><a href="index">Home</a></li>
<li class="dot"></li>
<li>Policy</li>
</ul>
</div>
</div>
</div>
</section>


<div class="news_content_container">
<div class="container">
<div class="row">
<article class="col-lg-9 col-md-8 col-sm-12 col-xs-12 news_post">
<h1>Our Online Privacy Code</h1>
<h1>Effective Date: April 6, 2018</h1>
<p>Your privacy is important to us and we value your trust. This Online Privacy Code (this “Code”) describes the online privacy practices of <?php echo $title; ?> financial Solution, N.A. (“<?php echo $title; ?> financial Solution,” “we” or “us”) and our affiliate, KB Ameritrade, applicable to consumers who visit, use or interact with our online services.</p>
<p><strong>Our “online services” include</strong><br />
<?php echo $title; ?> financial Solution-branded websites, mobile applications (“mobile apps,” including those for use on tablets), electronic communications (such as email messages) with you, and digital advertising campaigns.<br />
This Code explains the following:</p>
<p>How we or KB Ameritrade, directly or through service providers (including advertising partners), may collect information:<br />
When you visit, use or interact with us through any of our online services; and<br />
Through our advertisements (“ads”) displayed via online services operated by us or third parties; and<br />
How we, directly or through our service providers (including our advertising partners) may use or share information collected via our online services, and associate this information with other information about you.<br />
Consent: By visiting or using any of our online services, responding to any electronic communications we may send you, or clicking on one of our ads, you agree to this Code.</p>
<p>Check the Effective Date: This Code may be revised from time to time, so we encourage you to periodically check the current version available. If we revise this Code in a material way, we will change the “Effective” date shown at the top of this page and provide a conspicuous notice on our website before any changes take effect.</p>
<p>Important – Customers: If you have a financial product or service with us, we will use and share your personal information in accordance with the privacy notice that applies to your account. However, this Code may still be useful to you in describing our online services, and the options and choices described below are available to you as well.</p>
<p><strong>What information do we collect?</strong><br />
We may collect personal information from you through our online services, directly or through our service providers. For example, you may provide us with your name, mailing address, phone number, email address, account number, date of birth and Social Security number (SSN) when you fill out an online form or survey, register, log into or update your account through our online services, register for a marketing offer or input financial or other information into one of our mobile apps.</p>
<p>When you obtain one of our products or services online, or register for or use one of our online services, we may ask you to provide information about a previous financial transaction with another company (e.g., the amount of your monthly payment to a third party), and use that information to verify your identity (using information obtained from a third party information service).</p>
<p>When you visit or use any of our websites or mobile apps, view any of our electronic communications, or interact with one of our targeted ads, we may collect information from your computer(s) and your smartphone(s), tablet(s) or other mobile device(s) (together referred to as “mobile devices”). This information includes:</p>
<p>The make and model of the computer(s) or mobile device(s) you use to visit, use, view or interact with our online services, browser version, hardware and operating system;<br />
Your mobile phone number, mobile country code, unique device identifier, mobile advertising identifier (assigned by your mobile platform), information about the screen size of your mobile device(s), the date and time of device use, and other mobile device-related information;<br />
Your Internet Protocol (IP) address and related information, such as your internet service provider and general location and MAC address;<br />
The precise location of your mobile device(s), if enabled on your device(s) (for example, when you register to receive location-based content, such as the location of the nearest KB store, through our mobile apps);<br />
Photos and contacts stored on your mobile device(s) (when enabled in your mobile device settings);<br />
Your browsing habits on online services provided by us or third parties, such as search terms you entered on our websites, what websites and pages you visit, how long you stay and what actions you take;<br />
Search terms that directed you to our websites and mobile apps, which websites you came from, and which websites you visit right after leaving one of our websites;<br />
Which of our ads or other online content you view, access or click on; and<br />
Any actions you take in response to electronic communications that we send to you, such as opening the message or clicking an embedded link.<br />
Our service providers may also collect information about your browsing habits on online services offered by third parties and use it for the purposes described below.<br />
Third party information:</p>
<p>We may also collect information about you from additional online and offline sources, including our affiliates, credit reporting agencies and other third-party sources as permitted by law.</p>
<p><strong>Association of information:</strong></p>
<p>We may associate the above information from your computer(s) or mobile device(s) through various means, including a unique identifier (such as IP address, customer ID, or visitor ID, unique device identifier and mobile advertising identifier) by using cookies (small data files saved to your browser by websites) and other tracking technologies. When used, these unique identifiers enable us to identify you as our customer, track your activity on our online services and to associate your computer(s) and mobile device(s) with one another, for the purposes described in the following section.<br />
If you are one of our customers, we may associate the above information with your personal <?php echo $title; ?> financial Solution profile (contact information, and information about your holdings, transactions, demographics and location) and use it for the same purposes.<br />
KB Ameritrade:</p>
<p>When you visit, use or interact with us through any of our online services, KB Ameritrade may collect information from your computer(s) and mobile device(s), including information about your browsing habits on our websites.<br />
KB Ameritrade may associate the information that it collects via online services offered by us and itself through various means, to identify you as its customer, track your activity and to associate your computer(s) and mobile device(s) with one another. KB Ameritrade may also associate this information with your KB Ameritrade profile.<br />
For more information about how KB Ameritrade may use, associate or share information collected via our online services, contact KB Ameritrade directly.</p>
<p><strong>How do we use your information?</strong><br />
We may use the information discussed above in a number of ways, to:<br />
Deliver products and services to you, which includes:<br />
Recognizing you when you return to our websites or use our mobile apps (and remembering your login user ID);<br />
Verifying your identity;<br />
Processing applications and transactions;<br />
Using the location of your mobile device(s) for location-based services you request;<br />
Using contacts stored on your mobile device to add new individuals and merchants to our BillPay service through our mobile apps at your direction;<br />
Using photos stored on your mobile device to do the following through our mobile apps at your direction:<br />
Deposit a check;<br />
Pay bills through our BillPay service; and<br />
Autofill information on your driver’s license to open a new account.<br />
Managing your preferences (such as your language preference) and providing a more personalized experience;<br />
Facilitating the operation of our websites and mobile apps; and<br />
Providing you with updates on your accounts, products and services;<br />
Advertise and market our products and services, including:<br />
Posting ads through our or third-party websites or mobile apps that may be of interest to you (See the Online Advertising section below);<br />
Using your IP Address to display available product interest rates for your region or state; and<br />
Contacting you with ads, promotions and offers that may be of interest to you (as permitted by law and consistent with any marketing preferences that we offer and you have registered with us);<br />
Prevent and detect fraud and enhance the security of your account and our online services;<br />
Conduct market research, reporting and development, including to better understand our customers, website visitors and mobile app users, improve our online services, and improve our products and services; and<br />
In other ways as required or permitted by law or with your consent.<br />
Aggregated/anonymized information: We may also aggregate or anonymize information about you (so that it does not identify you individually). This aggregate or anonymized information is not subject to this Code, and we may use it as permitted by law.</p>
<p>KB Ameritrade: KB Ameritrade may use the information that it collects via our online services to advertise or market its products and services to you. For more information about how KB Ameritrade may use, associate or share information collected via our online services, contact KB Ameritrade directly.</p>
<p><strong>How do we share your information?</strong><br />
We may share personal information about you, and information collected from your computer(s) and mobile device(s) or received from third parties for everyday business purposes, including with:<br />
Third parties to deliver products or services to you, such as sharing the location and information about your mobile device(s) with third party mobile apps when you request directions to one of our stores;<br />
Our service providers for purposes such as servicing accounts, conducting transactions, surveys, market research, data analysis, reporting, marketing, development of our products and services, enrichment, and as described in our Online Advertising section below;<br />
Our affiliates (i.e., companies related to us by common ownership or control), including KB Ameritrade, for various purposes permitted by law, including our affiliates’ advertising and marketing of their products and services to you;<br />
Other financial institutions that jointly offer, endorse or sponsor financial products or services with us;<br />
Other individuals or entities, when we believe that disclosure is necessary to detect, prevent or report suspicious activities, prevent physical harm, financial loss, or violations of our agreements and policies;<br />
Our affiliates or third parties in connection with a corporate transaction, such as a sale of our businesses;<br />
Regulators and other organizations or individuals who are legally entitled to receive such information; and<br />
For specific products or services, when you have given your consent.<br />
Aggregated/anonymized information: We may also share aggregated or anonymized information (which does not identify you individually) for various business purposes as permitted by law, for example:</p>
<p>Third parties to help develop, market and deliver products and services that are better tailored to our customers, website visitors and mobile app users; and<br />
Our advertising partners for online advertising purposes.</p>
<p><strong>Online Advertising</strong><br />
We may advertise our products and services and personalize content through online services offered by us, our affiliates and third parties that are not affiliated with us, by using cookies, the mobile advertising identifier of your device and other tracking technologies. Some of our advertising partners may collect data from your mobile device, such as your website and app browsing habits and your mobile advertising identifier, and use it for “online behavioral advertising” (also referred to as “OBA” or “interest-based advertising”). We subscribe to the Self-Regulatory Principles for Online Behavioral Advertising of the Digital Advertising Alliance (DAA), which promotes consumer awareness and choice about how consumers’ information is used for OBA. To learn more about OBA, please visit http://www.aboutads.info/choices.<br />
Our personalized or tailored ads and content may include:</p>
<p><strong>Prescreened offers of credit;</strong><br />
Ads and content based upon your location (e.g., IP address or location of your mobile device), your computer(s) and mobile device(s), your visits to and use of online services offered by us or our affiliates, your customer relationship with us (e.g., contact information, and holdings, transactions, demographics and location) and other information described above;<br />
Ads based upon the above information and your visits to and use of online services offered by non-affiliated third parties, which are referred to as “online behavioral advertising” (“OBA”) or “interest-based advertising;”<br />
Relationship-based ads (e.g., “promoted posts”) on social media, search engine and webmail sites, based upon your contact information in our files; and<br />
Ads on search engine websites based upon search terms that you enter on the search engine websites.<br />
If you click on one of our ads, a cookie, the mobile advertising identifier of your device and other tracking technologies may be used to track the effectiveness of our advertising and to display tailored ads for our products or services.</p>
<p><strong>Opt-Out Options:</strong><br />
We do not respond to “do not track” signals transmitted by web browsers or similar mechanisms. However, several opt-out options are available to you:</p>
<p><strong>Our Opt-Outs:</strong> To opt out of personalized or interest-based content or ads on online services offered by us or third parties based upon your future visits to or use of our online services or your relationship with us, visit our Personalization and Advertising Preferences page.<br />
<strong>OBA Opt-Out:</strong> To opt out of OBA, including targeted ads based upon your behavior on another computer or mobile device, use the following options:<br />
Ads based upon your web browsing habits: Click the AdChoices icon on the ad and follow the instructions, or visit http://www.aboutads.info/choices; and<br />
Ads based upon your app browsing habits: Click the AdChoices icon on the ad and follow the instructions, or change the advertising settings offered by your mobile provider via your mobile device.<br />
Other Opt Outs: Some search engine websites and social media platforms (e.g., Facebook) that display our search-based ads or relationship-based ads offer their own opt-outs. Please visit those sites and platforms for more information.<br />
Opting out through any of these means may not stop advertising from appearing in your browser or apps, but it may make the ads you see less relevant to your interests. If you erase cookies from your browser, use a different browser, or reset the ad identifier on your device, you may need to renew your opt-out choice. In addition, we may still collect data in browsers and apps for other purposes such as market research, reporting and development of our products and services.</p>
<p>We or our advertising partners may use non-cookie technologies to recognize your computer or mobile device and collect and record information about your web surfing activity including your activities on our websites. Please keep in mind that your web browser may not permit you to block the use of these non-cookie technologies, and browser settings that block cookies may have no effect on such technologies.</p>
<p><strong>Security</strong><br />
We maintain appropriate physical, electronic, and administrative safeguards to protect information collected online.</p>
<p><strong>Third-Party Sites and Services</strong><br />
Our online services may contain links to websites and other online services operated by KB Ameritrade or third parties, which are not governed by this Code. We encourage you to learn about the privacy and security practices of KB Ameritrade and third parties. We are not responsible for the privacy or security of websites and other online services operated by KB Ameritrade or third parties, nor the online collection, use, association or sharing of personal or other information by KB Ameritrade or third parties.</p>
<p><strong>Updating Your Information (Customers</strong>)<br />
The accuracy of your account information is important. If you have a financial product or service with <?php echo $title; ?> financial Solution and you find that any personal information we have or have reported to another party does not appear to be accurate, please contact us at <em></em> or <a href="../cdn-cgi/l/email-protection.html" class="__cf_email__" data-cfemail="aedddbdedec1dcdaeedddacfc0cacfdccac8c7c0cfc0cdcbcdc1">[email&#160;protected]</a>rp.com. Please include your account number, if available.</p>
<p><strong>Protecting Children’s Online Privacy</strong><br />
Our online services are not intended for children under 13 years of age. We do not knowingly collect personal information from such children, or send them unsolicited promotions, without parental consent.</p>
<p><strong>Visitors Residing Outside the United States</strong><br />
If you visit, use or interact with our online services, information about you and your computer(s) and mobile device(s) may be collected, stored, used and processed in and transferred to, from and within the United States. In such instances, applicable U.S. federal and state laws shall govern. If you are a non-U.S. resident, such laws may not provide the same level of protection as the laws of the country of your residence.</p>
<p><strong>Contact Us</strong><br />
If you have any questions or comments on our Online Privacy Code, please contact us:</p>
<p><strong><?php echo $title; ?> financial Solution</strong><br />
<strong>Attention:</strong> Chief Privacy Officer<br />
<em></em></p>
</article> 

<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 blog_aside">
<div class="news_categories">
<div class="title_container">
<h4>Quick Links</h4>
<span class="decor_default"></span>
</div>
<ul>
<li><a href="investment_planning"><i class="fa fa-angle-right"></i>Investment Planning</a></li>
<li><a href="wealth_management"><i class="fa fa-angle-right"></i>Wealth Management</a></li>
<li><a href="commodities_trading"><i class="fa fa-angle-right"></i>Commodities</a></li>
<li><a href="mutual_funds"><i class="fa fa-angle-right"></i>Mutual Funds</a></li>
<li><a href="auth/"><i class="fa fa-angle-right"></i>Private Banking</a></li>
</ul>
</div> 
</div> 
</div> 
</div> 
</div>


<?php include "footer.php"; ?>


<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="../assets/landing/js/jquery-2.1.4.js"></script>
<script src="../assets/landing/ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript" src="../assets/landing/js/bootstrap.min.js"></script>


<script type="text/javascript" src="../assets/landing/js/jQuery.style.switcher.min.js"></script>

<script src="../assets/landing/js/jquery.themepunch.tools.min.js"></script>
<script src="../assets/landing/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.navigation.min.js"></script>

<script src="../assets/landing/js/owl.carousel.min.js"></script>

<script src="../assets/landing/js/jquery.appear.js"></script>

<script type="text/javascript" src="../assets/landing/js/jquery-ui.min.js"></script>

<script src="../assets/landing/js/jquery.countTo.js"></script>
<script src="../assets/landing/js/validate.js"></script>
<script type="text/javascript" src="../assets/landing/js/main.js"></script>
</div> 
</body>

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/privacy-policy. Date: Mon, 14 Sep 2020 23:40:01 GMT -->
</html>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5de1747543b1d1fce83/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
