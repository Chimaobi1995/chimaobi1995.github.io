<?php
if(isset($_POST['send'])){

if(empty($_POST['name']) OR empty($_POST['email']) OR empty($_POST['phone']) OR empty($_POST['requesttype']) OR empty($_POST['message'])){
	$msg = "<div class='alert alert-danger'>Please enter all required information</div>";
}else{

		$name = $_POST['name'];	
		$phone = $_POST['phone'];	
		$mail = $_POST['email'];	
		$type = $_POST['requesttype'];	
		$mess = $_POST['message'];	
	
		$to = $myemail;
		$subject = 'Consultation Form';
		$headers = "From: ".$myemail."\r\n";
		$headers .= "Reply-To: ".$mail."\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
		$message = "Inquire form ".$name."<br>
		
		<b>Name:</b> ".$name."<br>
		<b>Phone:</b> ".$phone."<br>
		<b>Email:</b> ".$mail."<br>
		<b>Type:</b> ".$type."<br>
		<b>Message:</b> ".$mess."";
		if(mail($to, $subject, $message, $headers)){
			$msg = "<div class='alert alert-success'>We have Receved Required</div>";
		}else{
			$msg = "<div class='alert alert-danger'>Oosp, unable to send message, check network connction and try again</div>";
		}
		
}

}
?>
<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 pull-right submit_form">
<div class="title_container">
<h4>Request a Free Consultation</h4>
<span class="decor_default"></span>
<?php if(isset($msg)){ echo $msg; unset($msg); } ?>
</div>
<form class="form-inline" role="form" method="post">
<div class="form-group">
<input type="text" name="name" required class="form-control" id="name">
<label for="name">Your Name *</label>
</div>

<div class="form-group">
<input type="text" name="phone" required class="form-control" id="phone">
<label for="phone">Your Phone *</label>
</div>
<div class="form-group">
<input type="email" name="email" required class="form-control" id="email">
<label for="email">Email *</label>
</div>
<div class="form-group">
<div class="single_form">
<select class="selectmenu" required name="requesttype">
<option selected="selected" value="">Select</option>
<option>Childrens Planning</option>
<option>Investment Planning</option>
<option>Insurance Planning</option>
<option>Tax Planning</option>
<option>Commodities Trading</option>
<option>Mutual Funds</option>
<option>Wealth Management</option>
<option>Childrens Planning</option>
</select>
</div> 
<label>About</label>
</div>
<div class="form-group">
<textarea name="message" id="message" required name="message" class="form-control"></textarea>
<label for="message">Message</label>
</div>
<button type="submit" class="submit hvr-sweep-to-rightB" name="send">Submit</button>
</form>
</div>
<div class="col-lg-5 col-md-6 col-sm-6 col-xs-12 pull-right key_benefits">
<div class="title_container">
<h4>Key Benefits</h4>
<span class="decor_default"></span>
</div>
<div class="key_benefits_panel">
<div class="panel-group" id="accordion">
<div class="panel">
<div class="panel-heading active-panel">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="insurance_planning.html#collapse1">
Comprehensive Protection</a>
</h4>
</div>
<div id="collapse1" class="panel-collapse collapse in">
<div class="panel-body">
<p>Get all and more from us. </p>
</div>
</div>
</div> 
<div class="panel">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="insurance_planning.html#collapse2">
Choice of Investment option</a>
</h4>
</div>
<div id="collapse2" class="panel-collapse collapse">
<div class="panel-body">
<p>Choose from our various options the best to suit you. </p>
</div>
</div>
</div> 
<div class="panel">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="insurance_planning.html#collapse3">
Loyalty Benefits</a>
</h4>
</div>
<div id="collapse3" class="panel-collapse collapse">
<div class="panel-body">
<p>Get benefits by just being loyal. </p>
</div>
</div>
</div> 
<div class="panel">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="insurance_planning.html#collapse4">
Tax Benefits</a>
</h4>
</div>
<div id="collapse4" class="panel-collapse collapse">
<div class="panel-body">
<p>Lower tax rates all on us.. </p>
</div>
</div>
</div> 
</div> 
</div>
</div>
