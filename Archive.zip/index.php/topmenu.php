<div class="top_header">
<div class="container">
<div class="row">
<div class="col-lg-7 col-md-5 col-sm-5 col-xs-12 top_header_left">
<p><span class="fa fa-question"></span>Get Free Financial Suggestion</p>
</div>
<div class="col-lg-5 col-md-7 col-sm-7 col-xs-12 top_header_right">
<a href="tel:<?php echo $myemail; ?>"> <span class="fa fa-envelope"></span> Email Us:&nbsp; </span><?php echo $myemail; ?></a></li>

</div>
</div>
</div>
</div>

<div class="bottom_header">
<div class="container">
<div class="row">
<div class="col-lg-4 col-md-3 col-sm-12 col-xs-12 logo_holder">
<a href="contact.html#"><img src="../logo.png" style="width:200px"/></a>

</div>
<div class="col-lg-8 col-md-9 col-sm-12 col-xs-12 pull-right address_container">

<div>
<div class="icon_holder">
<span class="icon flaticon-placeholder"></span>
</div>
<div class="text_holder">
<p><?php echo $myaddress; ?> </p>
</div>
</div>
<div>
<div class="icon_holder">
<span class="icon flaticon-clock"></span>
</div>
<div class="text_holder">
<p>8am - 6pm <span>Monday to Friday</span></p>
</div>
</div>
</div>
</div>
</div>
</div>