<?php
session_start();
require_once "config.php";
if(isset($_POST['yourname']) AND isset($_POST['yourphone'])){
	if(empty($_POST['yourname']) OR empty($_POST['yourphone'])){
	$_SESSION['msg'] = '<div class="alert alert-danger">Please all input is required</div>';
	header("location: contact");
	}else{

	$name = $_POST['yourname'];
	$phone = $_POST['yourphone'];
	$mail = $_POST['youremail'];
	$type = $_POST['enquiryType'];
	$mess = $_POST['message'];


		$to = $myemail;
		$subject = 'Contact US Form';
		$headers = "From: ".$myemail."\r\n";
		$headers .= "Reply-To: ".$mail."\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
		$message = "Inquire form ".$name."<br>
		
		<b>Name:</b> ".$name."<br>
		<b>Phone:</b> ".$phone."<br>
		<b>Email:</b> ".$mail."<br>
		<b>Type:</b> ".$type."<br>
		<b>Message:</b> ".$mess."";
		if(mail($to, $subject, $message, $headers)){
			$_SESSION['msg'] = "<div class='alert alert-success'>We have Receved Required</div>";
			header("location: contact");
		}else{
			$_SESSION['msg'] = "<div class='alert alert-danger'>Oosp, unable to send message, check network connction and try again</div>";
			header("location: contact");
		}


	}
}