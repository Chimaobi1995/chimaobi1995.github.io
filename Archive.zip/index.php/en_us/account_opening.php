<?php
if(isset($_POST['name']) or isset($_POST['phone'])){
	if(empty($_POST['name']) OR empty($_POST['phone']) OR empty($_POST['email']) OR empty($_POST['address'])){
		echo "empty";
	}else{
		
		$name = $_POST['name'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$address = $_POST['address'];
		
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			echo "invaild_email";
		}else{
			echo "good";
		}
		
	}
	
}