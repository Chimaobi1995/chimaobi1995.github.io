<?php
require_once("water.php");
$client = new Client;
$client->islogged();
$myself['passport'] = configs::url102."/passports/".$myself['username'].".jpg";

?><!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html style="height: 100%;" lang="en"><!--<![endif]--><head>
 <link rel="apple-touch-icon" sizes="57x57" href="../../assets/landing/images/fav-icon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../../assets/landing/images/fav-icon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../../assets/landing/images/fav-icon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../../assets/landing/images/fav-icon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../../assets/landing/images/fav-icon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../../assets/landing/images/fav-icon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../../assets/landing/images/fav-icon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../../assets/landing/images/fav-icon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../../assets/landing/images/fav-icon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="../../assets/landing/images/fav-iconandroid-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../assets/landing/images/fav-icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../../assets/landing/images/fav-icon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../assets/landing/images/fav-icon/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/landing/images/fav-icon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <title> <?= configs::bkname; ?> | My Account</title>
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
        <meta content="" name="description">
        <meta content="" name="author">
        <link rel="icon" href="img/favicon.png" type="image/x-icon">
        <!-- ================== BEGIN BASE CSS STYLE ================== -->
		<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <link href="assets/jquery-ui.css" rel="stylesheet">
        <link href="assets/bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/font-awesome.css">
        <link href="assets/themify-icons.css" rel="stylesheet">
        <link href="assets/animate.css" rel="stylesheet">
        <link href="assets/style.css" rel="stylesheet">
		
        <!-- ================== END BASE CSS STYLE ================== -->

        <!-- ================== BEGIN BASE JS ================== -->
        <script async="" src="assets/default.js" charset="UTF-8" crossorigin="*"></script><script src="assets/pace.js"></script>
        <!-- ================== END BASE JS ================== -->

    <link type="text/css" rel="stylesheet" charset="UTF-8" href="assets/translateelement.css"><script type="text/javascript" charset="UTF-8" src="assets/main.js"></script><script type="text/javascript" charset="UTF-8" src="assets/element_main.js"></script>
	<style>
		user-select: none;
-moz-user-select: none;


	</style>
	
	</head>
	
    <body class="  pace-done" style="position: relative; min-height: 100%; top: 0px;">
	
	<div class="pace  pace-inactive"><div class="pace-progress" style="transform: translate3d(100%, 0px, 0px);" data-progress-text="100%" data-progress="99">
	

  <div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div>
        <div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="assets/translate_24dp.png" alt="Google Translate" width="20" height="20"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Original text</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Contribute a better translation</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><div id="page-container" class="page-header-fixed page-sidebar-fixed">

            <!-- BEGIN #header -->

            <div id="header" class="header navbar navbar-inverse navbar-fixed-top">

                <!-- BEGIN container-fluid -->

                <div class="container-fluid">

                    <!-- BEGIN mobile sidebar expand / collapse button -->

                    <div class="navbar-header">

                        <a href="homepage.php" class="navbar-brand" style="background-color:darkblue">



						<b style="color:lightgreen"><?php if($myself['status'] =='Active'){ echo "<i class='fa fa-circle'></i> Online";};  ?> </b>

                        </a>

                        <button type="button" class="navbar-toggle" data-click="sidebar-toggled">

                            <span class="icon-bar"></span>

                            <span class="icon-bar"></span>

                        </button>

                    </div>

                    <!-- END mobile sidebar expand / collapse button -->

                    <!-- BEGIN header navigation right -->

                    <div class="navbar-xs-justified" style="background-color:#1f1f1f;">

                        <ul class="nav navbar-nav navbar-right">

                            <li class="dropdown">

                                <a href="javascript:;" data-toggle="dropdown">

                                    <span class="navbar-user-img online pull-right">

                                        <img src="<?php print $myself['passport']; ?>">

                                    </span>

                                    <span class="hidden-xs "><?php print $myself['firstname']." ".$myself['lastname']; ?></span>

                                </a>

                                <ul class="dropdown-menu">

                                    <li><a href="profile.php"><i class="fa fa-user"></i> My Profile</a></li>

                                    <li class="divider"></li>

                                    <li><a href="edit_pass.php"><i class="fa fa-key"></i> Change Password</a></li>

                                    <li class="divider"></li>

                                    <li><a href="logout.php"><i class="fa fa-power-off"></i> Logout</a></li>

                                </ul>

                            </li>

                        </ul>

                    </div>

                    <!-- END header navigation right -->

                </div>

                <!-- END container-fluid -->

                <!-- BEGIN header-search-bar -->



                <!-- END header-search-bar -->

            </div>

            <!-- END #header -->



            <!-- BEGIN #sidebar -->

            <div id="sidebar" class="sidebar sidebar-inverse">

                <!-- BEGIN scrollbar -->

                <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 100%;"><div data-scrollbar="true" data-height="100%" style="overflow: hidden; width: auto; height: 100%;" data-init="true">

                    <!-- BEGIN nav -->

                    <ul class="nav">



                        

				 <div id="google_translate_element"><div class="skiptranslate goog-te-gadget" dir="ltr" style=""><div id=":0.targetLanguage" style="white-space: nowrap;" class="goog-te-gadget-simple"><img src="images/cleardot.gif" class="goog-te-gadget-icon" alt="" style="background-image: url(&quot;https://translate.googleapis.com/translate_static/img/te_ctrl3.gif&quot;); background-position: -65px 0px;"><span style="vertical-align: middle;"><a aria-haspopup="true" class="goog-te-menu-value" href="javascript:void(0)"><span>Select Language</span><img src="images/cleardot.gif" alt="" width="1" height="1"><span style="border-left: 1px solid rgb(187, 187, 187);">​</span><img src="images/cleardot.gif" alt="" width="1" height="1"><span style="color: rgb(118, 118, 118);" aria-hidden="true">▼</span></a></span></div></div></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="assets/element.js"></script>
				<div style="color:#000; text-align:left; padding-top:15px" class="container">
					 <span class="navbar-user-img pull-center">
						<img style="width:50px" src="<?php print $myself['passport']; ?>">
						
					 </span> 
				</div>
					<li class="nav-divider"></li>
<li class="active"><a style="color:gray" href="homepage.php"><i class="fa fa-home"></i><span>Dashboard</span></a></li>
                        <li class="nav-header">Messaging</li>

                        <li class="has-sub">

                            <a href="inbox.php">

                                <i class="fa fa-envelope-o"></i> 

                                <span>Notifications <span class="notification"><?php print systemLogs::msgsCount($myself['username']); ?>
</span></span>

                            </a>



                        </li>

                        <li><a href="ticket.php"><i class="fa fa-comments-o"></i><span>Tickets</span></a></li>

                        <li class="nav-header">Transactions</li>

                        <li><a href="make_transfer.php"><i class="fa fa-line-chart"></i><span>Transfer Fund</span></a></li>

                        <li>

                            <a href="history.php">

                                <i class="fa fa-history"></i>

                                <span>Transfer History</span> 

                            </a>

                        </li>
                        <li>

                            <a href="transact_summary.php">

                                <i class="fa fa-list"></i>

                                <span>Transaction Summary</span> 

                            </a>

                        </li>

                        <li class="nav-divider"></li>

                        <li class="nav-header">My Account</li>

                        <li><a href="profile.php"><i class="fa fa-vcard"></i><span>My Profile</span></a></li>

                        <li><a href="edit_profile.php"><i class="fa fa-edit"></i> <span>Edit Profile</span></a></li>

                        <li><a href="edit_pass.php"><i class="fa fa-key"></i> <span>Change Password</span></a></li>
                        <li><a href="logout.php"><i class="fa fa-power-off"></i> <span>Logout</span></a></li>
						
						
                        <li class="nav-divider"></li>
                        <!--li class="nav-copyright"><img src="../img/core-img/logo.png" class="img-responsive" width="100px" height="90px"></li-->

                        <li class="nav-copyright">© <?php print date('Y');?> <?= configs::bkname; ?>.  </li>
                    </ul>
                    <!-- END nav -->
                </div><div class="slimScrollBar" style="background: rgb(0, 0, 0) none repeat scroll 0% 0%; width: 7px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 652px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; opacity: 0.2; z-index: 90; right: 1px;"></div></div>
                <!-- END scrollbar -->
            </div>
            <!-- END #sidebar -->
<div style="background-color:gainsboro;height:100%">
            <!-- BEGIN #content -->
			
            <?php include $q; ?>
			<!-- END #page-container -->
</div>

            <!-- ================== BEGIN BASE JS ================== -->
            <script src="assets/jquery-1.js"></script>
            <script src="assets/jquery-migrate-1.js"></script>
            <script src="assets/jquery-ui.js"></script>
            <script src="assets/js.js"></script>
            <script src="assets/bootstrap.js"></script>
            <script src="assets/jquery.js"></script>
            <!-- ================== END BASE JS ================== -->

            <!-- ================== BEGIN PAGE LEVEL JS ================== -->
            <script src="assets/Chart.js"></script>
            <script src="assets/dashboard.js"></script>
            <script src="assets/apps.js"></script>
            <!-- ================== END PAGE LEVEL JS ================== -->

            <script>
			/*$(document).ready(function(){
	document.oncontextmenu = document.body.oncontextmenu = function() { return false;}
});*/
$("html").on("contextmenu",function(e){ return false; });

                $(document).ready(function() {
                    App.init();
                    Dashboard.init();
                });
            </script>
            <script>
                num.toLocaleString('en', {useGrouping: true})
            </script>
<!--Start of Tawk.to Script-->
<!--script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5b433aa36d961556373d8802/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

</div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><iframe class="goog-te-menu-frame skiptranslate" title="Language Translate Widget" style="visibility: visible; box-sizing: content-box; width: 1004px; height: 285px; display: none;" frameborder="0"></iframe><div id="PJ9Rly6-1531467786150" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; bottom: 0px !important; left: auto !important; position: fixed !important; border: 0px none !important; min-height: 0px !important; min-width: 0px !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: auto !important; height: auto !important; z-index: 2000000000 !important; cursor: auto !important; float: none !important; display: block; right: 0px !important;" class=""><iframe id="Dk1oEj8-1531467786151" src="about:blank" scrolling="no" title="chat widget" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; right: auto !important; bottom: auto !important; left: auto !important; position: static !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 320px !important; height: 400px !important; z-index: 999999 !important; cursor: auto !important; float: none !important; display: none !important;" class="" frameborder="0"></iframe><iframe id="fGoEiYs-1531467786153" src="about:blank" scrolling="no" title="chat widget" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; bottom: 0px !important; left: auto !important; position: fixed !important; border: 0px none !important; min-height: 40px !important; max-height: 40px !important; max-width: 260px !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; width: 260px !important; height: 40px !important; z-index: 1000001 !important; cursor: auto !important; float: none !important; min-width: 260px !important; transform: rotate(0deg) translateZ(0px) !important; transform-origin: 0px center 0px !important; right: 10px !important; display: block !important;" class="" frameborder="0"></iframe><iframe id="WEe60kH-1531467786153" src="about:blank" scrolling="no" title="chat widget" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; bottom: 40px !important; position: fixed !important; border: 0px none !important; min-height: 37px !important; min-width: 260px !important; max-height: 37px !important; max-width: 260px !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 260px !important; height: 37px !important; display: none !important; z-index: 1000003 !important; cursor: auto !important; float: none !important; right: 10px !important; left: auto !important;" class="" frameborder="0"></iframe><iframe id="KanNIwl-1531467786153" src="about:blank" scrolling="no" title="chat widget" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; left: auto !important; position: fixed !important; border: 0px none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; display: none !important; cursor: auto !important; float: none !important; transform: rotate(0deg) translateZ(0px) !important; transform-origin: 0px center 0px !important; bottom: 44px !important; right: 69px !important; width: 142px !important; max-width: 142px !important; min-width: 142px !important; height: 86px !important; max-height: 86px !important; min-height: 86px !important; z-index: 1000002 !important;" class="" frameborder="0"></iframe><div id="g0LI7rf-1531467786150" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: rgb(255, 255, 255) none repeat scroll 0% 0% !important; opacity: 0 !important; top: 1px !important; bottom: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: auto !important; height: 45px !important; display: block !important; z-index: 999997 !important; cursor: move !important; float: none !important; left: 0px !important; right: 96px !important;" class=""></div><div id="UkbuRbM-1531467786150" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: 96px !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 6px !important; height: 100% !important; display: block !important; z-index: 999998 !important; cursor: w-resize !important; float: none !important;" class=""></div><div id="UgiZB6b-1531467786150" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: 0px !important; bottom: auto !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 6px !important; height: 100% !important; display: block !important; z-index: 999998 !important; cursor: e-resize !important; float: none !important;" class=""></div><div id="snvRR0Y-1531467786150" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: 0px !important; bottom: auto !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 6px !important; display: block !important; z-index: 999998 !important; cursor: n-resize !important; float: none !important;" class=""></div><div id="kGL9cPR-1531467786150" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; right: 0px !important; bottom: 0px !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 6px !important; display: block !important; z-index: 999998 !important; cursor: s-resize !important; float: none !important;" class=""></div><div id="nZNFd2j-1531467786150" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999998 !important; cursor: nw-resize !important; float: none !important;" class=""></div><div id="qi261Jg-1531467786150" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: 0px !important; bottom: auto !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999998 !important; cursor: ne-resize !important; float: none !important;" class=""></div><div id="Da60iac-1531467786150" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; right: auto !important; bottom: 0px !important; left: 0px !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999998 !important; cursor: sw-resize !important; float: none !important;" class=""></div><div id="knLN8d6-1531467786151" style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: auto !important; right: 0px !important; bottom: 0px !important; left: auto !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999999 !important; cursor: se-resize !important; float: none !important;" class=""></div><div style="outline: currentcolor none medium !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: transparent none repeat scroll 0% 0% !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px none !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 100% !important; display: none !important; z-index: 1000001 !important; cursor: move !important; float: left !important;" class=""></div></div><iframe src="about:blank" style="display: none !important;" title="chat widget logging"></iframe></body></html>