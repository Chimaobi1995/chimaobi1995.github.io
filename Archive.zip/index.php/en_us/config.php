<?php
$adminurl = "../bk";
?>