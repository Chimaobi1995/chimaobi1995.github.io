<?php
$conn = mysqli_connect("localhost", "root", "", "bk1");