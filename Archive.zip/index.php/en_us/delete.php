<?php
print strtotime("now");
?>