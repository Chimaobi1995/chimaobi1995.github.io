<?php
function get_ip(){ 
if(isset($_SERVER['HTTP_CLIENT_IP'])){
	return $_SERVER['HTTP_CLIENT_IP'];
}elseif(isset($_SERVER['HTTP_x_FORWARDED_FOR'])){
	return $_SERVER['HTTP_x_FORWARDED_FOR'];
}
else{
	return (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR']: '');	
}
}
$ip = get_ip();

?>
 <html>
<head>
<style>
div.gallery {
    border: 0px solid #ccc;
	
}

div.gallery:hover {
    border: 0px solid #777;
}

div.gallery img {
    width: 26%;
    height: auto;
	float: left;
}
div.desc {
    padding: 15px;
    text-align: center;
	background-color: darkblue;
	color: white;
	text-decoration: none;
	opacity: .7;
	shadow:30;
}

* {
    box-sizing: border-box;
}

.responsive {
    padding: 0 6px;
    float: left;
    width: 24.99999%;
}

@media only screen and (max-width: 700px) {
    .responsive {
        width: 49.99999%;
        margin: 6px 0;
}

@media only screen and (max-width: 500px) {
    .responsive {
        width: 100%;
}

.clearfix:after {
    content: "";
    display: table;
    clear: both;
}
</style>
</head>
<body>


<div class="container-fluid">

<div class="col-sm-9">
 <!--div class="desc" style=" background-color:red;color:#fff;font-size:15px">
    <img style="width:50px" src="../img/facemask-instructions.png"/><span style="text-align:right"> Due to COVID-19 pandemic, stimulus payments, SBA PPP relief program and temporary branch closures. We appreciate your patience as we work to address unprecedented call volume and digital banking activity resulting from COVID-19. <a style="color:yellow" href="../covid-19-pandemic.php">Learn more.</a></span></div-->
<div class="responsive">
<div class="gallery">
  
    <!--img src="images/1.png"  alt="Total Balance" width="50" height="50"-->
  
  <div class="desc"><span style="font-size:30px; color:white;"><i class="fa fa-briefcase"></i></span><br>Total Balance<br>
  <span style="font-size:30px;"><?php print $myself['currency'].$myself['accountbalance']; ?></span></div>
</div>
</div>
<div class="responsive">
<div class="gallery">
 
    <!--img src="images/8.png" alt="Available Balance" width="200" height="150"-->
  
  <div class="desc"><span style="font-size:30px; color:white;"><i class="fa fa-money"></i></span><br> Available Balance<br>
  <span style="font-size:30px;"><?php print $myself['currency'].$myself['accountbalance']; ?></span>
  </div>
</div>
</div>

<div class="responsive">
<div class="gallery">
  
    <!--img src="images/7.png" alt="Last Withdrawal" width="200" height="150"-->
  
  <div class="desc"> <span style="font-size:30px; color:white;"><i class="fa fa-credit-card"></i></span><br> Last Withdrawal<br>
  <span style="font-size:30px;"><?php
  $lastwithquery = mysqli_query($conn,"SELECT amount FROM transactions WHERE sender = '".$myself['username']."' ORDER BY id DESC LIMIT 1") OR die(mysqli_error($conn));
  if(mysqli_num_rows($lastwithquery)<1){
      $myself['lastwithdrawal'] = 0;
  }else{
      $myself['lastwithdrawal'] = mysqli_fetch_array($lastwithquery)[0];
  }
  
  print $myself['currency'].$myself['lastwithdrawal']; ?></span>
  </div>
</div>
</div>

<div class="responsive">
<div class="gallery">
  <a href="make_transfer.php">
    <!--img src="images/2.png" alt="Transfer" width="200" height="150"-->
  
  <div class="desc"><span style="font-size:30px; color:white;"><i class="fa fa-line-chart"></i></span><br> Transfer Fund</div></a>
</div>
</div>
<!--div style="background-image:url('img/banking.png');"></div>
<img style="float:right;width:100%" src="../img/banking.png"/-->

	<div class="col-md-12">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12">
				<div id="chartContainer" style="height: 100%; width: 100%;"></div>
			</div>

		</div>
	</div>
</div>
</div>

<script>
window.onload = function () {
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2", // "light1", "light2", "dark1", "dark2"
	exportEnabled: true,
	title:{
		text: "Statistics - 2016 - <?php echo date('Y'); ?>"
	},
	subtitles: [{
		text: "Stock Rate USD"
	}],
	axisX: {
		valueFormatString: "MMM"
	},
	axisY: {
		includeZero:false, 
		prefix: "$",
		title: "IP Address: <?php echo $ip; ?>"
		
	},
	axisY2: {
		prefix: "$",
		suffix: "bn",
		title: "Revenue & Income",
		tickLength: 0
	},
	toolTip: {
		shared: true
	},
	legend: {
		reversed: true,
		cursor: "pointer",
		itemclick: toggleDataSeries
	},     
	data: [{
		type: "candlestick",
		showInLegend: true,
		name: "Stock Price",
		yValueFormatString: "$#,##0.00",
		xValueFormatString: "MMMM",
		dataPoints: [   // Y: [Open, High ,Low, Close]
			{ x: new Date(2016, 0), y: [101.949997, 112.839996, 89.370003, 112.209999] },
			{ x: new Date(2016, 1), y: [112.269997, 117.589996, 96.820000, 106.919998] },
			{ x: new Date(2016, 2), y: [107.830002, 116.989998, 104.400002, 114.099998] },
			{ x: new Date(2016, 3), y: [113.750000, 120.790001, 106.309998, 117.580002] },
			{ x: new Date(2016, 4), y: [117.830002, 121.080002, 115.879997, 118.809998] },
			{ x: new Date(2016, 5), y: [118.500000, 119.440002, 108.230003, 114.279999] },
			{ x: new Date(2016, 6), y: [114.199997, 128.330002, 112.970001, 123.940002] },
			{ x: new Date(2016, 7), y: [123.849998, 126.730003, 122.070000, 126.120003] },
			{ x: new Date(2016, 8), y: [126.379997, 131.979996, 125.599998, 128.270004] },
			{ x: new Date(2016, 9), y: [128.380005, 133.500000, 126.750000, 130.990005] },
			{ x: new Date(2016, 10), y: [131.410004, 131.940002, 113.550003, 118.419998] },
			{ x: new Date(2016, 11), y: [118.379997, 122.500000, 114.000000, 115.050003] }
		]
	},
	{
		type: "line",
		showInLegend: true,
		name: "Net Income",
		axisYType: "secondary",
		yValueFormatString: "$#,##0.00bn",
		xValueFormatString: "MMMM",
		dataPoints: [
			{ x: new Date(2016, 2), y: 1.510 },
			{ x: new Date(2016, 5), y: 2.055 },
			{ x: new Date(2016, 8), y: 2.379 },
			{ x: new Date(2016, 11), y: 3.568 }
		]
	},
	{
		type: "line",
		showInLegend: true,
		name: "Total Revenue",
		axisYType: "secondary",
		yValueFormatString: "$#,##0.00bn",
		xValueFormatString: "MMMM",
		dataPoints: [
			{ x: new Date(2016, 2), y: 5.382 },
			{ x: new Date(2016, 5), y: 6.436 },
			{ x: new Date(2016, 8), y: 7.011 },
			{ x: new Date(2016, 11), y: 8.809 }
		]
	}]
});
chart.render();

function toggleDataSeries(e) {
	if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	} else {
		e.dataSeries.visible = true;
	}
	e.chart.render();
}

}


</script>

</body>

<script type="text/javascript" src="assets/canvasjs.min.js"></script>
</html> 