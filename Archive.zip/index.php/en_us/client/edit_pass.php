<!-- BEGIN #content -->
            <div id="content" class="content">


                <!-- BEGIN row -->
                <div class="row">
                    <div class="col-md-12">

                        <!-- BEGIN panel -->
                        <div class="panel panel-default">
                        <?php if (isset($MSG)){
                            print "<div class='alert alert-danger'>$MSG</div>";
                        }
                        ?>
                            <!-- BEGIN panel-heading -->
                            <div class="panel-heading">
                                <h3 class="panel-title">Change Password</h3><br>
                            </div>
                            <!-- END panel-heading -->
                            <!-- BEGIN panel-body -->
                            <form method="POST">
                                <div class="panel-body">
                                                                        <p class="desc">Update your password below</p>
                                    <div class="form-group">
                                        <label class="control-label">Old Password</label>
                                        <div class="input-group date">
                                            <input class="form-control" name="oldpass" placeholder="********" type="password">
                                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">New Password </label>
                                        <div class="input-group date">
                                            <input class="form-control" name="upass1" placeholder="********" type="password">
                                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Retype New Password </label>
                                        <div class="input-group date">
                                            <input class="form-control" name="upass" placeholder="********" type="password">
                                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input class="btn btn-primary" name="reset-pass" value="Update Password" type="submit">
                                    </div>
                                </div>
                            </form>
                            <!-- END panel-body -->
                        </div>
                        <!-- END panel -->

                    </div>
                    <!-- BEGIN col-3 -->

                </div>
                <!-- END #content -->

                <!-- BEGIN btn-scroll-top -->
                <a href="https://www.rt-b.net/online/index.php#" data-click="scroll-top" class="btn-scroll-top fade"><i class="ti-arrow-up"></i></a>
                <!-- END btn-scroll-top -->
            </div>
            <!-- END #page-container -->
