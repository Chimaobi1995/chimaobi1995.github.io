<?php
    if(isset($_POST['reply'])){
		if(empty($_POST['reply'])){
			$msg = "<div class='alert alert-danger'>Please enter message</div>";
		}else{
        $reply = sanitize::clean($_POST['reply']);
        $ID = sanitize::clean($_GET['id']);
        $OWNER = $myself['username'];
        $nowunix = strtotime("now");
        $DI = "INSERT INTO `ticketmessage`(`ticketid`, `owner`, `from_`, `message`, `date`, `read_`) VALUES ('$ID','$OWNER','$OWNER','$reply','$nowunix','0')";
        mysqli_query($conn,$DI) or die(mysqli_error($conn));
        mysqli_query($conn,"UPDATE tickets SET message = '$reply' WHERE id='$ID'") or die(mysqli_error($conn));
        $msg ="<div class='alert alert-success'>Reply Sent successfully</div>";
    }
	}
?>
<div id="content" class="content p-0" style="max-width:600px;margin:auto; ">

<table class="table table-striped table-condensed table-bordered bg-white dataTable no-footer dtr-inline collapsed">
                <?php
                    if(isset($msg)){
                        print "<tr><td>$msg</td></tr>";
                    }
                ?>
                <tr><td><h3>Ticket # <?php $thistick = sanitize::clean(@$_GET['id']); print $thistick; ?>(<?php 
                $ELE = mysqli_query($conn, "SELECT subject FROM tickets WHERE id = '$thistick' LIMIT 1") or die(mysqli_error($conn));
                
                $ttitle = mysqli_fetch_assoc($ELE)['subject']; 
                
                print $ttitle; 
                ?>)</h3></td></tr>
                <tr><td>
                    <form method="post">
                        <textarea class="form-control" name="reply" placeholder="Message.."></textarea>
                        <br/>
                        <button class='btn btn-primary btn-xs'>Reply</button>

                    </form>
                </td></tr>
                <?php
					$thisTickets = Client::ReadTickets($_GET['id']);
					//print_r($thisTickets);
					if(in_array("error",$thisTickets)){
						print "<tr><td>".$thisTickets[0]."</td></tr>";
					}else{
						for($m7 = 0; $m7<count($thisTickets); $m7++){
							?>
							<tr>
								<td>
								
								
								<?php 
									if($thisTickets[$m7]['from_'] == $myself['username']){
										echo '<span style="float:right" class="label label-danger"><span style="font-size:15px">Me: </span>'.date("Y-m-d h:i", $thisTickets[$m7]['date']).'</span><br/><span style="float:left">'.$thisTickets[$m7]['message'].'</span><br/>';
									} else{
										echo '<span  class="label label-info"><span style="font-size:15px">'.$thisTickets[$m7]['from_'].': </span>'.date("Y-m-d h:i", $thisTickets[$m7]['date']).'</span><br/>'.$thisTickets[$m7]['message'].'<br/>';
										
									}
								?>
								
								</td>    

							</tr>
							<?php
						}						
					}
				?>
		</table>
</div>