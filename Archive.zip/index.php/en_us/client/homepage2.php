<?php 
//require_once "../getIP.php";
?>
<!-- BEGIN #content -->
            <div id="content" class="content">


                <!-- BEGIN row -->
                <div class="row">
                    <div class="col-md-12">

                        <!-- BEGIN panel -->
                        <div class="panel panel-default">
                        
                            <!-- BEGIN panel-heading -->
                            <div class="panel-heading">
                                <h3 class="panel-title">Dashboard</h3><br>
                            </div>
                            <!-- END panel-heading -->

							Hello


                            <!-- END panel-heading -->
                            
                        </div>
                        <!-- END panel -->

                    </div>
                    <!-- BEGIN col-3 -->

                </div>
                <!-- END #content -->

                <!-- BEGIN btn-scroll-top -->
                <a href="https://www.rt-b.net/online/index.php#" data-click="scroll-top" class="btn-scroll-top fade"><i class="ti-arrow-up"></i></a>
                <!-- END btn-scroll-top -->
            </div>
            <!-- END #page-container -->
