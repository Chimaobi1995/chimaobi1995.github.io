<!-- BEGIN #content -->
		<div id="content" class="content">
			


<h4 class="page-title block-title" style="color:#000;">Transfer Records</h4>
                <div class="block-area" id="tableHover">
                    <h3 class="block-title" style="color:#000;">View All Transfer Records</h3>
                    <div class="table-responsive overflow" style="overflow: hidden;" tabindex="5001">
                        <table class="table table-striped table-condensed table-bordered bg-white dataTable no-footer dtr-inline collapsed">
                            <thead>
                                <tr>
                                    <th>#</th>
									<th>Sender</th>
									<th>Amount Transfered</th>
                                    <th>Account Transfered To</th>
                                    <th>Bank</th>
                                    <th>Account Name</th>
                                    <th>Remarks</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $transfers = Client::transfers("list");
                            for($i8=0;$i8<count($transfers); $i8++){
                                $thisTransfer = $transfers[$i8];
                                ?>
                                <tr>
                                    <td> <i class="fa fa-chevron-circle-right"></i></td> 
									<td><?php print $thisTransfer['sender']; ?></td>
									<td><?php print $thisTransfer['amount']; ?></td>
                                   <td><?php print $thisTransfer['sent_to_name']; ?></td>
                                    <td><?php print $thisTransfer['sent_to_bank']; ?></td>
                                    <td><?php print $thisTransfer['sent_to_number']; ?></td>
                                    <td><?php print $thisTransfer['remarks']; ?></td>
                                    <td><?php print $thisTransfer['date']; //print date("Y-m-d h:i:s",$thisTransfer['date']); ?></td>
                                    
                                </tr>
                                <?php
                            }
                            ?>
	                                
                                  
                               
                            </tbody>
                        </table>
                    </div>
                </div>
                


			<?php
			/*
			<!-- BEGIN page-header -->
			<h1 class="page-header">
				Transaction Summary <br><small>You can print or export this form on PDF and Excel format</small>
			</h1>
			<!-- END page-header -->
			
			<!-- BEGIN table -->
			<div id="datatables-default_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer"><div class="row"><div class="col-sm-3"><div class="dataTables_length" id="datatables-default_length"><label>Show <select name="datatables-default_length" aria-controls="datatables-default" class="form-control input-sm"><option value="20" selected="selected">20</option><option value="40">40</option><option value="60">60</option><option value="80">80</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-9 text-right"><div class="m-l-10 pull-right"><div class="dt-buttons btn-group"><a class="btn btn-default buttons-copy buttons-html5 btn-sm" tabindex="0" aria-controls="datatables-default" href="#"><span>Copy</span></a><a class="btn btn-default buttons-print btn-sm" tabindex="0" aria-controls="datatables-default" href="#"><span>Print</span></a><a class="btn btn-default buttons-excel buttons-html5 btn-sm" tabindex="0" aria-controls="datatables-default" href="#"><span>Excel</span></a><a class="btn btn-default buttons-pdf buttons-html5 btn-sm" tabindex="0" aria-controls="datatables-default" href="#"><span>PDF</span></a></div></div><div id="datatables-default_filter" class="dataTables_filter"><label>Search:<input class="form-control input-sm" placeholder="" aria-controls="datatables-default" type="search"></label></div></div></div><div style="position: absolute; height: 1px; width: 0px; overflow: hidden;"><input tabindex="0" type="text"></div><table id="datatables-default" class="table table-striped table-condensed table-bordered bg-white dataTable no-footer dtr-inline collapsed" role="grid" aria-describedby="datatables-default_info" style="position: relative; width: 984px;"><thead>
					<tr role="row"><th class="no-sort sorting_disabled" style="width: 7px;" rowspan="1" colspan="1" data-column-index="0" aria-label="#">#</th><th style="white-space: nowrap; width: 98px;" class="sorting_asc" tabindex="0" aria-controls="datatables-default" rowspan="1" colspan="1" data-column-index="1" aria-label="TYPE: activate to sort column descending" aria-sort="ascending">TYPE</th><th style="white-space: nowrap; width: 156px;" class="sorting" tabindex="0" aria-controls="datatables-default" rowspan="1" colspan="1" data-column-index="2" aria-label="AMOUNT: activate to sort column ascending">AMOUNT</th><th style="white-space: nowrap; width: 161px;" class="sorting" tabindex="0" aria-controls="datatables-default" rowspan="1" colspan="1" data-column-index="3" aria-label="TO/FROM: activate to sort column ascending">TO/FROM</th><th style="white-space: nowrap; width: 211px;" class="sorting" tabindex="0" aria-controls="datatables-default" rowspan="1" colspan="1" data-column-index="4" aria-label="DESCRIPTION: activate to sort column ascending">DESCRIPTION</th><th style="white-space: nowrap; width: 178px; display: none;" class="sorting" tabindex="0" aria-controls="datatables-default" rowspan="1" colspan="1" data-column-index="5" aria-label="DATE/TIME: activate to sort column ascending">DATE/TIME</th></tr>
				</thead>
				
				<tbody>
								<tr class="odd"><td colspan="5" class="dataTables_empty" valign="top">No transactions yet</td></tr></tbody>
			</table><div class="pull-left"><div class="dataTables_info" id="datatables-default_info" role="status" aria-live="polite">Showing 0 to 0 of 0 entries</div></div><div class="dataTables_paginate paging_simple_numbers" id="datatables-default_paginate"><ul class="pagination"><li class="paginate_button previous disabled" id="datatables-default_previous"><a href="#" aria-controls="datatables-default" data-dt-idx="0" tabindex="0">Previous</a></li><li class="paginate_button next disabled" id="datatables-default_next"><a href="#" aria-controls="datatables-default" data-dt-idx="1" tabindex="0">Next</a></li></ul></div></div>
			<!-- END table -->
			*/
			?>

		</div>
		<!-- END #content -->