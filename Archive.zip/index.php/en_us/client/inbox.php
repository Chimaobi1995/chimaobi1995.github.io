<!-- BEGIN #content -->
		<div id="content" class="content p-0">
		    <!-- BEGIN mail-box -->
				<div style="">
		        <!-- BEGIN mail-box-sidebar -->
		        <h4 style="color:#fff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Inbox</h4>
		        <div class="list-group" style="max-width:930px;margin:auto;font-size: 14px; height:50px">
					<?php
					$myclient = new Client;
					$messages=$myclient->messages();
					//print_r($messages);
					for($mua=0;$mua<count($messages);$mua++){
						$thismsg = $messages[$mua];
						?>
						 <a onclick="readmsg(<?php print $thismsg['id']; ?>)" href="#" class="list-group-item">
						 <?php if($thismsg['isread'] == "no"){ print '<span class="label label-info"><i class="fa fa-envelope"></i> Unread</span>'; }else{print '<span class="label label-success"><i class="fa fa-folder-open-o"></i> Read</span>'; } ?> <small style="color:green"><i><?php print $thismsg['sender']; ?></i></small> <?php print $thismsg['subject_']; ?> <span class="badge"><?php print date("Y-m-d h:i:s",$thismsg['date']); ?></span></a>
						<?php
					}


					?>
</div>
		    </div>
		    <!-- END mail-box -->
		</div>
		<script>
			readmsg = function(id){
				window.open('readmessage.php?id='+id,'targetWindow','toolbar=no,location=no,status=no,menubar=no, scrollbars=yes,resizable=yes,width=320,height=600');
			}
		</script>