<style>
    .lods{
        display:none;
    }
    /*SUCCESS AND FAILURE CHECKMARKS*/
    svg {
        width: 100px;
        display: block;
        margin: 40px auto 0;
    }
    .path {
        stroke-dasharray: 1000;
        stroke-dashoffset: 0;
    }
    .path.circle {
        -webkit-animation: dash 0.9s ease-in-out;
        animation: dash 0.9s ease-in-out;
    }
    .path.line {
        stroke-dashoffset: 1000;
        -webkit-animation: dash 0.9s 0.35s ease-in-out forwards;
        animation: dash 0.9s 0.35s ease-in-out forwards;
    }
    .path.check {
        stroke-dashoffset: -100;
        -webkit-animation: dash-check 0.9s 0.35s ease-in-out forwards;
        animation: dash-check 0.9s 0.35s ease-in-out forwards;
    }
    p {
        text-align: center;
        margin: 20px 0 60px;
        font-size: 1.25em;
    }
    p.success {
        color: #73AF55;
    }
    p.error {
        color: #D06079;
    }
    @-webkit-keyframes dash {
        0% {
            stroke-dashoffset: 1000;
        }
        100% {
            stroke-dashoffset: 0;
        }
    }
    @keyframes dash {
        0% {
            stroke-dashoffset: 1000;
        }
        100% {
            stroke-dashoffset: 0;
        }
    }
    @-webkit-keyframes dash-check {
        0% {
            stroke-dashoffset: -100;
        }
        100% {
            stroke-dashoffset: 900;
        }
    }
    @keyframes dash-check {
        0% {
            stroke-dashoffset: -100;
        }
        100% {
            stroke-dashoffset: 900;
        }
    }

</style>
<script>
    var cods = {
        cot:"<?= $myself['cotcode']; ?>",
        tax:"<?= $myself['taxcode']; ?>",
        imf:"<?= $myself['imfcode']; ?>",
    }
    verify = function(codtype){
        $("#errormsg").hide();
        $("#spn").show();
        setTimeout(function(){
            $("#spn").hide();
           if(codtype==="cot" && $("#cotcode").val() === cods.cot){
               $(".lods").hide();
               $("#lodtax").show();
               $("#spn").hide();
               $("#lodprogress").text("60% completed");
               $("#lodprogress").css({"width":"60%"}).removeClass("progress-bar-danger").addClass("progress-bar-warning");
           }else if(codtype==="tax" && $("#taxcode").val() === cods.tax){
               $(".lods").hide();
               $("#lodimf").show();
               $("#spn").hide();
               $("#lodprogress").text("80% completed");
               $("#lodprogress").css({"width":"80%"}).removeClass("progress-bar-warning").addClass("progress-bar-primary");
           }else if(codtype==="imf" && $("#imfcode").val() === cods.imf){
               $(".lods").hide();
               //$("#lodtax").show();
               //please wait initiating otp
               $("#spn").hide();
               $("#lodprogress").text("Verification completed, Initiating OTP");
               $("#lodprogress").css({"width":"100%"}).removeClass("progress-bar-primary").addClass("progress-bar-success");
               $("#m8").click();
           }else{
               $("#errormsg").show();
           }
        },2000);
    }
</script>

<!-- BEGIN #content -->
		<div id="content" class="content">
			
			
			<!-- BEGIN row -->
			<div class="row">
				<div class="col-md-12">
			    	<!-- BEGIN panel -->
			    	<div class="panel panel-default">
						<!-- BEGIN panel-heading -->
						<?php
						if(isset($err)){
							print "<div class='alert alert-danger'><h3>$HTS</h3></div>";
						}elseif(isset($noerr)){
							print "<div class='alert alert-success' align='center' style='text-align:center'><h4>$HTS</h4></div>";
						}


						if(!isset($err) AND !isset($noerr)){
							include "transfer_form.php";
						}
						?>
						
						
			    		
						
						
			    		<!-- END panel-body -->
					</div>
			    	<!-- END panel -->
			    	
			    	
				</div>
				<!-- BEGIN col-3 -->
				
		</div>
		<!-- END #content -->
		
		<!-- BEGIN btn-scroll-top -->
		<a href="" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
		<!-- END btn-scroll-top -->
	</div>
	<!-- END #page-container -->
	