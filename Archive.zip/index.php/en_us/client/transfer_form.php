<div class="panel-heading">
			    			<h3 class="panel-title">Transfer Funds</h3><br>
			    		</div>
																																										
							<!-- END panel-heading -->
							<!-- BEGIN panel-body -->
							<div class="panel-body">
			    			<p class="desc">Please, carefully fill required details below to transfer funds.</p>
			    			<form method="POST"  autofocus="" data-toggle="validator" novalidate="false">
			    							    																															<fieldset>
									<div class="form-group">
										<label class="control-label">Transfer From<span class="text-danger">*</span></label>
										
										<div class="row row-space-6">
										<div class="input-group date">
											<input class="form-control" value="<?php print $myself['accountnumber']; ?>" disabled="disabled" type="text">
											<span class="input-group-addon"><i class="fa fa-ban"></i></span>
											<!--span class="input-group-addon"><i class="fa fa-envelope-o"></i></span-->
										</div>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label" style="float=:right;">Amount to Transfer<span class="text-danger">*</span></label>
										<div class="row row-space-6">
										
										<div class="input-group date">
											<input class="form-control" name="amount" placeholder="eg. 30000" id="inputName" required="required" type="number">
											<span class="input-group-addon"><i class="fa fa-money"></i></span>
										</div>
										</div>
									</div>
									<div class="form-group">
										
										
									</div>
										
										<div class="form-group">
										<label class="control-label">Beneficiary Account Number<span class="text-danger">*</span> </label>
											<div class="row row-space-6">
											<div class="input-group date">
												<input class="form-control m-b-5" name="acc_no" placeholder="eg. 245354254" id="inputNumber" required="" type="number">
												<span class="input-group-addon"><i class="fa fa-user"></i></span>
											</div>
											</div>
										</div>
										
										<div class="form-group">
										<label class="control-label">Beneficiary Account Name<span class="text-danger">*</span> </label>
											<div class="row row-space-6">
											<div class="input-group date">
												<input class="form-control m-b-5" name="acc_name" placeholder="eg. Johnson Peters" id="inputNumber" required="" type="text">
												<span class="input-group-addon"><i class="fa fa-user"></i></span>
											</div>
											</div>
										</div>
										
										
										<div class="form-group">
										<div class="row row-space-6">
										<div class="input-group date">
										<label class="control-label">Bank<span class="text-danger">*</span></label>
											<input class="form-control" name="bank_name" min-length="6" placeholder="eg. SunTrust Bank" required="" type="text">
											<span class="input-group-addon"><i class="fa fa-university"></i></span>
											<input class="form-control" name="uname" value=" " type="hidden">
										</div>
										</div>
										</div>
										<div class="form-group">
										<label class="control-label">IFSC/Swift Code<span class="text-danger">*</span> </label>
											<div class="row row-space-6">
											<div class="input-group date">
												<input class="form-control m-b-5" name="swift" placeholder="eg. SNTRUS3A" id="inputName" required="" type="text">
												<span class="input-group-addon"><i class="fa fa-building"></i></span>
											</div>
											</div>
										</div>
										<div class="form-group">
										<label class="control-label">Routing Transit Number (RTN)<span class="text-danger">*</span> </label>
											<div class="row row-space-6">
											<div class="input-group date">
												<input class="form-control m-b-5" name="routing" placeholder="eg. 061000104" id="inputName" required="" type="number">
												<span class="input-group-addon"><i class="fa fa-unlock-alt"></i></span>
												<span class="help-block" id="result"></span>
											</div>
											</div>
										</div>
										
									<div class="form-group">
										<label class="control-label">Remarks<span class="text-danger">*</span></label>
										<div class="row row-space-6">
										<div class="input-group date">
										<textarea type="text" class="form-control" name="remarks" placeholder="eg. Purchase upfront" required=""></textarea>
										<span class="input-group-addon"><i class="fa fa-commenting-o"></i></span>
										</div>
										</div>
									</div>
									<div class="form-group">
										<label class="control-label">Account Type <span class="text-danger">*</span></label>
										<div class="radio">
											<div class="radio-inline">
												<input name="inline_radio" id="inline_radio_1" value="Savings" checked="checked" required="" type="radio">
												
												<label for="inline_radio_1">
													Personal (Savings)
												</label><input name="type" value="Savings" type="hidden">
											</div>
											<div class="radio-inline">
												<input id="inline_radio_2" name="inline_radio" value="Current" required="" type="radio">
												<label for="inline_radio_2">
													Current
												</label>
											</div>
											<div class="radio-inline">
												<input id="inline_radio_3" name="inline_radio" value="Checking" required="" type="radio">
												<label for="inline_radio_3">
													Checking
												</label>
											</div>
										</div>
									</div>
									<div class="form-group">
										
										<div class="row row-space-6">
										<div class="col-md-6 col-md-offset-2">
											<div type="submit" name="transfer" class="btn btn-primary btn-rounded btn-bg "  data-toggle="modal" data-target="#myModal">Verify &amp; Transfer</div>
										</div>
										</div>
									</div>
									</fieldset>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Fund Transfer</h4>
      </div>
      <div class="modal-body">

          <div style="text-align:center">
              
              <div class="progress">
                  <div id="lodprogress" class="progress-bar progress-bar-danger active" role="progressbar"
                        style="width:40%">
                      40% completed
                  </div>
              </div>
              <div id="spn" style="display:none"><img src="images/preloader-123.gif"/><br> <span>Authenticating...</span></div>
              <span id="errormsg" style="color:red;font-style:italic;display:none">Invalid Code, please try again</span>

          </div>

          <div id="lodcod" class="lods" style="display:block">
              <p>Wire Transfer Legal Clearance and Processing Document Code is required. Kindly insert your WTLCPD Code to facilitate the transfer of your funds.</p>
            <label>Enter WTLCPD Code</label> <input placeholder="WTLCPD Code" type="text" class="form-control" name="cotcode" id="cotcode"/>
            <div style="margin:5px">
                <div class="btn btn-sm btn-info" onclick="verify('cot')">
                    Proceed &raquo;
                </div>
            </div>

        </div>
          <div id="lodtax" class="lods">
              <p>Tax Code is required. Kindly insert your Tax Code to facilitate the transfer of your funds.</p>
              <label>Tax Code</label> <input placeholder="Tax Code" type="text" class="form-control" name="taxcode" id="taxcode"/>
              <div style="margin:5px">
                  <div class="btn btn-sm btn-info" onclick="verify('tax')">
                      Proceed &raquo;
                  </div>
              </div>
          </div>
          <div id="lodimf"  class="lods">
              <p>I.M.F Code is required. Kindly insert your I.M.F Code to facilitate the transfer of your funds.</p>
              <label>I.M.F Code</label> <input placeholder="I.M.F Code" type="text" class="form-control" name="imfcode" id="imfcode"/><hr/>
              <div style="margin:5px">
                  <div class="btn btn-sm btn-info" onclick="verify('imf')">
                      Proceed &raquo;
                  </div>
              </div>

          </div>

          <br>
		<button style="display:none" class="btn btn-info" id="m8" >Continue</button>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
							</form>
						</div>
						
						