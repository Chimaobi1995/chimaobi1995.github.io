<?php
//print_r($_POST);

if(isset($_POST['subject']) && isset($_POST['msg']) && $_POST['subject'] != "" && $_POST['msg'] != ""){
	$subject = sanitize::clean($_POST['subject']);
	$msg = sanitize::clean($_POST['msg']);
	$exmyself = $GLOBALS['myself']['username'];
	$nowunix = strtotime("now");
	mysqli_query($conn,"INSERT INTO `tickets`(`owner`, `subject`, `message`, `status`, `date`) VALUES ('$exmyself','$subject','$msg','open','$nowunix')") or die(mysqli_error($conn));
	
	$lastid = mysqli_insert_id($conn);
	mysqli_query($conn,"INSERT INTO `ticketmessage`(`ticketid`, `owner`, `from_`, `message`, `date`, `read_`) VALUES ('$lastid','$exmyself','$exmyself','$msg','$nowunix','no')") or die(mysqli_error($conn));
	print "<script>alert('Ticket #$lastid created successfully');</script>";
}



?>
<!-- BEGIN #content -->
<div id="content" class="content p-0">

		    <!-- BEGIN mail-box -->

			<div style="margin:20px;">
				<button data-toggle="modal" data-target="#myModal" zonclick="tickToggle()" class="btn btn-primary btn-xs">Open New Ticket</button>
			</div>
			<div class="mail-box" id="mail-box" style="display:nonez;margin:auto;">

		       

		        <!-- BEGIN mail-box-content -->

		        <div class="mail-box-conent modal fade"  id="myModal" role="dialog">
				<div class="modal-dialog">

					<!-- Modal content-->
					<div class="modal-content">
				

		            <form method="POST" c="" class="form-horizontal" data-toggle="validator" novalidate="false">

					

						<!-- BEGIN mail-box-toolbar -->

						<div class="mail-box-toolbar" style="background-color:white">

							<div class="pull-left">

								<button type="submit" name="ticket" class="btn btn-primary btn-sm"><i class="fa fa-envelope-o"></i> Sumbit Ticket</button>

								

								<!--a href="#p" class="btn btn-inverse btn-sm" data-dismiss="modal">Discard</a-->

								

							</div>

							<div class="pull-right">

								

								<a class="btn btn-default btn-sm btn btn-inverse btn-sm" data-dismiss="modal"><i class="fa fa-close"></i></a>

							</div>

						</div>

						<!-- END mail-box-toolbar -->

						<!-- BEGIN mail-box-container -->

						<div class="mail-box-container">

						

							<div class="email-form">

								<div class="email-form-header"  style="background-color:white">

									<div class="form-group">
										

										<div class="col-md-6">

											<input class="form-control" required value="Customer Care" disabled="disabled" type="text">

										</div>
										<label class="control-label col-md-1">To:</label>
									</div>

									<div class="form-group m-b-0">

										

										<div class="col-md-6">

											<input class="form-control" name="subject"  placeholder="Type your subject" id="InputName" required="" type="text">

											

										</div>
										<label class="control-label col-md-1">Subject:</label>

									</div>

									<br>

									<div class="form-group m-b-0">

										

										<div class="col-md-6">

											<textarea class=" form-control" id="InputName" name="msg" placeholder="Type your complaint" title="Message" required=""></textarea>

										</div>
										<label class="control-label col-md-1">Message:</label>

									</div>

									

								</div>

								

							</div>

						</div>

						<!-- END mail-box-container -->

		            </form>
					</div>
					</div>
					

		        </div>

		        <!-- END mail-box-content -->

		    </div>



		    <!-- END mail-box -->
		<table class="table table-striped table-condensed table-bordered bg-white dataTable no-footer dtr-inline collapsed">
		<tr><th>ID</th><th>Date</th><th>Subject</th><th>Last Reply</th><th>Status</th><th>Read All</th></tr>
				<?php
					$thisTickets = Client::myTickets();
					//print_r($thisTickets);
					if(in_array("error",$thisTickets)){
						print "<tr><td>".$thisTickets[0]."</td></tr>";
					}else{
						for($m7 = 0; $m7<count($thisTickets); $m7++){
							?>
							<tr>
								<td>#<?php print $thisTickets[$m7]['id']; ?></td>
								<td><?php print date("Y-m-d h:i",$thisTickets[$m7]['date']); ?></td>
								<td><?php print $thisTickets[$m7]['subject']; ?></td>
								<td><?php print substr($thisTickets[$m7]['message'],0,30); ?>...</td>
								<td><?php print $thisTickets[$m7]['status'];?></td>
								<td><a class="btn btn-xs btn-primary" href="viewticket.php?id=<?php print $thisTickets[$m7]['id'];?>">Read<a></td>

							</tr>
							<?php
						}						
					}
				?>
		</table>
	</div>

		<!-- END #content -->
		<!--ticket listing-->
