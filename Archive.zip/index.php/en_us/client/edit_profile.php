<!-- BEGIN #content -->
		<div id="content" class="content">
		<!-- BEGIN row -->
			<div class="row">
				<div class="col-md-12">
				<!-- BEGIN panel -->
			    	<div class="panel panel-default">
			    		<!-- BEGIN panel-heading -->
			    		<div class="panel-heading">
			    			<h3 class="panel-title">Edit Profile</h3><br>
			    		</div>
			    		<!-- END panel-heading -->
			    		<!-- BEGIN panel-body -->
			    		<div class="panel-body">
			    			<p class="desc">You can update your information here</p>
			    			<form action="" method="POST" autofocus="">
			    							    				<div class="form-group">
									<label class="control-label">Email </label>
									<div class="input-group date">
										<input class="form-control" name="email" type="email" value="<?= $myself['email']; ?>">
										<span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
									</div>
								</div>
			    				<div class="form-group">
									<label class="control-label">Phone </label>
									<div class="input-group date">
										<input class="form-control" name="phone"  value="<?= $myself['phone']; ?>" type="text">
										<span class="input-group-addon"><i class="fa fa-phone"></i></span>
									</div>
								</div>
								
								<div class="form-group">
									<label class="control-label">Address</label>
									<div class="input-group date">
										<input class="form-control"  value="<?= $myself['address']; ?>" name="addr" type="text">
										<span class="input-group-addon"><i class="fa fa-map"></i></span>
									</div>
								</div>
								<div class="form-group">
									<input class="btn btn-primary" name="update" value="Update Info" type="submit">
								</div>
								
								
								
							</form>
						</div>
			    		<!-- END panel-body -->
					</div>
			    	<!-- END panel -->
			    	
			    	
				</div>
				<!-- BEGIN col-3 -->
				
		</div>
		<!-- END #content -->
		
		<!-- BEGIN btn-scroll-top -->
		<a href="#" data-click="scroll-top" class="btn-scroll-top fade"><i class="ti-arrow-up"></i></a>
		<!-- END btn-scroll-top -->
	</div>
	<!-- END #page-container -->