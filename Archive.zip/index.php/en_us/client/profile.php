<!-- BEGIN #content -->
            <div id="content" class="content p-0">
                <!-- BEGIN profile-header -->
                <div class="profile-header">
                    <!-- BEGIN profile-header-cover -->
                    <div class="profile-header-cover"></div>
                    <!-- END profile-header-cover -->
                    <!-- BEGIN profile-header-content -->
                    <div class="profile-header-content">
                        <!-- BEGIN profile-header-img -->
                        <div class="profile-header-img"> <img src="<?php print $myself['passport']; ?>" class="img-responsive" alt="profile picture"> </div>
                        <!-- END profile-header-img -->
                        <!-- BEGIN profile-header-info -->
                        <div class="profile-header-info">
                            <h4>  </h4>
                            <p>
                                                            </p> <a href="edit_profile.php" class="btn btn-xs btn-primary">Edit Profile</a> </div>
                        <!-- END profile-header-info -->
                    </div>
                    <!-- END profile-header-content -->
                    <!-- BEGIN profile-header-tab -->
                    <ul class="profile-header-tab">
                        <li></li>
                    </ul>
                    <!-- END profile-header-tab -->
                </div>
                <!-- END profile-header -->
                <!-- BEGIN profile-container -->
                <div class="profile-container">
                    <!-- BEGIN row -->
                    <div class="row row-space-20">
                        <!-- BEGIN col-8 -->
                        <!-- BEGIN col-4 -->
                        <!-- BEGIN profile-info-list -->
                        <ul style="color:#000;" class="profile-info-list">
                            <li class="title">
                                <h1 style="color:#000;"><?php print $myself['firstname'].' '.$myself['lastname']; ?></h1></li>
                                <h5 style="color:#000;"><strong>ACCOUNT INFORMATION</strong></h5></li>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Email</b></div>
                                    <div class="value"><?php print $myself['email']; ?>
                                                                            </div>
                                </li>
                                <br>
                                <li>
                                    <div class="field"><b>Phone</b></div>
                                    <div class="value"><?php print $myself['phone']; ?>
                                                                            </div>
                                </li>
                                <br> 
							</div>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Sex</b></div>
                                    <div class="value"><?php print $myself['gender']; ?>
                                                                            </div>
                                </li>
                                <br>
                                <li>
                                    <div class="field"><b>Marital Status</b></div>
                                    <div class="value"><?php print $myself['maritalstatus']; ?>
                                                                            </div>
                                </li>
                                <br> 
							</div>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Date of Birth</b></div>
                                    <div class="value"><?php print $myself['dob']; ?>
                                                                            </div>
                                </li>
                                <br>
                                <li>
                                    <div class="field"><b>Account No</b></div>
                                    <div class="value"><?php print $myself['accountnumber']; ?></div>
                                </li>
                                <br>
							</div>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Account Type</b></div>
                                    <div class="value">
                                         
                                    <?php print $myself['accountype']; ?></div>
                                </li>
                                <br> 
							</div>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Address</b></div>
                                    <div class="value"> <address class="m-b-0"><?php print $myself['address']; ?></address> </div>
                                </li>
                                <br> 
							</div>
							<div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Active Since</b></div>
                                    <div class="value">
                                        
                                    <?php print $myself['registrationdate']; ?></div>
                                </li>
                                <br> 
							</div>
							
							</ul>
							
                        <!-- END profile-info-list -->
                        </div>
                        <!-- END col-4 -->
                    </div>
                    <!-- END row -->
                </div>
                <!-- END profile-container -->