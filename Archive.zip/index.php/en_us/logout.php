<?php
require_once("water.php");
$k = new Client;
$k->logout();
?>