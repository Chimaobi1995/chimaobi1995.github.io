<?php
require_once("water.php");
$Client = new Client;
$Client->isLogged();
ini_set("display_errors", 0);
if(isset($_POST) && $_POST['oldpass'] != "" && $_POST['upass1'] != "" && $_POST['upass'] != ""){

    $oldpass = sanitize::clean($_POST['oldpass']);
	$upass = sanitize::clean($_POST['upass']);
    $upass1 = sanitize::clean($_POST['upass1']);
    
    if($oldpass != $myself['password']){
        $MSG = "Sorry, Incorrect Password";
        goto Skip;
    }elseif($upass != $upass1){
        $MSG = "Please ensure you retyped the new password";
        goto Skip;
    }
	
	$mi = $myself['username'];
	mysqli_query($conn,"UPDATE pipul SET password = '$upass' WHERE username = '$mi'") or die(mysqli_error($conn));
    header("Location: logout.php");
    Skip:
}
ini_set("display_errors", 1);
$q = "client/edit_pass.php";
include "accountdashboard.php";
?>