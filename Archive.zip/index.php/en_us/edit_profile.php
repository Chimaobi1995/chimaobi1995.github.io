<?php
require_once("water.php");
ini_set("display_errors", 0);
$Client = new Client;
$Client->isLogged();
if(isset($_POST) && $_POST['addr'] != "" && $_POST['phone'] != "" && $_POST['email'] != ""){
	$phone = sanitize::clean($_POST['phone']);
	$email = sanitize::clean($_POST['email']);
	$addr = sanitize::clean($_POST['addr']);
	$mi = $myself['username'];

	$mmm=mysqli_query($conn,"UPDATE pipul SET phone = '$phone', email = '$email', address = '$addr' WHERE username = '$mi'") or die(mysqli_error($conn));
	
	header("Location: profile.php");
}
ini_set("display_errors", 1);
$q = "client/edit_profile.php";
include "accountdashboard.php";
?>