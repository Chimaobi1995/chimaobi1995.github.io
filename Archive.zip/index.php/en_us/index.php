<?php
session_start();
require_once("water.php");
$client = new Client;

if(isset($_POST['u_input']) AND isset($_POST['p_input'])){
    $clientAuth = $client->auth($_POST['u_input'],$_POST['p_input']);
    
	$myClient = new Client();
	$myClient->isLogged();
	
	if($clientAuth != true){
       //$_SESSION['msg'] = $client->logout("<div class='alert alert-danger'><i class='fa fa-times'></i> Invalid Login Details</div>");
	   
       	$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Invalid Login Details</div>";
       	
    }else if($myself['status'] == 'Dormant/Inactive'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! this Account is Dormant or have not been Activated!</div>"; 
	
	}else if($myself['status'] == 'SUSPEND'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! Your Account has been suspended, we noticed unidentified activities, please contact <a href='../contact'>support!</a></div>"; 
	
	    
	}else if($myself['status'] == 'DISABLED'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! Your Account Has Been Disabled For Violation of Our Terms!</div>"; 
	
	}else if($myself['status'] == 'CLOSED'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! this Account has been Closed or No Longer Exist!</div>";
	
	    
	}else if($myself['status'] == 'ON HOLD'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! this Account is currently on hold, please contact <a href='../contact'>support</a></div>"; 
	}else{
	
        //verifying otp
        if(isset($_POST['otp'])){
            if($_POST['otp'] != $myself['otp']){
                $otpmessage = "<div class='alert alert-danger'>Invalid OTP, Please try again</div>";
                goto shootp;
            }else{
                print "<script>location.href='homepage';</script>";
                //die();
                header("Location: homepage");
                die();
            }
        }
        /* print_r($_SESSION);
        PRINT_r($myself);
        DIE(); */
        $myClient->generateOTP();
        if(!isset($otpmessage)){
            $otpmessage = "";
        }
            
        $otpmessage = "$otpmessage <br/>Please Provide One Time Password sent to ".$myself['email']." to Login to your account";
        shootp:
        $otpformelements = '

        <input type="hidden" name="u_input" value="'.$_POST['u_input'].'" />
        <input type="hidden" name="p_input" value="'.$_POST['p_input'].'" />
    
    ';
        require_once("verifyotp.php");
        unset($_SESSION['user']);
        die(); 

        //end of otp verification
    }
}
require_once "../config.php";
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <head>
        <meta charset="utf-8" />
        <title><?php echo $title; ?> financial Solution | Login</title>
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <link rel="apple-touch-icon" sizes="57x57" href="../../assets/landing/images/fav-icon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../../assets/landing/images/fav-icon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../../assets/landing/images/fav-icon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../../assets/landing/images/fav-icon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../../assets/landing/images/fav-icon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../../assets/landing/images/fav-icon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../../assets/landing/images/fav-icon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../../assets/landing/images/fav-icon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../../assets/landing/images/fav-icon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192" href="../../assets/landing/images/fav-icon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../../assets/landing/images/fav-icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../../assets/landing/images/fav-icon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../../assets/landing/images/fav-icon/favicon-16x16.png">
        <!-- ================== BEGIN BASE CSS STYLE ================== -->
        <link href="assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css" rel="stylesheet" />
        <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
        <link href="assets/plugins/icon/themify-icons/themify-icons.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="assets/css/animate.min.css" rel="stylesheet" />
        <link href="assets/css/style.min.css" rel="stylesheet" />
        <!-- ================== END BASE CSS STYLE ================== -->

        <!-- ================== BEGIN BASE JS ================== -->
        <script src="assets/plugins/loader/pace/pace.min.js"></script>
        <!-- ================== END BASE JS ================== -->
    </head>
    <body class="inverse-mode" style="background-image: url(img/sunset.jpg); background-size:cover; background-attachment:fixed;">
        <!-- BEGIN #page-container -->
        <div id="page-container">
            <!-- BEGIN login -->
            <div class="login"><img src="img/logo.png" height="60" width="150" style="padding: 10px 10px; ">
                <b style="font-size:2.0em; color:#fff;"></b>
                <!-- BEGIN login-cover -->
                <div class="login-cover"></div>
                <!-- END login-cover -->
                <!-- BEGIN login-content -->
                <div class="login-content">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <!-- BEGIN login-brand -->
                    <div class="login-brand">
                        <a href="login.php#"><span class=" fa fa-lock logo"></i></span> Internet Banking Access </a>
                    </div>
					
					<?php if(isset($_SESSION['msg'])){ echo $_SESSION['msg']; unset($_SESSION['msg']);} 
						if(isset($msg)){
							echo $msg;
							unset($msg);
						}
					?>
                    <!-- END login-brand -->
                    <!-- BEGIN login-desc -->
                    <div class="login-desc">
                        Log in securely into your account
                    </div>
                    <!-- END login-desc -->
                    <!-- BEGIN login-form -->
                    <form method="POST">
                        <div class="form-group">
                            <label class="control-label">Account No</label>
                            <input type="text" name="u_input" class="form-control" placeholder="Enter your account no" autofocus />
                            
                        </div>
                        <div class="form-group">
                            <label class="control-label">Password</label>
                            <input type="password" name="p_input" class="form-control" placeholder="Enter password" />
                        </div>


                        <button type="submit" name="send" class="btn btn-inverse">Sign In</button>
                    </form>

				<div class="m-t-20">
					Not yet a customer? Click <a href="../apply">here</a> to apply.
				</div>
                    <!-- END login-form --><br><br><br><br><br><br><br>
                    <footer class="">
                        &copy; <?php echo date('Y').' '.$title; ?> financial Solution . All Rights Reserved.

                    </footer>
                </div>
                <!-- END login-content -->
            </div>
            <!-- END login -->

            <!-- BEGIN btn-scroll-top -->
            <a href="login.htm#" data-click="scroll-top" class="btn-scroll-top fade"><i class="ti-arrow-up"></i></a>
            <!-- END btn-scroll-top -->

        </div>
        <!-- END #page-container -->

        <!-- ================== BEGIN BASE JS ================== -->
        <script src="assets/plugins/jquery/jquery-1.9.1.min.js"></script>
        <script src="assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
        <script src="assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
        <script src="assets/plugins/cookie/js/js.cookie.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/plugins/scrollbar/slimscroll/jquery.slimscroll.min.js"></script>
        <!-- ================== END BASE JS ================== -->

        <!-- ================== BEGIN PAGE LEVEL JS ================== -->
        <script src="assets/js/apps.min.js"></script>
        <!-- ================== END PAGE LEVEL JS ================== -->

        <script>
            $(document).ready(function() {
                App.init();
            });
        </script>

    </body>
</html>
