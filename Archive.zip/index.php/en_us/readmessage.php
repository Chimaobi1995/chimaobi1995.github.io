<?php
require_once("water.php");
$myclient = new Client;
$myclient->isLogged();
if(isset($_GET['id'])){
    $thismsg = $myclient->messages($_GET['id'],"read");
    //print_r($thismsg);
}
?>
  <link href="assets/jquery-ui.css" rel="stylesheet">
        <link href="assets/bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <link href="assets/themify-icons.css" rel="stylesheet">
        <link href="assets/animate.css" rel="stylesheet">
        <link href="assets/style.css" rel="stylesheet">
 <body style="background-color:whitesmoke;margin:10px;">




 <div class="list-group">
  <div href="#" class="list-group-item active">From: <?php print $thismsg['sender']; ?></div>
  <div href="#" class="list-group-item">
  <span class="label label-primary">SUBJECT: <?php print $thismsg['subject_']; ?> </span>
  <br/>
  <br/>
  <?php print $thismsg['content']; ?></div>
  
  <div class="list-group-item"><button onclick="window.close()" class="btn btn-danger btn-xs"><i class="fa fa-close"></i> Close</button> <button onclick="window.print()" class="btn btn-primary btn-xs"><i class="fa fa-print fa-printer"></i> Print</button> 
</div>
</body>