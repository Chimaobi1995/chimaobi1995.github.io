<?php
require "config.php";
require $adminurl."/blood.php";
class Client{
    public function __construct(){
        if(session_id()==''){
            session_start();
        }
    }
    public function auth($username, $password){
        if($username == "" || $password == ""){
            goto logot;
        }
        if(session_id()==''){
            session_start();
        }
        $conn = $GLOBALS['conn'];
        $salt = $this->reSalt($password);
        $g = "SELECT * FROM pipul WHERE (username='$username' OR accountnumber='$username') AND password = '$password'";
        //print $g;
        //die($g);
        $getam = mysqli_query($conn,$g) or die(mysqli_error($conn));
        if(mysqli_num_rows($getam)<1){
            logot:
            //header("Location: control.php");
            $_SESSION['msg'] = "<div class='alert alert-danger'>Invalid login or expired license<div>";
        }else{
            $ry = mysqli_fetch_array($getam);
            $_SESSION['user'] = $ry['aid'];
            return true;
            //header("Location: master.php");
        }
    }
    private function reAuth($client){
        $conn = $GLOBALS['conn'];
        $g = "SELECT * FROM pipul WHERE aid='$client'";
        $getam = mysqli_query($conn,$g) or die(mysqli_error($conn));
        if(mysqli_num_rows($getam)<1){
            return $this->logout("Session Expired");
        }else{
            $myData = mysqli_fetch_assoc($getam);
            $GLOBALS['myself'] = $myData;
            $GLOBALS['myself']['passport'] = configs::url102."/passport/".$myData['username'].".jpg";
            $myusername = $myData['username'];
            $l = mysqli_query($conn,"SELECT amount FROM transactions WHERE sender = '$myusername' AND type_ = 'Debit' LIMIT 1") or die(mysqli_error($conn));
            if(mysqli_num_rows($l) > 0){
                $lastwithdrawal = mysqli_fetch_array($l)[0];
            }else{
                $lastwithdrawal = 0;
            }
            $GLOBALS['myself']['lastwithdrawal'] = $lastwithdrawal;
            return $myData;
        }
    }
    public function isLogged(){
        if(session_id()==''){
            session_start();
        }
        if(isset($_SESSION['user'])){
            $sesuser=$_SESSION['user'];
            $this->reAuth($sesuser);
            $_SESSION['msg'] = "Logged IN";
            return $sesuser;
        }else{
            $this->logout("Session Expired");
            //print "logout";
        }
    }
    private function reSalt($pass){
        //will modify resalt method to interprete salt
        return $pass;
    }
    public function logout($x="<div class='alert alert-info'>You Have Logged Out Successfully</div>"){
        if(session_id()==''){
            session_start();
        }
        unset($_SESSION['user']);
        $_SESSION['msg'] = $x;
        header("Location: ./");
    }
    public function myTickets(){
        $conn = $GLOBALS['conn'];
        $id = $GLOBALS['myself']['username'];
        $container = array();
        $m = mysqli_query($conn,"SELECT * FROM tickets WHERE owner = '$id' ORDER by status DESC, id DESC") or die(mysqli_error($conn));
        if(mysqli_num_rows($m)>0){
            $contena = array();
            while($mm=mysqli_fetch_assoc($m)){
                $contena[] = $mm;
            }
            return $contena;
        }else{
            return array(
                "Sorry, No Ticket Found",
                "error"
            );
        }
    }
    public function ReadTickets($tid){
        $conn = $GLOBALS['conn'];
        $tid = sanitize::clean($tid);
        $id = $GLOBALS['myself']['username'];
        $container = array();
        $m = mysqli_query($conn,"SELECT * FROM ticketmessage WHERE owner = '$id' AND ticketid = '$tid' ORDER BY id DESC") or die(mysqli_error($conn));
        $contena = array();
        if(mysqli_num_rows($m)>0){
            while($mm=mysqli_fetch_assoc($m)){
                $contena[] = $mm;
            }
            return $contena;
        }else{
            return array(
                "Sorry, Invalid Ticket id",
                "error"
            );
        }
    }
    public function transfers($todo){
        $conn = $GLOBALS['conn'];
        $myusername = $GLOBALS['myself']['username'];
        if($todo == "list"){
            $tick= mysqli_query($conn,"SELECT * FROM transactions WHERE sent_to_name = '$myusername' ORDER BY id desc") or die(mysqli_error($conn));
            $mem = array();
            while($ti=mysqli_fetch_assoc($tick)){
                $mem[] = $ti;
            }
            return $mem;
        }
    }

    public function transLog(){
        $conn = $GLOBALS['conn'];
        $myusername = $GLOBALS['myself']['username'];
        $longtin = "SELECT pipul.accountnumber, credit_debit_history.username, credit_debit_history.amount_transfered, credit_debit_history.description,credit_debit_history.type_,credit_debit_history.date_,credit_debit_history.time_ FROM credit_debit_history INNER JOIN pipul ON pipul.username = credit_debit_history.username WHERE pipul.username = '$myusername' ORDER BY id DESC";
        $tick= mysqli_query($conn,$longtin) or die(mysqli_error($conn));
        $mem = array();
        while($ti=mysqli_fetch_assoc($tick)){
            $mem[] = $ti;
        }
        return $mem;
    }
    public function generateOTP(){
        $ot=mt_rand(100000,999999);
        $myusa = $GLOBALS['myself']['username'];
        $mynomb = $GLOBALS['myself']['phone'];
        $mymail = $GLOBALS['myself']['email'];
        $conn = $GLOBALS['conn'];
        mysqli_query($conn,"UPDATE pipul SET otp = '$ot' WHERE username = '$myusa'") or die(mysqli_error($conn));
        $this->sendSMS("Your One Time Password is $ot, do not share this with anyone",$mynomb);
        $this->sendEmail("You have initiated a transaction","Your One Time Password is $ot, do not share this with anyone",configs::email102,$mymail);
    }
    public function sendSMS($mesej,$nomba){
        $curl = curl_init();
        $Q1 = configs::smsAPI;
        $Q1 = str_replace("%%destination%%",urlencode($nomba),$Q1);
        $Q1 = str_replace("%%message%%",urlencode($mesej),$Q1);
        $Q1 = str_replace("%%sender%%",urlencode(configs::smssenderid),$Q1);
        //$Q1 = str_replace("%%sender%%",urlencode(configs::bkname),$Q1);
      
        //print $Q1;
        //die();
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => $Q1
        ));
        $res_send = curl_exec($curl);
        curl_close($curl);
       // print $res_send;
        //die();
        
       
    }
    public function sendEmail($subj,$mesej,$from_,$to){
        $msg = file_get_contents("emailtemplate.php");
        $content = str_replace("{MAILBODY}",$mesej,$msg);
        $content = str_replace("{SUBJECT}",$subj,$content);
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: $from_" . "\r\n";

        return mail($to,$subj,$content,$headers);

    }
    public function DoTransfer($sender,$amount,$sent_to_number,$sent_to_bank,$sent_to_name,$remarks,$type_){
        $sender = sanitize::clean($sender);
        $amount = sanitize::clean($amount);
        $sent_to_number = sanitize::clean($sent_to_number);
        $sent_to_bank = sanitize::clean($sent_to_bank);
        $sent_to_name = sanitize::clean($sent_to_name);
        $remarks = sanitize::clean($remarks);
        $nowunix = strtotime("now");
        $date = date("d/m/Y",$nowunix);
        $time = date("h:i:s",$nowunix);
        $type_ = sanitize::clean($type_);
        $newotp = mt_rand('100000','999999');

        $conn = $GLOBALS['conn'];

        //debit me
        mysqli_query($conn,"UPDATE pipul SET accountbalance = (accountbalance-$amount), otp = '$newotp' WHERE username = '$sender'") or die(mysqli_error($conn));

        //add to transaction log
        $sender = $GLOBALS['myself']['username'];
        mysqli_query($conn, "INSERT INTO `transactions`(`sender`, `amount`, `sent_to_number`, `sent_to_bank`, `sent_to_name`, `remarks`, `date`, `time`, `type_`) VALUES ('$sender','$amount','$sent_to_number','$sent_to_bank','$sent_to_name','$remarks','$date','$time','$type_')") or die(mysqli_error($conn));

        //add to credit_debit_history
        mysqli_query($conn, "INSERT INTO `credit_debit_history`(`username`, `amount_transfered`, `description`, `type_`, `date_`, `time_`) VALUES ('$sender','$amount','$remarks','$type_','$date','$time')") or die(mysqli_error($conn));

        //send notification
        $cur = $GLOBALS['myself']['currency'];
        $mymail = $GLOBALS['myself']['email'];
        $bal = $GLOBALS['myself']['accountbalance']-$amount;
        $mynomb = $GLOBALS['myself']['phone'];
        $msg = "Your Account has been debited with $cur $amount \n Current balance $cur $bal";
        $this->sendSMS($msg,$mynomb);
        $this->sendEmail("Transaction details",$msg,configs::email102,$mymail);

    }
    public function messages($id=0,$task = "list"){
        if($task=="read"){
            return $this->readmessage($id);
        }elseif($task == "delete"){
            return $this->deletemessage($id);
        }
        //listing all messages
        $myusername = $GLOBALS['myself']['username'];
        $ms=mysqli_query($GLOBALS['conn'], "SELECT * FROM messages WHERE owner = '$myusername' ORDER BY id DESC") OR DIE(mysqli_error($GLOBALS['conn']));
        $container = array();
        while($ma=mysqli_fetch_assoc($ms)){
            $container[] = $ma;
        }
        return $container;
    }
    private function readmessage($id){
        $id = sanitize::clean($id);
        $myusername = $GLOBALS['myself']['username'];
        mysqli_query($GLOBALS['conn'],"UPDATE messages SET isread = 'yes' WHERE id = '$id'") or die(mysqli_error($GLOBALS['conn']));
        $ms = mysqli_fetch_assoc(mysqli_query($GLOBALS['conn'],"SELECT * FROM messages WHERE id = '$id' AND owner = '$myusername'"));
        return $ms;
    }
    private function deletemessage($id){
        $id = sanitize::clean($id);
        mysqli_query($GLOBALS['conn'],"DELETE from messages WHERE id = '$id' LIMIT 1") or die(mysqli_error($GLOBALS['conn']));
        return "Message Deleted successfully";
    }
}
?>