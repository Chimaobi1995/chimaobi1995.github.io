<?php 
//session_start();
require_once "../init.php";
require_once("water.php");
$client = new Client;

if(isset($_POST['send'])){
    $clientAuth = $client->auth($_POST['u_input'],$_POST['p_input']);
    
	$myClient = new Client();
	$myClient->isLogged();
	
	if($clientAuth != true){
       //$_SESSION['msg'] = $client->logout("<div class='alert alert-danger'><i class='fa fa-times'></i> Invalid Login Details</div>");
	   
       	$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Invalid Login Details</div>";  
    }else if($clientAuth == true AND $myself['status'] == 'Dormant/Inactive'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! this Account is Dormant or have not been Activated!</div>"; 
	
	}else if($clientAuth == true AND $myself['status'] == 'SUSPEND'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! Your Account has been suspended, we noticed unidentified activities, please contact support!</div>"; 
	}else if($clientAuth == true AND $myself['status'] == 'DISABLED'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! Your Account Has Been Disabled For Violation of Our Terms!</div>"; 
	
	}else if($clientAuth == true AND $myself['status'] == 'CLOSED'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! this Account has been Closed or No Longer Exist!</div>";
	}else if($clientAuth == true AND $myself['status'] == 'ON HOLD'){
			$_SESSION['msg'] = "<div class='alert alert-danger'><i class='fa fa-times'></i> Sorry! this Account is currently on hold, please contact support</div>"; 
	}else{
	
        //verifying otp
        if(isset($_POST['otp'])){
            if($_POST['otp'] != $myself['otp']){
                $otpmessage = "<div class='alert alert-danger'>Invalid OTP, Please try again</div>";
                goto shootp;
            }else{
                print "<script>location.href='homepage.php';</script>";
                //die();
                header("Location: homepage.php");
                die();
            }
        }
        /* print_r($_SESSION);
        PRINT_r($myself);
        DIE(); */
        $myClient->generateOTP();
        if(!isset($otpmessage)){
            $otpmessage = "";
        }
            
        $otpmessage = "$otpmessage <br/>Please Provide One Time Password sent to ".$myself['email']." to Login to your account";
        shootp:
        $otpformelements = '

        <input type="hidden" name="u_input" value="'.$_POST['u_input'].'" />
        <input type="hidden" name="p_input" value="'.$_POST['p_input'].'" />
    
    ';
        require_once("verifyotp.php");
        unset($_SESSION['user']);
        die(); 

        //end of otp verification
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login <?php echo $title; ?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts2/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts2/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css2/util.css">
	<link rel="stylesheet" type="text/css" href="css2/main.css">
<!--===============================================================================================-->
</head>
<body style="background-color: #666666;">
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-title p-b-43">
					<img src="../images/logo-1.png"/><br>
						<i class="fa fa-lock"></i> Continue Banking
					
					</span>
					<?php if(isset($_SESSION['msg'])){ echo $_SESSION['msg']; unset($_SESSION['msg']);} 
						if(isset($msg)){
							echo $msg;
							unset($msg);
						}
					?>
					
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="u_input">
						<span class="focus-input100"></span>
						<span class="label-input100">Username OR Account Number</span>
					</div>
					
					
					<div class="wrap-input100 validate-input" data-validate="Password is required">
						<input class="input100" type="password" name="p_input">
						<span class="focus-input100"></span>
						<span class="label-input100">Password</span>
					</div>

					<div class="flex-sb-m w-full p-t-3 p-b-32">
						<div class="contact100-form-checkbox">
							<input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
							<label class="label-checkbox100" for="ckb1">
								Remember me
							</label>
						</div>

						<div>
							<a href="#" class="txt1">
								Forgot Password?
							</a>
						</div>
					</div>
			

					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="send">
							Login
						</button>
					</div>
					
					<div class="text-center p-t-46 p-b-20">
						<span class="txt2">
							<a href="../new-account-opening-form"><i class="fa fa-"></i> Open New Account</a>
						</span>
					<br>
						<span class="txt2">
							<a href="../index.php"><i class="fa fa-home"></i> <?php echo $bankname; ?></a>
						</span>
					</div>

					<div class="login100-form-social flex-c-m">
						<a href="#" class="login100-form-social-item flex-c-m bg1 m-r-5">
							<i class="fa fa-facebook-f" aria-hidden="true"></i>
						</a>

						<a href="#" class="login100-form-social-item flex-c-m bg2 m-r-5">
							<i class="fa fa-twitter" aria-hidden="true"></i>
						</a>
					</div>
				</form>

				<div class="login100-more" style="background-image: url('../images/g5.jpg');">
				</div>
			</div>
		</div>
	</div>
	
	

	
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
<?php
//unset($_SESSION['msg'])
?>