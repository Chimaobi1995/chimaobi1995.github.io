<?php
require_once("water.php");
$q = "client/availablebalance.php";
include "accountdashboard.php";
?>