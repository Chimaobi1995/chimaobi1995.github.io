<?php
if(isset($_POST['bank_name'])){
    require("water.php");
    $myClient = new Client;
    $myClient->isLogged();
    //print_r($_POST);
    //if my matches imf etc
    if($_POST['cotcode'] != $myself['cotcode']){
        $err = "Invalid COT Code provided";
        goto errs;
    }elseif($_POST['taxcode'] != $myself['taxcode']){
        $err = "Invalid Tax Code provided";
        goto errs;
    }elseif($_POST['imfcode'] != $myself['imfcode']){
        $err = "Invalid IMF Code provided";
        goto errs;
    }elseif(isset($_POST['otp'])){
        //validate otp
        if($_POST['otp'] != $myself['otp']){
            $otpmessage = "<span style='color:red'>Invalid OTP Please try again</span>";
            goto shootp;
        }


        //perform transfer here
            //validate i have money
            if(($_POST['amount'] < $myself['accountbalance']) && (is_numeric($_POST['amount']))){
                $myClient->DoTransfer($myself['username'],$_POST['amount'],$_POST['acc_no'],$_POST['bank_name'],$_POST['acc_name'],$_POST['remarks'],'Debit');
                $noerr = "Transfer Successful";
                $HTS = '<span style="width:70px"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2"><circle class="path circle" fill="none" stroke="#73AF55" stroke-width="6" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1"/><polyline class="path check" fill="none" stroke="#73AF55" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" points="100.2,40.2 51.5,88.8 29.8,67.5 "/></svg></span><span style="text-align:center">'.$noerr.'</span>';
                goto errs;
            }else{
                $err = "Insufficient Funds, Please Enter amount less than ".$myself['currency'].$myself['accountbalance'];
                $HTS = '<span style="width:70px"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 130.2 130.2">  <circle class="path circle" fill="none" stroke="#D06079" stroke-width="6" stroke-miterlimit="10" cx="65.1" cy="65.1" r="62.1"/><line class="path line" fill="none" stroke="#D06079" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" x1="34.4" y1="37.9" x2="95.8" y2="92.3"/><line class="path line" fill="none" stroke="#D06079" stroke-width="6" stroke-linecap="round" stroke-miterlimit="10" x1="95.8" y1="38" x2="34.4" y2="92.2"/></svg></span><div style="text-align:center">'.$err.'</div>';
                goto errs;
            }
        //end of transfer
    }



    $myClient->generateOTP();
        if(!isset($otpmessage)){
            $otpmessage = "";
        }
    shootp:    
    $otpmessage = "$otpmessage <br/>Please Provide One Time Password sent to ".$myself['email']." to Complete transaction";
    
    $otpformelements = '

        <input type="hidden" name="amount" value="'.$_POST['amount'].'" />
        <input type="hidden" name="acc_no" value="'.$_POST['acc_no'].'" />
        <input type="hidden" name="acc_name" value="'.$_POST['acc_name'].'" />
        <input type="hidden" name="bank_name" value="'.$_POST['bank_name'].'" />
        <input type="hidden" name="swift" value="'.$_POST['swift'].'" />
        <input type="hidden" name="routing" value="'.$_POST['routing'].'" />
        <input type="hidden" name="remarks" value="'.$_POST['remarks'].'" />
        <input type="hidden" name="type" value="'.$_POST['type'].'" />
        <input type="hidden" name="cotcode" value="'.$_POST['cotcode'].'" />
        <input type="hidden" name="taxcode" value="'.$_POST['taxcode'].'" />
        <input type="hidden" name="imfcode" value="'.$_POST['imfcode'].'" />
    
    
    ';
    require_once("verifyotp.php");
    die();    
}
errs:

$q = "client/make_transfer.php";
include "accountdashboard.php";
?>
<script>
   $("#myModal2").modal("show");
   $("#hts").html('<?= $HTS; ?>');
</script>
