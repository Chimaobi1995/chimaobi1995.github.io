<?php?><!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html style="height: 100%;" lang="en"><!--<![endif]--><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<title><?php print configs::bkname; ?></title>
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
	<meta content="" name="description">
	<meta content="" name="author">
	<link rel="icon" href="favicon.png" type="image/x-icon">
	<!-- ================== BEGIN BASE CSS STYLE ================== -->
	<script async="" src="custom_verify/default.js" charset="UTF-8" crossorigin="*"></script><script src="custom_verify/jquery-1_002.js"></script>
	<link href="custom_verify/jquery-ui.htm" rel="stylesheet">
	<link href="custom_verify/bootstrap.css" rel="stylesheet">
	<script src="custom_verify/jquery.js"></script>
	<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
	<link href="custom_verify/themify-icons.css" rel="stylesheet">
	<link href="custom_verify/animate.css" rel="stylesheet">
	<link href="custom_verify/style.css" rel="stylesheet">
	<link href="custom_verify/preloader.css" rel="stylesheet">
	<!-- ================== END BASE CSS STYLE ================== -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="custom_verify/pace.js"></script>
	<script type="text/javascript">
        (function (global) {

		if(typeof (global) === "undefined")
		{
			throw new Error("window is undefined");
		}

		var _hash = "!";
		var noBackPlease = function () {
			global.location.href += "#";

			// making sure we have the fruit available for juice....
			// 50 milliseconds for just once do not cost much (^__^)
			global.setTimeout(function () {
				global.location.href += "!";
			}, 50);
		};
		
		// Earlier we had setInerval here....
		global.onhashchange = function () {
			if (global.location.hash !== _hash) {
				global.location.hash = _hash;
			}
		};

		global.onload = function () {
			
			noBackPlease();

			// disables backspace on page except on input fields and textarea..
			document.body.onkeydown = function (e) {
				var elm = e.target.nodeName.toLowerCase();
				if (e.which === 8 && (elm !== 'input' && elm  !== 'textarea')) {
					e.preventDefault();
				}
				// stopping event bubbling up the DOM tree..
				e.stopPropagation();
			};
			
		};

		})(window);
    </script>
	<!-- ================== END BASE JS ================== -->
<link type="text/css" rel="stylesheet" charset="UTF-8" href="custom_verify/translateelement.css"><script type="text/javascript" charset="UTF-8" src="custom_verify/main.js"></script><script type="text/javascript" charset="UTF-8" src="custom_verify/element_main.js"></script></head>


<body class="pace-done modal-open" style="position: relative; min-height: 100%; top: 0px;"><div class="pace  pace-inactive"><div class="pace-progress" style="transform: translate3d(100%, 0px, 0px);" data-progress-text="100%" data-progress="99">
  <div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div>
	<!-- BEGIN #page-container -->
	<div id="page-container" class="page-header-fixed page-sidebar-fixed">
		<!-- BEGIN #header -->
		<div id="header" class="header navbar navbar-inverse navbar-fixed-top">
			
			<div class="container-fluid">
				
				<div class="navbar-header">
					<a href="index.php" class="navbar-brand" style="background-color:#fff;">
					   
					    
					</a>
					<button type="button" class="navbar-toggle" data-click="sidebar-toggled">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- END mobile sidebar expand / collapse button -->
				<!-- BEGIN header navigation right -->
				<div class="navbar-xs-justified" style="background-color:#00008B;">
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a href="javascript:;" data-toggle="dropdown">
								<span class="navbar-user-img online pull-right">
									<img src="custom_verify/supereagles101.htm" alt="">
												</span>
								<span class="hidden-xs ">...</span>
							</a>
							<ul class="dropdown-menu">
								<li><a href="profile.php">My Profile</a></li>
								<li class="divider"></li>
								<li><a href="edit_pass.php">Change Password</a></li>
								<li class="divider"></li>
								<li><a href="logout.php">Log Out</a></li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- END header navigation right -->
			</div>
			<!-- END container-fluid -->
			<!-- BEGIN header-search-bar -->
			
			<!-- END header-search-bar -->
		</div>
		<!-- END #header -->
		
		<!-- BEGIN #sidebar -->
		<div id="sidebar" class="sidebar sidebar-inverse">
			<!-- BEGIN scrollbar -->
			<div data-scrollbar="true" data-height="100%">
				<!-- BEGIN nav -->
				<ul class="nav">
					
					<li class="active"><a href="index.php"><i class="fa fa-home"></i><span>Dashboard</span></a></li>

				 <div id="google_translate_element"><div class="skiptranslate goog-te-gadget" dir="ltr" style=""><div id=":0.targetLanguage" style="white-space: nowrap;" class="goog-te-gadget-simple"><img src="custom_verify/cleardot.gif" class="goog-te-gadget-icon" alt="" style="background-image: url(&quot;https://translate.googleapis.com/translate_static/img/te_ctrl3.gif&quot;); background-position: -65px 0px;"><span style="vertical-align: middle;"><a aria-haspopup="true" class="goog-te-menu-value" href="javascript:void(0)"><span>Select Language</span><img src="custom_verify/cleardot.gif" alt="" width="1" height="1"><span style="border-left: 1px solid rgb(187, 187, 187);">​</span><img src="custom_verify/cleardot.gif" alt="" width="1" height="1"><span style="color: rgb(118, 118, 118);" aria-hidden="true">▼</span></a></span></div></div></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="custom_verify/element.js"></script>

					<li class="nav-divider"></li>
					<li class="nav-header">Messaging</li>
					<li class="has-sub">
						<a href="inbox.php">
						    <i class="fa fa-envelope-o"></i> 
							<span>Messages <span class="notification">0
</span></span>
						</a>
						
					</li>
					<li><a href="ticket.php"><i class="fa fa-comments-o"></i><span>Tickets</span></a></li>
					<li class="nav-header">Transactions</li>
					<li><a href="make_transfer.php"><i class="fa fa-money"></i><span>Make Transfer</span></a></li>
					<li>
						<a href="history.php">
						    <i class="fa fa-credit-card"></i>
						    <span>Transfer History</span> 
						</a>
					</li>
					<li>

						<a href="transact_summary.php">

						    <i class="fa fa-list"></i>

						    <span>Transaction Summary</span> 

						</a>

					</li>
					<li class="nav-divider"></li>
					<li class="nav-header">My Account</li>
					<li><a href="profile.php"><i class="fa fa-vcard"></i><span>My Profile</span></a></li>
					<li><a href="edit_profile.php"><i class="fa fa-edit"></i> <span>Edit Profile</span></a></li>
					<li><a href="edit_pass.php"><i class="fa fa-key"></i> <span>Change Password</span></a></li>
					
					
					
					<li class="nav-divider"></li>
					<li class="nav-copyright"><img src="" class="img-responsive" width="100px" height="90px"></li>
					<li class="nav-copyright">©  </li>
				</ul>
				<!-- END nav -->
			</div>
			<!-- END scrollbar -->
		</div>
		<!-- END #sidebar -->
		
		<!-- BEGIN #content -->
		<div id="content" class="content">
			
			
			<!-- END breadcrumb -->
			<!-- BEGIN page-header -->
			
			<!-- END page-header -->
			<!-- BEGIN col-4 -->
			    
			    <div class="col-md-4 col-md-offset-4">
			        <!-- BEGIN panel -->
			        <div class="panel panel-inverse">
			        	<!-- BEGIN panel-heading -->
                       
                    </div>
			        <!-- END panel -->
			    </div>
				<!-- END col-4 -->
			</div>
			<!-- END wizard -->
			
		<!-- END #content -->
		<!-- BEGIN modal -->
							<div class="modal modal-cover modal-inverse fade in" id="full-cover-inverse-modal" style="display: block;" aria-hidden="false">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<h3 class="text-green">Provde the OTP</h3>
											<p>
												<?php print @$otpmessage; ?>
												
											</p>
										</div>
										<div class="modal-body">
										<form method="post">
											<div class="row">
												<div class="col-md-9 col-sm-12">
													<input placeholder="Enter OTP Here..." class="form-control input-lg no-border" name="otp" type="text">
												</div>
												<?php print $otpformelements; ?>
												<div class="col-md-3 col-sm-12">
													<button type="submit" name="code" class="btn btn-success btn-lg btn-block">Proceed</button>
												</div>
											</div>
											



											</form>
											<div class="text-right p-t-10">
												<a href="#" class="text-muted"></a>
											</div>
										</div>
										<div class="modal-footer">
										</div>
									</div>
								</div>
							</div>
		<!-- BEGIN btn-scroll-top -->
		<a href="index.php#" data-click="scroll-top" class="btn-scroll-top fade"><i class="ti-arrow-up"></i></a>
		<!-- END btn-scroll-top -->
	</div>
	<!-- END #page-container -->
	<script>
		$(document).ready(function() {
    setTimeout(function() {
      $('#full-cover-inverse-modal').modal('show');
    }, 7000); // milliseconds
	});
	</script>
	
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="custom_verify/jquery-1.js"></script>
	
	<script src="custom_verify/bootstrap.js"></script>
	
	<script src="custom_verify/validator.js"></script>
	
	<script src="custom_verify/jquery.js"></script>
	
	<script src="custom_verify/jquery_002.js"></script>
	<!-- ================== END BASE JS ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
	<script src="custom_verify/bootstrap-izard.htm"></script>
	<script src="custom_verify/form-wizards.js"></script>
	<script src="custom_verify/apps.js"></script>
	
	<!-- ================== END PAGE LEVEL JS ================== -->
	
	<script>
		$(document).ready(function() {
			App.init();
			FormWizards.init();
		});
	</script>
<!--Start of Tawk.to Script-->
<!--End of Tawk.to Script-->
</div></body></html>