<?php
$q = "client/verify.php";
include "accountdashboard.php";
?>