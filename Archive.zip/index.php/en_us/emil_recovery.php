<?php
require_once "connect.php";
if(isset($_POST['email'])){
	if(empty($_POST['email'])){
		echo "empty";
	}else{
		$email = $_POST['email'];
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			echo "invaild_email";
		}else{
			$c = mysqli_query($conn, "SELECT * FROM pipul WHERE email = '$email'") or die(mysqli_error($conn));
			if(mysqli_num_rows($c)<1){
				echo "notfound";
			}else{
				
				$clientdata = mysqli_fetch_assoc($c);
				$name = $clientdata['firstname'];
				$username = $clientdata['username'];
				$password = $clientdata['password'];
				
				$to = $email;
				$subject = 'subject here';
				$headers = "From: support@randolphbrook.online\r\n";
				$headers .= "Reply-To: support@randolphbrook.online\r\n";
				$headers .= "MIME-Version: 1.0\r\n";
				$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
				$message = "
				<img src='https://www.randolphbrook.online/img/password_reset.png'/>
				Dear ".$name.",<br>
				
				Here is your login details as you have requested, you may wish to do change of password anytime from your login dashborad area when you have logged in.<br>
				
				Username: ".$username."<b>
				Password: ".$password." <br>
				
				<br>
				<pre>
				If you have receved this message in error, please kindly delete and report this message to us on support@randolphbrook.online or you can call us on +1 (856) 512-0567. thank you for choosing us and we choose you too.
				</pre>
				
				";
				 mail($to, $subject, $message, $headers);
 
				echo "sent";
				
			}
		}
		
	}
	
	
}