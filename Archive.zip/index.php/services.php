<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/services. Date: Mon, 14 Sep 2020 23:37:27 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="content" description="<?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants">
<title><?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants</title>
<link rel="apple-touch-icon" sizes="57x57" href="../assets/landing/images/fav-icon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/landing/images/fav-icon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/landing/images/fav-icon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/landing/images/fav-icon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/landing/images/fav-icon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/landing/images/fav-icon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/landing/images/fav-icon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/landing/images/fav-icon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/landing/images/fav-icon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/../assets/landing/images/fav-iconandroid-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/landing/images/fav-icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/landing/images/fav-icon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/landing/images/fav-icon/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/landing/images/fav-icon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/bootstrap/bootstrap.css" media="screen">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Alegreya:400,400italic,700,900,700italic,900italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="../assets/landing/fonts/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/fonts/flat-icon/flaticon.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/settings.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/layers.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/navigation.css">

<link rel="stylesheet" href="../assets/landing/css/owl.carousel.css">
<link rel="stylesheet" href="../assets/landing/css/owl.theme.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/jquery-css/jquery-ui.css">


<link rel="stylesheet" type="text/css" href="../assets/landing/css/custom/style.css">

<link type="text/css" rel="stylesheet" id="jssDefault" href="../assets/landing/css/custom/theme-2.css" />

<link rel="stylesheet" type="text/css" href="../assets/landing/css/responsive/responsive.css">
<link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/font-awesome.css">
</head>
<body class="home layout_changer">
<!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

<div class="body_wrapper">

<div id="loader-wrapper">
<div id="loader"></div>
</div>


<?php include "topmenu.php"; ?>
<?php include "main_menu.php"; ?>

<section class="inner_banner">
<div class="container">
<div class="banner-title">
<h1>Valuable Services</h1>
<span class="decor-equal"></span>
</div>
</div>
</section>


<section class="breadcrumb_sec">
<div class="container">
<div class="row">
<div class="col-lg-10 col-md-9 col-sm-6 col-xs-3">
<h5>Services</h5>
</div>
<div class="col-lg-2 col-md-3 col-sm-6 col-xs-9">
<ul>
<li><a href="index.html">Home</a></li>
<li class="dot"></li>
<li>Services</li>
</ul>
</div>
</div>
</div>
</section>


<section class="service_content container">
<div class="row top_row">
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
<div class="single_service_item">
<div class="service_icon transition3s">
<div class="icon_border">
<span class="icon flaticon-statistics"></span>
</div>
</div>
<div class="service_text">
<a href="investment_planning.html"><h5>Investment Planning</h5></a>
<p>Need to buy a house? an equipment? or that dream car, We have just the right investment plans for you.</p>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
<div class="single_service_item">
<div class="service_icon transition3s">
<div class="icon_border">
<span class="icon flaticon-money33"></span>
</div>
</div>
<div class="service_text">
<a href="childrens_planning.html"><h5>Secured Funding</h5></a>
<p>High level security to ensure your money is always safe. Get the best now.</p>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
<div class="single_service_item">
<div class="service_icon transition3s">
<div class="icon_border">
<span class="icon flaticon-museum34"></span>
</div>
</div>
<div class="service_text">
<a href="retirement_planning.html"><h5>Retirement Planning</h5></a>
<p>Retire to a most amazing life using our retirement policy plans, your future is secured and guaranteed.</p>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
<div class="single_service_item">
<div class="service_icon transition3s">
<div class="icon_border">
<span class="icon flaticon-money183"></span>
</div>
</div>
<div class="service_text">
<a href="insurance_planning.html"><h5>Insurance Planning</h5></a>
<p>Insurance planning is a critical component of a comprehensive financial plan that includes evaluating risks and determining the proper insurance coverage to mitigate those risks.</p>
</div>
</div>
</div>
</div>
<div class="row bottom_row">
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
<div class="single_service_item">
<div class="service_icon transition3s">
<div class="icon_border">
<span class="icon flaticon-payment7"></span>
</div>
</div>
<div class="service_text">
<a href="tax_planning.html"><h5>Tax Planning</h5></a>
<p>Tax planning is the analysis of a financial situation or plan from a tax perspective with the purpose to ensure tax efficiency.</p>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
<div class="single_service_item">
<div class="service_icon transition3s">
<div class="icon_border">
<span class="icon flaticon-gold1"></span>
</div>
</div>
<div class="service_text">
<a href="commodities_trading.html"><h5>Commodities Trading</h5></a>
<p>Dealing commodities is an old profession, dating back further than trading stocks and bonds. Ancient civilizations traded a wide array of commodities, from seashells to spices.</p>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
<div class="single_service_item">
<div class="service_icon transition3s">
<div class="icon_border">
<span class="icon flaticon-museum34"></span>
</div>
</div>
<div class="service_text">
<a href="mutual_funds.html"><h5>Mutual Funds</h5></a>
<p>An investment programme funded by shareholders that trades in diversified holdings and is professionally managed.</p>
</div>
</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
<div class="single_service_item">
<div class="service_icon transition3s">
<div class="icon_border">
<span class="icon flaticon-house118"></span>
</div>
</div>
<div class="service_text">
<a href="wealth_management.html"><h5>Wealth Management</h5></a>
<p>Wealth management is a high-level professional service that combines financial and investment advice.</p>
</div>
</div>
</div>
</div>
</section>


<?php include "footer.php"; ?>


<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="../assets/landing/js/jquery-2.1.4.js"></script>
<script src="../assets/landing/ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript" src="../assets/landing/js/bootstrap.min.js"></script>


<script type="text/javascript" src="../assets/landing/js/jQuery.style.switcher.min.js"></script>

<script src="../assets/landing/js/jquery.themepunch.tools.min.js"></script>
<script src="../assets/landing/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.navigation.min.js"></script>

<script src="../assets/landing/js/owl.carousel.min.js"></script>

<script src="../assets/landing/js/jquery.appear.js"></script>

<script type="text/javascript" src="../assets/landing/js/jquery-ui.min.js"></script>

<script src="../assets/landing/js/jquery.countTo.js"></script>
<script src="../assets/landing/js/validate.js"></script>
<script type="text/javascript" src="../assets/landing/js/main.js"></script>
</div> 
</body>

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/services. Date: Mon, 14 Sep 2020 23:37:27 GMT -->
</html>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5de1747543b1d1fce83/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
