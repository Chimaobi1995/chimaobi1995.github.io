<?php
error_reporting(0);
require_once "config.php";
if(isset($_POST['send'])){
if(empty($_POST['name']) OR empty($_POST['email']) OR empty($_POST['phone']) OR empty($_POST['requesttype']) OR empty($_POST['message'])){
	$msg = "<div class='alert alert-danger'>Please enter all required information</div>";
}else{

		$name = $_POST['name'];	
		$phone = $_POST['phone'];	
		$mail = $_POST['email'];	
		$type = $_POST['requesttype'];	
		$mess = $_POST['message'];	
	
		$to = $myemail;
		$subject = 'Consultation Form';
		$headers = "From: ".$myemail."\r\n";
		$headers .= "Reply-To: ".$mail."\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
		$message = "Inquire form ".$name."<br>
		
		<b>Name:</b> ".$name."<br>
		<b>Phone:</b> ".$phone."<br>
		<b>Email:</b> ".$mail."<br>
		<b>Type:</b> ".$type."<br>
		<b>Message:</b> ".$mess."";
		if(mail($to, $subject, $message, $headers)){
			$msg = "<div class='alert alert-success'>We have Receved Required</div>";
		}else{
			$msg = "<div class='alert alert-danger'>Oosp, unable to send message, check network connction and try again</div>";
		}
		
}

}
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/index. Date: Mon, 14 Sep 2020 23:39:39 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="content" description="<?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants">
<title><?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants</title>

<link rel="apple-touch-icon" sizes="57x57" href="../assets/landing/images/fav-icon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/landing/images/fav-icon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/landing/images/fav-icon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/landing/images/fav-icon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/landing/images/fav-icon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/landing/images/fav-icon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/landing/images/fav-icon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/landing/images/fav-icon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/landing/images/fav-icon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/../assets/landing/images/fav-iconandroid-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/landing/images/fav-icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/landing/images/fav-icon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/landing/images/fav-icon/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/landing/images/fav-icon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">


<link rel="stylesheet" type="text/css" href="../assets/landing/css/bootstrap/bootstrap.css" media="screen">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Alegreya:400,400italic,700,900,700italic,900italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="../assets/landing/fonts/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/fonts/flat-icon/flaticon.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/settings.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/layers.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/navigation.css">

<link rel="stylesheet" href="../assets/landing/css/owl.carousel.css">
<link rel="stylesheet" href="../assets/landing/css/owl.theme.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/jquery-css/jquery-ui.css">


<link rel="stylesheet" type="text/css" href="../assets/landing/css/custom/style.css">

<link type="text/css" rel="stylesheet" id="jssDefault" href="../assets/landing/css/custom/theme-2.css" />

<link rel="stylesheet" type="text/css" href="../assets/landing/css/responsive/responsive.css">
<link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/font-awesome.css">
</head>
<body class="home layout_changer">


<!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

<div class="body_wrapper">

<div id="loader-wrapper">
<div id="loader"></div>
</div>

<?php include "topmenu.php"; ?>
<?php include "main_menu.php"; ?>

<section class="banner">
<div class="rev_slider_wrapper">
<div id="main_slider" class="rev_slider" data-version="5.0">
<ul>
<li data-transition="fade" class="slide_show"> 
<img src="../assets/landing/images/home/banner.jpg" alt="image">
<div class="main_heading tp-caption tp-resizeme title_container" data-x="['left','left','left','left']" data-hoffset="['0','80','80','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-153','-163','-183','-173']" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="1300" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<h6><?php echo $title; ?> financial Solution </h6>
<span class="decor_default" style="margin-top:19px;"></span>
</div>
<div class="tp-caption tp-resizeme" data-x="['left','left','left','left']" data-hoffset="['0','80','80','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-51','-53','-63','-75']" data-transform_idle="o:1;" data-whitespace="nowrap" data-transform_in="x:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="1500" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<h1>Trusted Banker and Financial <br>Consultants</h1>
</div>
<div class="tp-caption tp-resizeme banner_heading" data-x="['left','left','left','left']" data-hoffset="['0','80','80','0']" data-y="['middle','middle','middle','middle']" data-voffset="['64','64','54','24']" data-transform_idle="o:1;" data-transform_in="y:bottom;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-whitespace="nowrap" data-start="1150" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<p>We proud ourself to providing great Services and support to Our Customer</p>
</div>
<div class="tp-caption tp-resizeme" data-x="['left','left','left','left']" data-hoffset="['0','80','80','0']" data-y="['middle','middle','middle','middle']" data-voffset="['144','144','134','114']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1200" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<a href="contact" class="consultation_button transition3s hvr-sweep-to-right-white">Contact Us</a>
</div>
<div class="tp-caption tp-resizeme" data-x="['left','left','left','left']" data-hoffset="['190','270','280','190']" data-y="['middle','middle','middle','middle']" data-voffset="['144','144','134','114']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1200" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<a href="about_us" class="learn_more transition3s hvr-sweep-to-right-white">Learn More</a>
</div>
</li> 
<li data-transition="slideoverup" class="slide_show slide_2"> 
<img src="../assets/landing/images/home/banner2.jpg" alt="image">
<div class="main_heading tp-caption tp-resizeme logo" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-150','-163','-163','-163']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1300" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<span class="logo"></span>
</div>
<div class="main_heading tp-caption tp-resizeme title_container" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-75','-75','-75','-75']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1300" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<h6><?php echo $title; ?> financial Solution Consultation</h6>
<span class="decor-equal"></span>
</div>
<div class="tp-caption tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['20','20','20','20']" data-transform_idle="o:1;" data-transform_in="x:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1500" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<h1>Get Free Consultation <br> From Our Experts</h1>
</div>
<div class="tp-caption tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['-96','-96','-96','-96']" data-y="['middle','middle','middle','middle']" data-voffset="['166','166','166','156']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1200" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<a href="contact" class="consultation_button transition3s hvr-sweep-to-right-white">Consultation</a>
</div>
<div class="tp-caption tp-resizeme" data-x="['center','center','center','center']" data-hoffset="['95','95','95','95']" data-y="['middle','middle','middle','middle']" data-voffset="['166','166','166','156']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1200" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<a href="about-us" class="learn_more transition3s hvr-sweep-to-right-white">Learn More</a>
</div>
</li> 
<li data-transition="slideright" class="slide_show slide_3"> 
<img src="../assets/landing/images/home/banner3.jpg" alt="image">
<div class="main_heading tp-caption tp-resizeme title_container" data-x="['right','right','right','right']" data-hoffset="['250','335','335','174']" data-y="['middle','middle','middle','middle']" data-voffset="['-150','-150','-160','-150']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1300" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<h6><?php echo $title; ?> financial Solution</h6>
<span class="decor_default" style="margin-top:19px;"></span>
</div>
<div class="tp-caption tp-resizeme" data-x="['right','right','right','right']" data-hoffset="['0','85','85','44']" data-y="['middle','middle','middle','middle']" data-voffset="['-50','-50','-60','-50']" data-transform_idle="o:1;" data-transform_in="x:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1400" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<h1>Lets Start your Future<br>Financial Plan </h1>
</div>
<div class="tp-caption tp-resizeme banner_heading" data-x="['right','right','right','right']" data-hoffset="['30','115','115','-12']" data-y="['middle','middle','middle','middle']" data-voffset="['68','68','58','68']" data-transform_idle="o:1;" data-transform_in="y:bottom;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-whitespace="nowrap" data-start="1500" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<p>Secure your financial future, contact us for rich retirement plans</p>
</div>
<div class="tp-caption tp-resizeme" data-x="['right','right','right','right']" data-hoffset="['405','490','490','320']" data-y="['middle','middle','middle','middle']" data-voffset="['144','144','134','144']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1700" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<a href="contact" class="consultation_button transition3s hvr-sweep-to-right-white">Consultation</a>
</div>
<div class="tp-caption tp-resizeme" data-x="['right','right','right','right']" data-hoffset="['205','290','290','120']" data-y="['middle','middle','middle','middle']" data-voffset="['144','144','134','144']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:2000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-whitespace="nowrap" data-start="1700" data-splitin="none" data-splitout="none" data-responsive_offset="on">
<a href="about_us" class="learn_more transition3s hvr-sweep-to-right-white">Learn More</a>
</div>
</li> 
</ul>
</div>
</div>
</section>


<section class="about_finance_press">
<div class="container">
<div class="row">
<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 finance_text">
<div class="title_container">
<h4>About <?php echo $title; ?> financial Solution</h4>
<span class="decor_default"></span>
</div>
<div class="some_speach">
<h3>We Got You Covered Always. We Know How Important Keeping Your Money Safe Is To You. <span></span> <?php echo $title; ?> financial Solution<sup>”</sup></h3>
<p><?php echo $title; ?> financial Solution has grown from a credit union called Brent Shrine Credit Union which was first formed in 1979 to serve people living in the US or working in or outside the London Borough of Brent. We changed our name to <?php echo $title; ?> financial Solution and extended our common bond nationally to encompass the British South Asian diaspora.
Since then our common bond has extended a number of times to include members and supporters of a very wide range of organisations and associations across the UK. Recently we have extended membership to supporters of the financial education charity: Financial Education and Awareness.</p>
<a href="contact" class="transition3s">Get Your Free Financial Analysis</a>
</div>
</div>
<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
<div class="finance_fact_item row">
<div class="icon_holder col-lg-2 col-md-2 col-sm-3 col-xs-2">
<span class="icon flaticon-employee4"></span>
</div>
<div class="finance_fact_name col-lg-7 col-md-7 col-sm-7 col-xs-6">
<h6>Advisors</h6>
<span>100% Customer Satisfaction</span>
</div>
<span class="col-lg-3 col-md-3 col-sm-2 col-xs-4 counter timer" data-from="5" data-to="230" data-speed="5000" data-refresh-interval="50"></span>
</div>
<div class="finance_fact_item row">
<div class="icon_holder col-lg-2 col-md-2 col-sm-3 col-xs-2">
<span class="icon flaticon-price8"></span>
</div>
<div class="finance_fact_name col-lg-7 col-md-7 col-sm-7 col-xs-6">
<h6>Loan Processed</h6>
<span>Over 15, 000 Loans granted </span>
</div>
<span class="col-lg-3 col-md-3 col-sm-2 col-xs-4 counter timer" data-from="10" data-to="846" data-speed="5000" data-refresh-interval="50"></span>
</div>
<div class="finance_fact_item row">
<div class="icon_holder col-lg-2 col-md-2 col-sm-3 col-xs-2">
<span class="icon flaticon-location71"></span>
</div>
<div class="finance_fact_name col-lg-7 col-md-7 col-sm-7 col-xs-6">
<h6>Locations</h6>
<span>Find Us All Over The World</span>
</div>
<span class="col-lg-3 col-md-3 col-sm-2 col-xs-4 counter timer" data-from="5" data-to="100" data-speed="5000" data-refresh-interval="50"></span>
</div>
</div>
</div>
</div>
</section>


<section class="best_service" id="best-services">
<div class="container">
<div class="row">
<div class="title_container col-lg-12">
<h4>Experts Services That You Need</h4>
<span class="decor_default"></span>
</div>
</div>
<div class="owl_slider row">
<div id="owl-demo">
<div class="item">
<div class="single_service_item">
<div class="transition3s">
<div class="icon_border">
<img src="../assets/landing/images/1.jpg" style="width:170px"/>
</div>
</div>
<div class="service_text">

<a href="investment_planning"><h5>Investment Planning</h5></a>
<p>Need to buy a house? an equipment? or that dream car, We have just the right investment plans for you.</p>
</div> 
</div> 
</div> 
<div class="item">
<div class="single_service_item">
<div class="transition3s">
<div class="icon_border">
<img src="../assets/landing/images/2.jpg" style="width:170px"/>
</div>
</div>
<div class="service_text">
<a href="home/childrens_planning"><h5>Insurance cover</h5></a>
<p>We provide comprehensive financial plan that evaluates risks and determine the proper insurance coverage to mitigate those risks.</p>
</div> 
</div> 
</div> 
<div class="item">
<div class="single_service_item">
<div class="transition3s">
<div class="icon_border">
<img src="../assets/landing/images/3.png" style="width:170px"/>
</div>
</div>
<div class="service_text">
<a href="en_us/"><h5>Private Banking</h5></a>
<p>Secured Online banking. Private and Commercial banking services you can trust.</p>
</div> 
</div> 
</div> 
<div class="item">
<div class="single_service_item">
<div class="transition3s">
<div class="icon_border">
<img src="../assets/landing/images/4.jpeg" style="width:170px"/>
</div>
</div>
<div class="service_text">
<a href="retirement_planning"><h5>Retirement Planning</h5></a>
<p>Secure an amazing future for yourself and get the best out of life after retirement.</p>
</div> 
</div> 
</div> 
<div class="item">
<div class="single_service_item">
<div class="transition3s">
<div class="icon_border">
<img src="../assets/landing/images/5.jpg" style="width:170px"/>
</div>
</div>
<div class="service_text">
<a href="tax_planning"><h5>Tax Planning</h5></a>
<p>Tax planning is the analysis of a financial situation or plan from a tax perspective with the purpose to ensure tax efficiency.</p>
</div> 
</div> 
</div> 
<div class="item">
<div class="single_service_item">
<div class="transition3s">
<div class="icon_border">
<img src="../assets/landing/images/6.jpg" style="width:170px"/>
</div>
</div>
<div class="service_text">
<a href="mutual_funds"><h5>Secured Funding</h5></a>
<p>High level security to ensure your money is always safe. Get the best now.</p>
</div> 
</div> 
</div> 
<div class="item">
<div class="single_service_item">
<div class="transition3s">
<div class="icon_border">
<img src="../assets/landing/images/7.png" style="width:170px"/>
</div>
</div>
<div class="service_text">
<a href="commodities_trading"><h5>Commodity Trading</h5></a>
<p>Dealing commodities is an old profession, dating back further than trading stocks and bonds. Ancient civilizations traded a wide array of commodities, from seashells to spices.</p>
</div> 
</div> 
</div> 
<div class="item">
<div class="single_service_item">
<div class="transition3s">
<div class="icon_border">
<img src="../assets/landing/images/8.png" style="width:170px"/>
</div>
</div>
<div class="service_text">
<a href="wealth_management"><h5>Wealth Management</h5></a>
<p>Wealth management is a high-level professional service that combines financial and investment advice</p>
</div> 
</div> 
</div> 
</div> 
<div class="customNavigation">
<a class="prev"><i class="fa fa-angle-left"></i></a>
<a class="next"><i class="fa fa-angle-right"></i></a>
</div>
</div> 
</div>
</section>


<section class="section_bg">
<div class="container">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 testimonial">
<div class="img_holder">
<img src="../assets/landing/images/home/test-bg.jpg" alt="images">
<div class="overlay"></div>
</div>
<div class="slider_container">
<div id="testimonial-slider" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#testimonial-slider" data-slide-to="0" class="active"></li>
<li data-target="#testimonial-slider" data-slide-to="1"></li>
<li data-target="#testimonial-slider" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span class="icon flaticon-quotes3"></span>
<p class="speach"><?php echo $title; ?> financial Solution got me out of a debt-trap. They helped me pay off expensive short term debts and credit cards and understand how to borrow responsibly..</p>
<div class="client_name">
<h6>Mary Christiona</h6>
<span>Marketing Manager @ VK Ltd.</span>
</div>
</div>
<div class="item">
<span class="icon flaticon-quotes3"></span>
<p class="speach">Online banking has never been so effortlessly seamless. It’s as easy as tapping and sending.</p>
<div class="client_name">
<h6>Henry Jaden</h6>
<span>Investment Expert.</span>
</div>
</div>
<div class="item">
<span class="icon flaticon-quotes3"></span>
<p class="speach">They provide expert services and has a rich set of very experienced financial advisors.</p>
<div class="client_name">
<h6>Tom Phils</h6>
<span>Trader.</span>
</div>
</div>
</div> 
</div> 
</div> 
</div>
<div class="col-lg-5 col-lg-offset-1 col-md-6 col-sm-12 col-xs-12 people_choose_us">
<div class="title_container">
<h4>Why People Choose Us</h4>
<span class="decor_default"></span>
</div>
<div class="row choose_category"> 
<div class="col-lg-1 col-md-1 col-sm-1 col-xs-2 icon-holder">
<span class="icon flaticon-speed2"></span>
<i class="fa fa-angle-down"></i>
</div>
<div class="col-lg-11 col-md-11 col-sm-11 col-xs-10 text_holder">
<h5>24 Hours Support</h5>
<p>We are always up and ready to attend to your every needs and questions.</p>
</div>
</div>
<div class="row choose_category"> 
<div class="col-lg-1 col-md-1 col-sm-1 col-xs-2 icon-holder">
<span class="icon flaticon-house118"></span>
<i class="fa fa-angle-down"></i>
</div>
<div class="col-lg-11 col-md-11 col-sm-11 col-xs-10 text_holder">
<h5>Secured Banking</h5>
<p>Your Money can't be safer anywhere else.</p>
</div>
</div>
<div class="row choose_category">
<div class="col-lg-1 col-md-1 col-sm-1 col-xs-2 icon-holder">
<span class="icon flaticon-tasks2"></span>
</div>
<div class="col-lg-11 col-md-11 col-sm-11 col-xs-10 text_holder">
<h5>Information Sourcing</h5>
<p>Keeping you up to date with all trends around the global market.</p>
</div>
</div>
</div> 
</div> 
</div> 
</section>


<section class="faq_gallery_sec">
<div class="container">
<div class="row">
<div class="col-lg-6 col-md-6 faq_sec">
<div class="title_container">
<h4>Frequently Asked Questions</h4>
<span class="decor_default"></span>
</div>
<div class="panel-group" id="accordion">
<div class="panel panel-default">
<a data-toggle="collapse" data-parent="#accordion" href="index.html#collapse1">
<div class="panel-heading">
<h5 class="panel-title">What is <?php echo $title; ?> financial Solution</h5>
</div>
</a>
<div id="collapse1" class="panel-collapse collapse">
<div class="panel-body">
<p>Three credit unions, one each from England, Scotland and Wales, have cooperated together to form the Platinum Trust Bank Network. This UK-wide credit union network pools know-how and resources to better serve their members and provide first class service and competitive savings and loans products.</p>
</div>
</div>
</div>
<div class="panel panel-default">
<a data-toggle="collapse" data-parent="#accordion" href="index.html#collapse2">
<div class="panel-heading">
<h5 class="panel-title">What is Credit Union?</h5>
</div>
</a>
<div id="collapse2" class="panel-collapse collapse in">
<div class="panel-body">
<p>Credit unions are member-owned, not-for-profit financial cooperatives that provide savings, loans and other financial services to their members.<br>
<hr>
Credit union membership is based on a common bond, a linkage shared by savers and borrowers who belong to a particular community, organisation, religion or place of employment. Credit unions pool their members’ savings to finance loans rather than rely on outside capital.
<br>
Members benefit from higher returns on savings, lower rates on loans and no hidden fees.</p>
</div>
</div>
</div>
<div class="panel panel-default">
<a data-toggle="collapse" data-parent="#accordion" href="index.html#collapse3">
<div class="panel-heading">
<h5 class="panel-title">How can I join?</h5>
</div>
</a>
<div id="collapse3" class="panel-collapse collapse">
<div class="panel-body">
<p>As a network of Credit Unions, we can extend eligibility throughout England, Scotland and Wales. The members of a wide variety of organisations, employers, clubs and associations are automatically eligible to join one of our networked credit unions.<br>
<hr>
<?php echo $title; ?> financial Solution has grown out of a credit union called Brent Shrine Credit Union which was first formed in 1979 to serve people living or working in the London Borough of Brent. We changed our name to <?php echo $title; ?> financial Solution and extended our common bond nationally to encompass the British South Asian diaspora.<br>
<hr>
Since then our common bond has extended a number of times to include members and supporters of a very wide range of organisations and associations across the UK. Recently we have extended membership to supporters of the financial education charity: Financial Education and Awareness. A full list of these associations is available from the credit union.<br>
<hr>
<?php echo $title; ?> financial Solution Wales’ common bond allows any individual who resides or is employed in the locality of Wales to join provided that they do not live in Cardiff and the Vale.<br>
Request Free Members <a href="../cdn-cgi/l/email-protection.html#2d5e585d5d425f596d5e594c43494c5f494b44434c434e484e425f5d034e4240">HERE</a>
</p>
</div>
</div>
</div>
<div class="panel panel-default">
<a data-toggle="collapse" data-parent="#accordion" href="index.html#collapse4">
<div class="panel-heading">
<h5 class="panel-title">What is a Common Bond?</h5>
</div>
</a>
<div id="collapse4" class="panel-collapse collapse">
<div class="panel-body">
<p>The ‘bond’ or association between members constitutes a credit unions ‘common bond’. These bonds can be several and varied including where people live, work and clubs and associations to which they belong.</p>
</div>
</div>
</div>
<div class="panel panel-default">
<a data-toggle="collapse" data-parent="#accordion" href="index.html#collapse5">
<div class="panel-heading">
<h5 class="panel-title">How can I Apply?</h5>
</div>
</a>
<div id="collapse5" class="panel-collapse collapse">
<div class="panel-body">
<p>Opening an account with any of our credit unions is is easy. Send a mail to <a href="contact" class="__cf_email__" data-cfemail="6a020f061a0e0f19012a191e0b040e0b180e0c03040b04090f0905181a44090507">[email&#160;protected]</a>, our support team will walk you through the very easy process.
You will sign the Account Opening Agreement online as part of this process and receive a copy of the signed agreement in an email for your records..</p>
</div>
</div>
</div>
</div> 
</div>
<div class="col-lg-6 col-md-6 gallery_sec">
<div class="transform_img_holder gallery_img">
<img class="img-responsive" src="../assets/landing/images/home/1.jpg" alt="images">
<div class="overlay"></div>
</div>
<div class="transform_img_holder gallery_img">
<img class="img-responsive" src="../assets/landing/images/home/2.jpg" alt="images">
<div class="overlay"></div>
</div>
<div class="transform_img_holder gallery_img">
<img class="img-responsive" src="../assets/landing/images/home/3.jpg" alt="images">
<div class="overlay"></div>
</div>
<div class="transform_img_holder gallery_img">
<img class="img-responsive" src="../assets/landing/images/home/4.jpg" alt="images">
<div class="overlay"></div>
</div>
<div class="transform_img_holder gallery_img">
<img class="img-responsive" src="../assets/landing/images/home/5.jpg" alt="images">
<div class="overlay"></div>
</div>
</div>
</div>
</div>
</section>


<section class="parallax">
<div class="overlay"></div>
<div class="container">
<div class="row">
<div class="col-lg-9 col-md-9 col-sm-12 text_holder">
<h3><?php echo $title; ?> financial Solution Offers Secured Online Banking Services. Get Expert Financial Service</h3>
</div>
<div class="col-lg-3 col-md-3 col-sm-12 button">
<a href="contact" class="hvr-sweep-to-rightB">Get Free Consultation</a>
</div>
</div>
</div>
</section>


<section class="stay_consultation">
<div class="container">
<div class="row">
<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 stay_with_finance">
<img src="../assets/landing/images/home/stay-bg.jpg" alt="images">
<div class="text_container">
<span class="logo"></span>
<h4>Why Save with <?php echo $title; ?> financial Solution?</h4>
<p>
Your savings will be secure and ethical. Credit Unions use their savings to lend to their members. We don’t have shareholders. We are a financial co-operative: an organisation owned by its members, for the benefit of its members. Competitive savings rates We strive to provide our members with competitive rates on their savings. Our fixed term savings bonds are popular and can become quickly oversubscribed. So keep a look out for new offers.</p>
<a href="contact" class="button-main hvr-sweep-to-rightB buy_theme">Reach Us</a>
</div>
</div>
<div class="col-lg-7 col-md-7 col-md-12 col-xs-12 consultation">
<div class="title_container">
<h4>Request a Free Consultation</h4>
<?php if(isset($msg)){ echo $msg; unset($msg); } ?>
<span class="decor_default"></span>
</div>
<form method="post" class="submit">
<div class="input-group">
<div class="single_form">
<input type="text" name="name" class="form-control" placeholder="Full Name *">
</div>

<div class="single_form">
<input type="text" name="email" name="email" placeholder="Email">
<input type="text" name="phone" class="left_input_fix" placeholder="Phone *">
</div>
<div class="single_form">
<select class="selectmenu" name="requesttype">
<option selected="selected">Private Banking</option>
<option>Private Banking</option>
<option>Free Consultation</option>
<option>Private Banking</option>
</select>
</div> 

<textarea placeholder="Special Request..." name="message"></textarea>
</div>
<button type="submit" class="button-main hvr-sweep-to-rightB submit_now" name="send">Submit now</button>
</form>
</div>
</div>
</div>
</section>


<section class="latest_news">
<div class="container">
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
<div class="single_news">
<div class="img_holder">
<img class="img-responsive" src="../assets/landing/images/use.jpg" alt="images">
<div class="hvr-sweep-to-bottom"></div>
<div class="icon_holder transition3s">
<a href="index.html#"><i class="fa fa-link"></i></a>
</div>
</div>
<div class="post_meta">
<ul>
<li><a href="index.html#"><i class="fa fa-user"></i> Posted By Jimmy </a></li>
<li><a href="index.html#"><i class="fa fa-calendar"></i> 21st Aug 2018</a></li>
</ul>
<div class="title_container">
<h3>Fed Chair Powell calls case ‘strong’ for more interest rate hikes</h3>
<span class="decor_default"></span>
</div>
<p>Citing robust growth and a generational low in unemployment, Federal Reserve Chairman Jerome Powell emphasized the central bank’s commitment to further interest rates in a speech Wednesday.
Economic gains are negating the need for crisis-era monetary policy, the Fed leader told a European Central Bank forum.</p>
<!--a href="index.html#" target="_blank" class="read_more transition3s">Read More <i class="fa fa-caret-right"></i></a-->
</div>
</div> 
</div>
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
<div class="single_news">
<div class="img_holder">
<img class="img-responsive" src="../assets/landing/images/stock.jpg" alt="images">
<div class="hvr-sweep-to-bottom"></div>
<div class="icon_holder transition3s">
<a href="index.html#"><i class="fa fa-link"></i></a>
</div>
</div>
<div class="post_meta">
<ul>
<li><a href="index.html#"><i class="fa fa-user"></i> Posted By Mosses </a></li>
<li><a href="index.html#"><i class="fa fa-calendar"></i> 17st Nov 2020</a></li>
</ul>
<div class="title_container">
<h3>There is a ‘much bigger issue’ for the market than trade: Analyst </h3>
<span class="decor_default"></span>
</div>
<p>There is a “much bigger issue” for the market than concerns about trade, investing expert Richard Bernstein told CNBC on Tuesday.
In fact, over the last three to four months, almost every sizeable market sell-off has come from pro-inflation policies out of Washington, D.C., the CEO and chief investment officer of Richard Bernstein Advisors said.</p>
<!--a href="index" target="_blank" class="read_more transition3s">Read More <i class="fa fa-caret-right"></i></a-->
</div>
</div> 
</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
<div class="news_aside">
<div class="aside_item">
<div class="overlay"></div>
<div class="text">
<h3>Wealth</h3>
<span><?php echo $title; ?> financial Solution wealth management at its best.</span>
</div>
</div> 
<div class="aside_item">
<div class="overlay"></div>
<div class="text">
<h3>Account</h3>
<span>Personal Online and Private Banking with <?php echo $title; ?> financial Solution.</span>
</div>
</div> 
<div class="aside_item">
<div class="overlay"></div>
<div class="text">
<h3>Payment</h3>
<span>Easy transfer of funds between local and foreign accounts.</span>
</div>
</div> 
<div class="aside_item">
<div class="overlay"></div>
<div class="text">
<h3>Commodities</h3>
<span>Real time stock market analysis on the go.</span>
</div>
</div> 
</div> 
</div>
</div>
</div>
</section>


<div class="our_partners">
<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12">
<div>
<ul id="owl-demo2">
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-1.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-2.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-3.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-4.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-5.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-1.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-2.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-3.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-4.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-5.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-1.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-2.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-3.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-4.png" alt="logo"></a></li>
<li class="item"><a href="#"><img src="../assets/landing/images/home/icon-5.png" alt="logo"></a></li>
</ul>
</div>
</div>
</div>
</div>
</div>


<?php include "footer.php";?>


<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="../assets/landing/js/jquery-2.1.4.js"></script>
<script src="../assets/landing/ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript" src="../assets/landing/js/bootstrap.min.js"></script>


<script type="text/javascript" src="../assets/landing/js/jQuery.style.switcher.min.js"></script>

<script src="../assets/landing/js/jquery.themepunch.tools.min.js"></script>
<script src="../assets/landing/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.navigation.min.js"></script>

<script src="../assets/landing/js/owl.carousel.min.js"></script>

<script src="../assets/landing/js/jquery.appear.js"></script>

<script type="text/javascript" src="../assets/landing/js/jquery-ui.min.js"></script>

<script src="../assets/landing/js/jquery.countTo.js"></script>
<script src="../assets/landing/js/validate.js"></script>
<script type="text/javascript" src="../assets/landing/js/main.js"></script>
</div> 
</body>

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/index. Date: Mon, 14 Sep 2020 23:39:39 GMT -->
</html>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5de1747543b1d1fce83/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
//history.go(0);
</script>
