<?php
require "configs.php";
$conn = mysqli_connect(configs::server102, configs::user102, configs::pass102, configs::db102) or die (mysqli_connect_error());
class sanitize{
    public function clean($x){
                if (get_magic_quotes_gpc())
                    {
                        $x=stripslashes($x);
                    }
                return $GLOBALS['conn']->real_escape_string($x);
    }
    public function filename($x){
        $x = str_replace(".shtml","",$x);
        return str_replace(".php","",$x);
    }
}
class Manager{
    public function __construct(){
            if(session_id()==''){
                    session_start();
                }
    }
    public function auth($username, $password){
            if(session_id()==''){
                session_start();
                }
            $conn = $GLOBALS['conn'];
            $salt = $this->reSalt($password);
            $g = "SELECT * FROM manager WHERE email='$username' AND pass = '$password' AND salt = '$salt'";
            //print $g;
            //die($g);
            $getam = mysqli_query($conn,$g) or die(mysqli_error($conn));
            if(mysqli_num_rows($getam)<1){
                //header("Location: control.php");
                return "invalid login or expired license";
            }else{
                $ry = mysqli_fetch_array($getam);
                $_SESSION['manager'] = $ry['id'];
                return true;
                //header("Location: master.php");
            }
        
    }
    private function reAuth($manager){
        $conn = $GLOBALS['conn'];
        $g = "SELECT * FROM manager WHERE id='$manager'";
        $getam = mysqli_query($conn,$g) or die(mysqli_error($conn));
        if(mysqli_num_rows($getam)<1){
            return $this->logout("Session Expired");
        }else{
            $myData = mysqli_fetch_assoc($getam);
            return $myData;
        } 
    }
    public function isLogged(){
        if(session_id()==''){
            session_start();
            }
            if(isset($_SESSION['manager'])){
            $sesuser=$_SESSION['manager'];
           $this->reAuth($sesuser);
          // $_SESSION['msg'] = "Logged IN";
            return $sesuser;
            }else{
               $this->logout("Session Expired");
              //print "logout";
            }
    }
    private function reSalt($pass){
        //will modify resalt method to interprete salt
        return $pass;
    }
    public function logout($x="Logged out"){
        if(session_id()==''){
            session_start();
            }
        unset($_SESSION['manager']);
        $_SESSION['msg'] = $x;
        header("Location: ../index.php");
    }
}
class AdminTools{
    public function getUsernames($sortby="registrationdate", $limit=""){
        $conn = $GLOBALS['conn'];
        $sortby = sanitize::clean($sortby);
        $container = array();
        $m = mysqli_query($conn,"SELECT username FROM pipul ORDER BY $sortby DESC") or die(mysqli_error($conn));
        while($ma=mysqli_fetch_assoc($m)){
            $container[] = $ma['username'];
        }
        return $container;
    }
    public function getUsers($status="all",$sortby="registrationdate", $limit=""){
        $conn = $GLOBALS['conn'];
        if($status == "all"){
            $jar = "";
        }elseif($status=="pending"){
            $jar = "WHERE NOT status = 'active' ";
        }else{
            $lor = sanitize::clean($status);
            $jar = "WHERE status = '$lor' ";
        }
        $sortby = sanitize::clean($sortby);
        $container = array();
        $m = mysqli_query($conn,"SELECT * FROM pipul $jar ORDER BY $sortby DESC") or die(mysqli_error($conn));
        while($ma=mysqli_fetch_assoc($m)){
            $container[] = $ma;
        }
        return $container;
    }
    public function fetchUser($id){
        $conn = $GLOBALS['conn'];
        $id = sanitize::clean($id);
        $container = array();
        $m = mysqli_query($conn,"SELECT * FROM pipul WHERE aid = '$id' OR username = '$id' LIMIT 1") or die(mysqli_error($conn));
        if(mysqli_num_rows($m)>0){
        return mysqli_fetch_assoc($m);
        }else{
            return array(
                "Sorry, Username not found",
                "error"
            );
        }
    }
    public function fileupload($filetoupload,$target_dir,$saveas,$format){
        $target_file = $target_dir . $saveas.".".$format;
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
       
        if ($filetoupload["size"] > 50000000) {
             $error = "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            return $error;
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($filetoupload["tmp_name"], $target_file)) {
                return "Upload Successfull";
            }else{
                return "Error uploading File";
            } 
        }
        }
    public function Tickets($id=0,$task="list",$reply=""){
        $id = sanitize::clean($id);
        $task = sanitize::clean($task);
        $reply = sanitize::clean($reply);
        $conn = $GLOBALS['conn'];
        //if id 0 then list all by topic
        //task can vary such as update, add, delete, etc
        if($id==0){
           $tick= mysqli_query($conn,"SELECT * FROM tickets ORDER BY id desc") or die(mysqli_error($conn));
           $mem = array();
           while($ti=mysqli_fetch_assoc($tick)){
               $mem[] = $ti;
           }
           return $mem;
        }
        if($task == "list"){
            $tick= mysqli_query($conn,"SELECT * FROM ticketmessage WHERE ticketid='$id' ORDER BY id desc") or die(mysqli_error($conn));
           $mem = array();
           while($ti=mysqli_fetch_assoc($tick)){
               $mem[] = $ti;
           }
           return $mem;
        }
        if($task == "reply" && $reply != ""){
            $customercare = configs::customercare;
            $nowunix = strtotime("now");
            $owner = mysqli_fetch_array(mysqli_query($conn, "SELECT owner FROM tickets WHERE id = '$id' LIMIT 1"))[0];
            $replying = mysqli_query($conn,"INSERT INTO `ticketmessage`( `ticketid`, `from_`, `owner`, `message`, `date`, `read_`) VALUES ('$id','$customercare','$owner','$reply','$nowunix','0')") OR DIE(mysqli_error($conn));
            return array(
                "Ticket $id replied successfully"
            );
        }
    }
    public function transfers($todo){
        $conn = $GLOBALS['conn'];
        if($todo == "list"){
            $tick= mysqli_query($conn,"SELECT * FROM transactions ORDER BY id desc") or die(mysqli_error($conn));
            $mem = array();
            while($ti=mysqli_fetch_assoc($tick)){
                $mem[] = $ti;
            }
            return $mem;
        }
    }
    public function transLog(){
        $conn = $GLOBALS['conn'];
            $longtin = "SELECT pipul.accountnumber, credit_debit_history.username, credit_debit_history.amount_transfered, credit_debit_history.description,credit_debit_history.type_,credit_debit_history.date_,credit_debit_history.time_ FROM credit_debit_history INNER JOIN pipul ON pipul.username = credit_debit_history.username";
            $tick= mysqli_query($conn,$longtin) or die(mysqli_error($conn));
            $mem = array();
            while($ti=mysqli_fetch_assoc($tick)){
                $mem[] = $ti;
            }
            return $mem;
    }
    public function listmessages(){
        $conn = $GLOBALS['conn'];
        $tick= mysqli_query($conn,"SELECT * FROM messages ORDER BY id desc") or die(mysqli_error($conn));
            $mem = array();
            while($ti=mysqli_fetch_assoc($tick)){
                $mem[] = $ti;
            }
            return $mem;
    }
}
class systemLogs{
    public function messages(){
        $conn = $GLOBALS['conn'];
        $msg = mysqli_fetch_array(mysqli_query($conn,"SELECT COUNT(id) FROM tickets WHERE status = 'open'"));
        return $msg[0];
    }
    public function totalaccounts(){
        $conn = $GLOBALS['conn'];
        $msg = mysqli_fetch_array(mysqli_query($conn,"SELECT COUNT(aid) FROM pipul"));
        return $msg[0];
    }
    public function transfers(){
        $conn = $GLOBALS['conn'];
        $msg = mysqli_fetch_array(mysqli_query($conn,"SELECT COUNT(id) FROM transactions"));
        return $msg[0];
    }
    public function pendingaccounts(){
        $conn = $GLOBALS['conn'];
        $msg = mysqli_fetch_array(mysqli_query($conn,"SELECT COUNT(id) FROM tickets WHERE status = 'pending'"));
        return $msg[0];
    }
    public function msgsCount($user){
        $conn = $GLOBALS['conn'];
        $user = sanitize::clean($user);
        $msg = mysqli_fetch_array(mysqli_query($conn,"SELECT COUNT(id) FROM messages WHERE owner = '$user' AND isread = 'no'"));
        return $msg[0];
    }
}
?>