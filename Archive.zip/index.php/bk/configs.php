<?php
error_reporting(0);
class configs{
    //const license = "**oXTUFlewATT11kaMNTRE1UeBNlY5lzRkRlQIFWUGRlT6lEVOlXQq50dVp3Y0smeNlXRy4ENVNDZ7d4ed0";
    const bkname = "ETNB Financial Solution || Commercial || Personal Banking || Financial Consultants";
    const server102="localhost";
    const user102="flipejsy_user";
    const pass102="flipejsy_etnb_db123";
    const db102 = "flipejsy_etnb_db123";
    const url102="https://etnb.online/index.php/bk";
	const userurl = "https://etnb.online/index.php/en_us";
    const email102="support@etnb.online";
    const url ="https://etnb.online/index.php/";
    const logo ="https://etnb.online/index.php/en_us/img";
    const servername = "etnb";
	const customercare = "Pwanc Mushito";
    //SMS for the OTP
	const smssenderid = "sender";
	const smsusername = "mysmsusername";
    const smspassword = "mysmspassword";
    const smsAPI = "";
    //const smsAPI = "http://www.estoresms.com/smsapi.php?username=".configs::smsusername."&password=".configs::smspassword."&sender=%%sender%%&recipient=%%destination%%&message=%%message%%&";
}
