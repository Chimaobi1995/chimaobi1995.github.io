<?php
require_once("blood.php");
$manager = new Manager;
if(isset($_POST['email']) && isset($_POST['upass'])){
    $managerAuth = $manager->auth($_POST['email'],$_POST['upass']);
    if($managerAuth != true){
       $manager->logout("Invalid Login Details");
    }else{
        header("Location: users");
    }
}

?>
<!DOCTYPE html>
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <meta name="format-detection" content="telephone=no">
        <meta charset="UTF-8">

        <meta name="description" content="">
        <meta name="keywords" content="">
		<link rel="icon" href="https://www.rt-b.net/online/admin/img/favicon.png" type="image/x-icon">

        <title><?= configs::bkname; ?>| Admin Sign In</title>
            
        <!-- CSS -->
        <link href="asset/bootstrap.css" rel="stylesheet">
        <link href="asset/animate.css" rel="stylesheet">
        <link rel="stylesheet" href="asset/font-awesome.css">
        <link href="asset/form.css" rel="stylesheet">
        <link href="asset/calendar.css" rel="stylesheet">
        <link href="asset/style.css" rel="stylesheet">
        <link href="asset/icons.css" rel="stylesheet">
        <link href="asset/generics.css" rel="stylesheet"> 
    </head>
    <body id="skin-blur-window">
		<div class="container">
		<div class="row">
		<div class="col-md-4"></div>
		<div class="col-md-4">
        <section id="login" align="center">
            <header><br><br><br><br>
				<!--img src="asset/logo.png" class="img-responsive"-->
                <br>
                <p style="font-size:28px;color:green;text-align:center;text-transform:uppercase;font-family:arial">Admin Control panel</p>
            </header>
				             <div class="clearfix"></div>
            
            <!-- Login -->


            <form method="post" class="box tile animated active"  >
                <h3 class="m-t-0 m-b-15">Sign In</h3>
                <input class="login-control m-b-10"  name="email" placeholder="Email Address" autofocus="" type="text"/>
                <input class="login-control"  name="upass" placeholder="Password" type="password"/>
                <div class="checkbox m-b-20">
                    <label>
                        <div class="icheckbox_minimal" style="position: relative;" aria-checked="false" aria-disabled="false"><input style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;" type="checkbox"><ins class="iCheck-helper" style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;"></ins></div>
                        Remember Me
                    </label>
                </div>
                <input class="btn btn-sm m-r-5" value="Log In" type="submit"/>
                
                <small>
                   
                    <a class="box-switcher" data-switch="box-reset" href="users/index.php">Forgot Password?</a>
                </small>
            </form>
            
			</section></div>
			</div>
			</div>
        
                              
        
        <!-- Javascript Libraries -->
        <!-- jQuery -->
        <script src="asset/jquery.js"></script> <!-- jQuery Library -->
        
        <!-- Bootstrap -->
        <script src="asset/bootstrap.js"></script>
        
        <!--  Form Related -->
        <script src="asset/icheck.js"></script> <!-- Custom Checkbox + Radio -->
        
        <!-- All JS functions -->
        <script src="asset/functions.js"></script>
    

</body></html>