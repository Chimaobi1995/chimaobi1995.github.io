<?php
session_start();
require_once("../blood.php");
$manager = new Manager;
$manager->isLogged();
//print_r($_POST);
//die();


if(isset($_POST['uname'])){
    $uname = sanitize::clean($_POST['uname']);
    $type = sanitize::clean($_POST['type']);
    $amount = sanitize::clean($_POST['amount']);
    $remarks = sanitize::clean($_POST['remarks']);
    $sender_name = sanitize::clean($_POST['sender_name']);
    $date = sanitize::clean($_POST['date']);
    $time = sanitize::clean($_POST['time']);
    $sent_to_bank = configs::bkname;
	


    //add or remove
    if($_POST['type'] == "Credit"){
        mysqli_query($conn,"UPDATE pipul SET totalbalance = (totalbalance + $amount), accountbalance = (accountbalance + $amount) WHERE username = '$uname'") or die(mysqli_error($conn));
		//$type = "Credit";
    }else{
        mysqli_query($conn,"UPDATE pipul SET totalbalance = (totalbalance - $amount), accountbalance = (accountbalance - $amount) WHERE username = '$uname'") or die(mysqli_error($conn));
		//$type = "Debit";
    }

    //end of add or remove

    $em = "INSERT INTO `transactions`(`sender`, `amount`, `sent_to_bank`, `remarks`, `date`, `time`, `type_`, `sent_to_name`, `sent_to_number`) VALUES ('$sender_name', '$amount', '$sent_to_bank', '$remarks','$date','$time', '$type', '$uname', '$uname')";
	    mysqli_query($conn,$em) or die(mysqli_error($conn));
		
		if(mysqli_affected_rows($conn)<1){
			$_SESSION['msg'] = "<div class='alert alert-success'>Unable to make transactions, please try again</div>";
		}else{
		
		

    $profile = mysqli_query($conn,"SELECT * FROM pipul WHERE username = '$uname' LIMIT 1") or die(mysqli_error($conn));

    function sendEmail($subj,$mesej,$from_,$to){
        $msg = file_get_contents("../../client/emailtemplate.php");
        $content = str_replace("{MAILBODY}",$mesej,$msg);
        $content = str_replace("{SUBJECT}",$subj,$content);
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: $from_" . "\r\n";

        return mail($to,$subj,$content,$headers);

    }
    function sendSMS($mesej,$nomba){
        $curl = curl_init();
        $Q1 = configs::smsAPI;
        $Q1 = str_replace("%%destination%%",urlencode($nomba),$Q1);
        $Q1 = str_replace("%%message%%",urlencode($mesej),$Q1);
        $Q1 = str_replace("%%sender%%",urlencode(configs::smssenderid),$Q1);
        //$Q1 = str_replace("%%sender%%",urlencode(configs::bkname),$Q1);

        //print $Q1;
        //die();
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => $Q1
        ));
        $res_send = curl_exec($curl);
        curl_close($curl);
        // print $res_send;
        //die();


    }
    if(mysqli_num_rows($profile)>0){
        $profilez = mysqli_fetch_array($profile);
        $email = $profilez['email'];
        $phone = $profilez['phone'];
        $subj = "Transaction Details";
        $cur = $profilez['currency'];
        if($_POST['type'] == "Credit"){
            $newbal = ($profilez['accountbalance']);
            $mesej = "Your account has been credited with $cur $amount,\n your current balance is $cur $newbal";
        }else{
            $newbal = ($profilez['accountbalance']);
            $mesej = "Your account has been debited with $cur $amount,\n your current balance is $cur $newbal";
        }
        sendEmail($subj,$mesej,configs::email102,$email);
        sendSMS($mesej,$phone);

    }
	$_SESSION['msg'] = "<div class='alert alert-success'>Transaction Successful</div>";
    header("Location: transferrec.php");
}

}



?>