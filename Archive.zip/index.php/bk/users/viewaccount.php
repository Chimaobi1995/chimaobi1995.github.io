<?php
$q = "queryfile/viewaccount.php";
include "dashboard.php"
?>