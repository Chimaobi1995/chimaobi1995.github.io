actMgr = {
    approvaAcct : function(id){
        if(confirm("Are you sure you want to approve this account?")){
            location.href= "approveaccount.php?id="+id;
        }
    },
    delete : function(id){
        if(confirm("Are you sure you want to approve this account?")){
            location.href= "delete.php?id="+id;
        }  
    }
}
