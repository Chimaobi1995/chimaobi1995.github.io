<?php
require_once("../blood.php");
$manager = new Manager;
$manager->isLogged();
//print_r($_POST);

if(isset($_POST['uname'])){
    $uname = sanitize::clean($_POST['uname']);
    $type = sanitize::clean($_POST['type']);
    $amount = sanitize::clean($_POST['amount']);
    $remarks = sanitize::clean($_POST['remarks']);
    $sender_name = sanitize::clean($_POST['sender_name']);
    $date = sanitize::clean($_POST['date']);
    $time = sanitize::clean($_POST['time']);

    $em = "INSERT INTO `credit_debit_history`(`username`, `amount_transfered`, `description`, `type_`, `date_`,`time_`) VALUES ('$uname','$amount','$remarks','$type','$date','$time')";
   // print $em;
    mysqli_query($conn,$em) or die(mysqli_error($conn));
    header("Location: creditdebitlist.php");
}



?>