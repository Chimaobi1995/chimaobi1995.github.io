<?php
require_once("../blood.php");
$manager = new Manager;
$manager->islogged();
if(isset($_GET['id'])){
    $id = sanitize::clean($_GET['id']);
    $doer=mysqli_query($conn,"UPDATE pipul SET status = 'active' where aid = '$id'") or die(mysqli_error($conn));
    if(mysqli_affected_rows($conn)>0){
        header("Location: pendingaccounts.php?msg=Account approved");
    }else{
        header("Location: pendingaccounts.php?msg=Unable to approve invalid account");
    }
}

?>