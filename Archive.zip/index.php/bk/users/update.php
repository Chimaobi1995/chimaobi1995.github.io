<?php
$q = "queryfile/update.php";
include "dashboard.php"
?>