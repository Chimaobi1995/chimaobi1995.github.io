   		
            
            <section id="content" class="container">

           <center> <h4 class="page-title block-title">
					<form method="" action="">
					<div class="media-body">
						<input class="main-search" placeholder="Enter search here!" type="text"> 
                    </div>
					</h4>
					<button type="submit" name="submit" class="btn btn-md">Search</button>
					</form>
					</center>
			              <div class="block-area" id="tableHover">
                    <h3 class="block-title">View All Sent Messages</h3>
                <!-- Main Widgets -->
               
                 <div class="message-list list-container">
                    <header class="listview-header media">
                        <div class="icheckbox_minimal" style="position: relative;" aria-checked="false" aria-disabled="false"><input class="pull-left list-parent-check" value="" style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;" type="checkbox">
						
						<!--ins class="iCheck-helper" style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;"></ins-->
						
						</div>
                            
                        
                        
                        <ul class="list-inline list-mass-actions pull-left">
                            <li>
                                <a data-toggle="modal" href="#compose-message" title="" class="tooltips" data-original-title="Compose Message">
                                    <i class="fa fa-pencil-square-o"></i>Compose
                                </a>
                            </li>
                           
                           
                            <li class="show-on" style="display: none;">
                                <a href="" title="" class="tooltips" data-original-title="Delete">
                                    <i class="sa-list-delete"></i>
                                </a>
                            </li>
                        </ul>

                         <div class="clearfix"></div>
                    </header>
					
                   
					<div class="media">
					<div class="icheckbox_minimal" style="position: relative;" aria-checked="false" aria-disabled="false"><input class="pull-left" style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;" type="checkbox">
					
					<!--ins class="iCheck-helper" style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;"></ins-->
					</div>
                        <a class="media-body" href="message-detail.html">
                            <div class="pull-left list-title">
                                <span class="t-overflow f-bold" style="font-size:140%;">Sender</span>
                            </div>
							<div class="pull-left list-title">
                                <span class="t-overflow f-bold" style="font-size:140%;">To</span>
                            </div>
                            <div class="pull-right list-date" style="font-size:140%;">Date</div> 
                            <div class="media-body hidden-xs">
                                <span class="t-overflow" style="font-size:140%;">Message</span>
                            </div>
                        </a>
                    </div>




                     <?php
                     $msg = new AdminTools;
                        $allmsg = $msg->listmessages();
                        //print_r($allmsg);
                        for($u7=0;$u7<count($allmsg);$u7++){
                            $thismsg=$allmsg[$u7];
                            ?>
                             <div class="media">
                        <div class="icheckbox_minimal" style="position: relative;" aria-checked="false" aria-disabled="false"><input class="pull-left list-check" style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;" type="checkbox">
						<!--ins class="iCheck-helper" style="position: absolute; top: -20%; left: -20%; display: block; width: 140%; height: 140%; margin: 0px; padding: 0px; background: rgb(255, 255, 255) none repeat scroll 0% 0%; border: 0px none; opacity: 0;"></ins-->
						</div>

                        <a class="media-body">
							
                            <div class="pull-left list-title">
                                <span class="t-overflow f-bold"><?php print $thismsg['sender']; ?></span>
                            </div>
							<div class="pull-left list-title">
                                <span class="t-overflow f-bold"><?php print $thismsg['owner']; ?></span>
                            </div>
                            <div class="pull-right list-date"><?php print date("Y-m-d h:i:s",$thismsg['date']); ?></div> 
                            <div class="media-body hidden-xs">
                                <span class="t-overflo"><?php print $thismsg['content']; ?></span>
                            </div>
							 
                        </a>
                    </div><br>
                            <?php
                        }
                    ?>
                   


<br>
                                     </div>
                
                <!-- Compose -->
                <div class="modal fade" id="compose-message">
                    <div class="modal-dialog">
                        <div class="modal-content">
						<form class="form-group" method="POST">
                            <div class="modal-header">
							
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                <h4 class="modal-title"><i class="fa fa-envelope-o"></i> Compose Message</h4>
                            </div>
                            <select class="form-control primary" name="sender_name">
                                <option class="form-control" style="background-color:#000" value="Customer Care">Customer Care</option>
                                <option class="form-control" style="background-color:#000" value="Account Officer">Account Officer</option>
                                <option class="form-control" style="background-color:#000" value="Service Department">Service Department</option>
                            </select>
							<select class="form-control primary" name="reci_name">
                                
                                                                <?php
                                                                $pipul = AdminTools::getUsernames();
                                                                for($y=0;$y<count($pipul);$y++){
                                                                    print "<option>".$pipul[$y]."</option>";
                                                                }
                                                                ?>
                                                            </select>
                            <div class=" form-control">
                                <input class="form-control input-transparent" name="subject" placeholder="Subject..." type="text">
                            </div>
                            <textarea class="form-control" name="msg" placeholder="Type Your message here..."></textarea>
                            <div class="p-relative">
                                <div class="message-options">
								<i class="fa fa-envelope-o"></i>
                                    <!--img src="img/icon/tile-actions.png" alt=""-->
                                </div>
                                
                            </div>
                            <div class="modal-footer m-0">
                                <button class="btn" data-dismiss="modal">Cancel</button>
								<button class="btn" type="subit" name="message">Send</button>
                            </div>
						</form>
                        </div>
                    </div>
                </div>
                
            </div>
			</section>  


			