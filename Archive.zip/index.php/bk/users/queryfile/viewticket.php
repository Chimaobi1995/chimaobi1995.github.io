<?php
if(isset($_GET['id']) && $_GET['id'] != 0){
    $thisTicket = AdminTools::Tickets($_GET['id']);
    ?>
    	<section id="content" class="container">
        <div style="max-width:800px !important">
			<h4 class="page-title block-title"> Tickets</h4>
                <div class="block-area" id="tableHover">
                    <h3 class="block-title">Ticket Details</h3>
                    <div class="table-responsive overflow" style="overflow: hidden;" tabindex="5001">
                        <table class="table table-bordered table-hover tile">
                            <thead>
		
                               
                            </thead>
                            
                            <tbody>
                            <tr>
                                <td>
                                <form method="post">
                                <b>Reply</b>
                                <textarea name="reply" placeholder="type a message..." class="form-control"></textarea>
                                    <button class="btn btn-small">Reply</button>
                                </td>
                                </form>
                            </tr>
                                <?php 
                                    for($y7 = 0; $y7<count($thisTicket); $y7++){
                                        $thisdetail = $thisTicket[$y7];
                                        ?>
                                        <tr>
                                            <td>
                                                <span class="badge"><?php print $thisdetail['from_']; ?><br/><?php print date("Y-m-d h:i", $thisdetail['date']) ; ?></span>
                                                <div class="alert alert-success"><?php print $thisdetail['message']; ?></div>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                ?>
   
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <hr class="whiter m-t-20">
            </div>
			</section>
        


<?php
}else{
    print "Error, Invalid Request";
}
