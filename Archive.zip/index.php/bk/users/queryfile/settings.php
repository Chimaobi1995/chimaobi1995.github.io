   <!-- Content -->
            <section id="content" class="container">
            <h4 class="page-title block-title">SETTINGS</h4>
			 
                <div class="block-area" id="tableHover">
                    <h3 class="block-title">Control Account Status</h3><br>
                
                
                <!-- Notification Drawer -->
                 <!-- Shortcuts -->
			
				<form method="POST">
                <div class="row">
					<div class="col-md-3 form-group">
						<label>Select Account</label>
						<select name="uname" class="form-control input-sm validate[required]">
                        <?php
                            $everyone = AdminTools::getUsers();
                            for($as=0;$as<count($everyone);$as++){
                                $thisUser = $everyone[$as];
                                ?><option value="<?php print $thisUser['username']; ?>"><?php print $thisUser['firstname']." ".$thisUser['middlename']." ".$thisUser['lastname']; ?></option>
                                <?php
                            }
                        ?>
						</select>
					</div>
				</div>
				<div class="row">
					<div class="col-md-3 form-group">
						<label>Set Status</label>
						<select name="status" class="form-control input-sm validate[required]">
							<option value="Active" selected="selected">Active</option>
							<option value="Dormant/Inactive">Dormant/Inactive</option>
							<option value="CLOSED">Closed</option>
							<option value="DISABLED">Disabled</option>
							<option value="SUSPEND">Suspend</option>
							<option value="ON HOLD">On Hold</option>
						</select>
					</div>
                </div>
					<button type="submit" name="set" class="btn btn-md">Set</button>
				</form>
                <hr class="whiter">
				<br>
				<article>
				<ul>
					<li><b>Active</b> <p> This means that the client can access all functions within his/her account</p></li>
					<li><b>Dormant/Inactive</b><p>A notice that the account is 
Dormant/Inactive will be shown on the client's dashboard. Also, he/she 
will not be able to make any transfers.</p></li>
					<li><b>Closed</b> <p> When the account is set to Closed, it brings 
up a message when the client tries to log in, saying that the account no
 longer exist.</p></li>
					<li><b>Disabled</b> <p> A client will be notified when they try 
logging in that their account has been disabled due to violation of 
terms. He will be advised to contact the customer care to rectify the 
issue.</p></li>
                </ul>
				</article>
                <!-- Quick Stats -->
                
		
            <!-- Older IE Message -->
            <!--[if lt IE 9]>
                <div class="ie-block">
                    <h1 class="Ops">Ooops!</h1>
                    <p>You are using an outdated version of Internet Explorer, upgrade to any of the following web browser in order to access the maximum functionality of this website. </p>
                    <ul class="browsers">
                        <li>
                            <a href="https://www.google.com/intl/en/chrome/browser/">
                                <img src="img/browsers/chrome.png" alt="">
                                <div>Google Chrome</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://www.mozilla.org/en-US/firefox/new/">
                                <img src="img/browsers/firefox.png" alt="">
                                <div>Mozilla firefox</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://www.opera.com/computer/windows">
                                <img src="img/browsers/opera.png" alt="">
                                <div>Opera</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://safari.en.softonic.com/">
                                <img src="img/browsers/safari.png" alt="">
                                <div>Safari</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://windows.microsoft.com/en-us/internet-explorer/downloads/ie-10/worldwide-languages">
                                <img src="img/browsers/ie.png" alt="">
                                <div>Internet Explorer(New)</div>
                            </a>
                        </li>
                    </ul>
                    <p>Upgrade your browser for a Safer and Faster web experience. <br/>Thank you for your patience...</p>
                </div>   
            <![endif]-->
        </div></section>
        