			<section id="content" class="container">
			<h4 class="page-title block-title">Update Accounts</h4>
                <div class="block-area" id="tableHover">
                    <h3 class="block-title">Active Accounts</h3>
                    <div class="table-responsive overflow" style="overflow: hidden;" tabindex="5001">
                        <table class="table table-bordered table-hover tile">
                            <thead>
                                <tr>
                                    
                                    <th>Full Name</th>
                                    <th>Username</th>
                                    
                                    <th>Email</th>
                                    <th>Sex</th>
                                    <th>Account Type</th>
                                    <th>Total Balance</th>
                                    <th>Available Balance</th>
                                    
                                    <th>Currency</th>
                                   
                                   
                                    <th>PW</th>
                                    <th>View Account</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $pipuList = AdminTools::getUsers();
                                for($y=0;$y<count($pipuList); $y++){
                                    $thisPerson = $pipuList[$y];
                                   ?>
                                   <tr>
                                    <td><?php print $thisPerson['firstname']." ". $thisPerson['middlename']." ".$thisPerson['lastname']; ?></td>
                                        <td><?php print  $thisPerson['username']; ?></td> 
                                        <td><?php print  $thisPerson['email']; ?></td>
                                        <td><?php print  $thisPerson['gender']; ?></td>
                                        <td><?php print  $thisPerson['accountype']; ?></td>
                                        <td><?php print  $thisPerson['totalbalance']; ?></td>
                                        <td><?php print  $thisPerson['accountbalance']; ?></td>
                                        <td><?php print  $thisPerson['currency']; ?></td>
                                        <td><?php print  $thisPerson['registrationdate']; ?></td>
                                        <td><a href="editaccount.php?id=<?php print  $thisPerson['aid']; ?>" name="delete" rel="tooltip" class="btn btn-simple btn-danger btn-icon " title="Edit Account">Edit</a> <a href="delete.php?id=<?php print  $thisPerson['aid']; ?>" name="delete" rel="tooltip" class="btn btn-simple btn-danger btn-icon " title="Remove Account">Delete</a> 
                                        </td>
                                    </tr>    
                                   <?php 
                                }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <hr class="whiter m-t-20">
			</section>
          
