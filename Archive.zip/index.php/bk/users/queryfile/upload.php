	<?php
	if(isset($_FILES['passport'])){
		$filetoupload = $_FILES['passport'];
		$target_dir = "../passports/";
		//verifying username exists
		$thisUser = $_POST['user'];
		if(in_array("error", AdminTools::fetchUser($thisUser))){
			Die("Invalid User Selected");
		}
		$saveas = sanitize::filename($_POST['user']);
		//end of verifications
		$doUpl = AdminTools::fileupload($filetoupload,$target_dir,$saveas,"jpg");
		print "<script>alert('$doUpl');</script>";

	}
	 $pipuList = AdminTools::getUsernames();
	?><section id="content" class="container">
			<h4 class="page-title block-title">Upload Image</h4>
			
			<br>
                        <br>
                        <br>
                             
                <!-- Required Feilds -->
                <div class="block-area" id="required">    
                    
                    
				  <fieldset>
					
					<form action="" method="post" enctype="multipart/form-data">
					<div class="col-md-2 form-group">
                            <label>Select User</label>
                            <select name="user" class="form-control input-sm validate[required]">
							<?php
								for($i8=0;$i8<count($pipuList); $i8++){
									print "<option>".$pipuList[$i8]."</option>";
								}
							?>
                               
                              
                            </select>
                        </div>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        
						<h4 class="">Please, make sure the image is a '.jpg' file and saved with account username</h4>
						<div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-preview thumbnail form-control"></div>
                        
							<div>
								<span class="btn btn-file btn-alt btn-sm">
									<span class="fileupload-new">Select image</span>
									<span class="fileupload-exists">Change</span>
									<input accept="image/jpeg" type="file" name="passport">
								</span>
								<a href="#" class="btn fileupload-exists btn-sm" data-dismiss="fileupload">Remove</a>
							</div>
						</div>
                       
							<input class="btn btn-md fileupload-new" value="Upload Image" type="submit">
                        
                    </form>
					</fieldset>
                        
                </div>
                
                <hr class="whiter m-t-20">
			</section>
          
