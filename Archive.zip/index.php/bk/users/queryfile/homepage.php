<?php
$manager = new Manager;
$manager->islogged();
?>
	   <!-- Content -->
            <section id="content" class="container">



                <!-- Notification Drawer -->


                <h4 class="page-title">DASHBOARD</h4>
         
                <!-- Shortcuts -->
                <div class="block-area shortcut-area">
                    <a class="shortcut tile" href="createaccount.php">
                        <img src="assets/user-plus.png" alt="">
                        <small class="t-overflow">Add Account</small>
                    </a>
                    <a class="shortcut tile" href="viewaccount.php">
                        <img src="assets/vcard.png" alt="">
                        <small class="t-overflow">View Accounts</small>
                    </a>
                    <a class="shortcut tile" href="pendingaccounts.php">
                        <img src="assets/user-secret.png" alt="">
                        <small class="t-overflow">Pending Accounts</small>
                    </a>
                    <a class="shortcut tile" data-toggle="modal" href="#modalDefault">
                        <img src="assets/list.png" alt="">
                        <small class="t-overflow">Add History</small>
                    </a>
                    <a class="shortcut tile" data-toggle="modal" href="#credit">
                        <img src="assets/money.png" alt="">
                        <small class="t-overflow">Credit Acc</small>
                    </a>
                    <a class="shortcut tile" data-toggle="modal" href="#debit">
                        <img src="assets/cc-mastercard.png" alt="">
                        <small class="t-overflow">Debit Acc</small>
                    </a>
                </div>

                <hr class="whiter">

                <!-- Quick Stats -->
                <div class="block-area">
                    <div class="row">
                        <div class="col-md-3 col-xs-6">
                            <div class="tile quick-stats">
                                <div id="stats-line-2" class="pull-left"><canvas style="display: inline-block; width: 246px; height: 65px; vertical-align: top;" width="246" height="65"></canvas></div>
                                <div class="data">
                                    <h2 sdata-value="0"><?php print systemLogs::totalaccounts(); ?></h2>
                                    <small>Total Account</small>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 col-xs-6">
                            <div class="tile quick-stats media">
                                <div id="stats-line-3" class="pull-left"><canvas style="display: inline-block; width: 246px; height: 65px; vertical-align: top;" width="246" height="65"></canvas></div>
                                <div class="media-body">
                                    <h2><?php print systemLogs::messages(); ?></h2>
                                    <small>Tickets</small>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 col-xs-6">
                            <div class="tile quick-stats media">

                                <div id="stats-line-4" class="pull-left"><canvas style="display: inline-block; width: 246px; height: 65px; vertical-align: top;" width="246" height="65"></canvas></div>

                                <div class="media-body">
                                    <h2 sdata-value="0"><?php print systemLogs::transfers(); ?></h2>
                                    <small>Transfers Made</small>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 col-xs-6">
                            <div class="tile quick-stats media">
                                <div id="stats-line" class="pull-left"><canvas style="display: inline-block; width: 246px; height: 65px; vertical-align: top;" width="246" height="65"></canvas></div>
                                <div class="media-body">
                                    <h2 sdata-value="0"><?php print systemLogs::pendingaccounts(); ?></h2>
                                    <small>Total Pending Accounts</small>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="container-fluid">
                    <h6>ALL UPLOADED IMAGES </h6>
					<hr class="whiter">
                    <?php 
                    $_people = AdminTools::getUsernames(); 
                    for($pip = 0; $pip< count($_people); $pip++){
                        $thisUser = $_people[$pip];
                        $profpix = configs::url102."/passports/".$thisUser.".jpg";
                     print "<a href='view.php?user=$thisUser'><img src='$profpix' title='$thisUser' width='45px' height='50px'></a>&nbsp;";
                    }
                    ?>
				</div>
                

                <!-- Main Widgets -->

                <div class="block-area">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Main Chart -->


                            <!--  Recent Postings -->

                            <div class="clearfix"></div>
                        </div>

                        <div class="clearfix"></div>
                    </div>
                </div>


            </section>
            <div class="modal fade" id="modalDefault" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <h4 class="modal-title">Add Debit/Credit History</h4>
                        </div>
                        <div class="modal-body">
                            <p>Fill the for correctly.</p>
                        </div>
                        <form method="POST" action="savehistory.php">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>Select Account</label>
                                        <select name="uname" class="form-control input-sm validate[required]">
                                                <?php 
                                                $Pipu2 = AdminTools::getUsers();
                                               for($pip = 0; $pip< count($Pipu2); $pip++){
                                                $thisUser = $Pipu2[$pip];
                                                ?><option value="<?php print $thisUser['username']; ?>" selected="selected"><?php print $thisUser['firstname']." ".$thisUser['middlename']." ".$thisUser['lastname']; ?></option><?php
                                               }
                                                ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Transaction Type</label>
                                        <select name="type" class="form-control input-sm validate[required]">
                                            <option value="Credit" selected="selected">Credit</option>
                                            <option value="Debit">Debit</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>Amount</label>
                                        <input name="amount" class="input-sm form-control [required] mask-money" placeholder="Eg, 3,500,000.00" required="" type="number">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Description</label>
                                        <textarea name="remarks" class="input-sm form-control " placeholder="Eg, Flight Payment" required=""></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>To/From</label>
                                        <input name="sender_name" class="input-sm form-control [required] mask-money" placeholder="Eg, John Kennedy" required="" type="text">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Date</label>
                                        <div class="input-icon datetime-pick date-only">
                                            <input data-format="dd/MM/yyyy" name="date" class="input-sm validate[required] form-control mask-time" placeholder="Eg, 21st September, 2012" required="" type="text">
                                            <span class="add-on">
                                                <i class="sa-plus icon-calendar"></i>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="col-md-6 form-group">
                                        <label>Time</label>
                                        <div class="input-icon datetime-pick time-only-12">
                                            <input data-format="hh:mm:ss" name="time" class="input-sm validate[required] form-control" placeholder="Eg, 14:32" required="" type="text">
                                            <span class="add-on">
                                                <i class="sa-plus icon-time"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer" style="text-align:right;">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-danger btn-lg" data-dismiss="modal">Close</button>
                                        <button type="reset" class="btn btn-warning btn-lg">Reset</button>
                                        <button type="submit" name="his" class="btn btn-success btn-lg">Add History</button>

                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <div class="modal fade" id="credit" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <h4 class="modal-title">Credit User's Account</h4>
                        </div>
                        <div class="modal-body">
                            <p>Fill the for correctly.</p>
                        </div>
                        <form method="POST" action="savetransaction.php">
                        <input type="hidden" name="type_" value="Credit"/>
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>Select Account To Credit</label>
                                        <select name="uname" class="form-control input-sm validate[required]">
                                        <?php 
                                                $Pipu2 = AdminTools::getUsers();
                                               for($pip = 0; $pip< count($Pipu2); $pip++){
                                                $thisUser = $Pipu2[$pip];
                                                ?><option value="<?php print $thisUser['username']; ?>" selected="selected"><?php print $thisUser['firstname']." ".$thisUser['middlename']." ".$thisUser['lastname']; ?></option><?php
                                               }
                                                ?>
                                        </select>
                                    </div>
									
									
												
                                    <div class="col-md-6 form-group">
                                        <label>From</label>
                                        <input name="sender_name" class="input-sm form-control " required="" type="text">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>Amount</label>
                                        <input name="amount" class="input-sm form-control [required] mask-money" placeholder="Eg, 3,500,000.00" required="" type="number">
                                        <input name="type" value="Credit" type="hidden">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Description</label>
                                        <textarea name="remarks" class="input-sm form-control " placeholder="Eg, Flight Payment" required=""></textarea>
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col-md-6 form-group">
                                        <label>Date</label>
                                        <div class="input-icon datetime-pick date-only">
                                            <input data-format="dd/MM/yyyy" name="date" class="input-sm validate[required] form-control mask-time" placeholder="Eg, 21st September, 2012" required="" type="text">
                                            <span class="add-on">
                                                <i class="sa-plus icon-calendar"></i>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="col-md-6 form-group">
                                        <label>Time</label>
                                        <div class="input-icon datetime-pick time-only-12">
                                            <input data-format="hh:mm:ss" name="time" class="input-sm validate[required] form-control" placeholder="Eg, 14:32" required="" type="text">
                                            <span class="add-on">
                                                <i class="sa-plus icon-time"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer" style="text-align:right;">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-danger btn-lg" data-dismiss="modal">Close</button>
                                        <button type="reset" class="btn btn-warning btn-lg">Reset</button>
                                        <button type="submit" name="credit" class="btn btn-success btn-lg">Credit Account</button>

                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <div class="modal fade" id="debit" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <h4 class="modal-title">Debit User's Account</h4>
                        </div>
                        <div class="modal-body">
                            <p>Fill the for correctly.</p>
                        </div>
                        <form method="POST" action="savetransaction.php">
                        <input type="hidden" name="type_" value="Debit"/>
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>Select Account To Debit</label>
                                        <select name="uname" class="form-control input-sm validate[required]">
                                        <?php 
                                                $Pipu2 = AdminTools::getUsers();
                                               for($pip = 0; $pip< count($Pipu2); $pip++){
                                                $thisUser = $Pipu2[$pip];
                                                ?><option value="<?php print $thisUser['username']; ?>" selected="selected"><?php print $thisUser['firstname']." ".$thisUser['middlename']." ".$thisUser['lastname']; ?></option><?php
                                               }
                                                ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Debit To</label>
                                        <input name="sender_name" class="input-sm form-control " required="" type="text">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>Amount</label>
                                        <input name="amount" class="input-sm form-control [required] mask-money" placeholder="Eg, 3,500,000.00" required="" type="number">
                                        <input name="type" value="Debit" type="hidden">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Description</label>
                                        <textarea name="remarks" class="input-sm form-control " placeholder="Eg, Flight Payment" required=""></textarea>
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col-md-6 form-group">
                                        <label>Date</label>
                                        <div class="input-icon datetime-pick date-only">
                                            <input data-format="dd/MM/yyyy" name="date" class="input-sm validate[required] form-control mask-time" placeholder="Eg, 21st September, 2012" required="" type="text">
                                            <span class="add-on">
                                                <i class="sa-plus icon-calendar"></i>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="col-md-6 form-group">
                                        <label>Time</label>
                                        <div class="input-icon datetime-pick time-only-12">
                                            <input data-format="hh:mm:ss" name="time" class="input-sm validate[required] form-control" placeholder="Eg, 14:32" required="" type="text">
                                            <span class="add-on">
                                                <i class="sa-plus icon-time"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer" style="text-align:right;">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-danger btn-lg" data-dismiss="modal">Close</button>
                                        <button type="reset" class="btn btn-warning btn-lg">Reset</button>
                                        <button type="submit" name="debit" class="btn btn-success btn-lg">Debit Account</button>

                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <h4 class="modal-title">Edit Admin Account</h4>
                        </div>
                        <div class="modal-body">
                            <p>Change Your Login Details</p>
                        </div>
                        <form method="POST">
                            <div class="container-fluid">
                                <div class="row">

                                    <div class="col-md-6 form-group">
                                        <label>Email</label>
                                        <input name="email" value="info@rt-b.net" class="input-sm form-control " required="" type="text">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label>New Password</label>
                                        <input name="upass1" class="input-sm form-control [required]" required="" type="password">

                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Repeat Password</label>
                                        <input name="upass" class="input-sm form-control [required]" required="" type="password">

                                    </div>
                                </div>
                                <div class="modal-footer" style="text-align:right;">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-danger btn-lg" data-dismiss="modal">Close</button>

                                        <button type="submit" name="edit" class="btn btn-success btn-lg">Change Details</button>

                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <!-- Older IE Message -->
            <!--[if lt IE 9]>
                <div class="ie-block">
                    <h1 class="Ops">Ooops!</h1>
                    <p>You are using an outdated version of Internet Explorer, upgrade to any of the following web browser in order to access the maximum functionality of this website. </p>
                    <ul class="browsers">
                        <li>
                            <a href="https://www.google.com/intl/en/chrome/browser/">
                                <img src="img/browsers/chrome.png" alt="">
                                <div>Google Chrome</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://www.mozilla.org/en-US/firefox/new/">
                                <img src="img/browsers/firefox.png" alt="">
                                <div>Mozilla firefox</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://www.opera.com/computer/windows">
                                <img src="img/browsers/opera.png" alt="">
                                <div>Opera</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://safari.en.softonic.com/">
                                <img src="img/browsers/safari.png" alt="">
                                <div>Safari</div>
                            </a>
                        </li>
                        <li>
                            <a href="http://windows.microsoft.com/en-us/internet-explorer/downloads/ie-10/worldwide-languages">
                                <img src="img/browsers/ie.png" alt="">
                                <div>Internet Explorer(New)</div>
                            </a>
                        </li>
                    </ul>
                    <p>Upgrade your browser for a Safer and Faster web experience. <br/>Thank you for your patience...</p>
                </div>   
            <![endif]-->
        </section>
