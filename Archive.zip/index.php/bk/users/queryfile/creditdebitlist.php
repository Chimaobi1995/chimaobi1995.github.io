		<section id="content" class="container">
			<h4 class="page-title block-title">Credit/Debit Records</h4>
                <div class="block-area" id="tableHover">
                    <h3 class="block-title">View All Credit &amp; Debit History</h3>
                    <div class="table-responsive overflow" style="overflow: hidden;" tabindex="5001">
                        <table class="table table-bordered table-hover tile">
                            <thead>
                                <tr>
                                
									<th>Account No</th>
									<th>Amount Transfered</th>
                                    <th>Description</th>
                                    <th>Type</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                              $logs = AdminTools::transLog();
                              for($ya = 0; $ya<count($logs); $ya++){
                                  $thisLog = $logs[$ya];
                                  ?>
                                    <tr>
                                    <td><?php print $thisLog['accountnumber']; ?></td>
                                    <td><?php print $thisLog['amount_transfered']; ?></td>
                                    <td><?php print $thisLog['description']; ?></td>
                                    <td><?php print $thisLog['type_']; ?></td>
                                    <td><?php print $thisLog['date_']; ?></td>
                                    <td><?php print $thisLog['time_']; ?></td>
                                    
                                    </tr>
                                  <?php
                              }

                            ?>
	                                
                                   
                               
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <hr class="whiter m-t-20">
			</section>
  