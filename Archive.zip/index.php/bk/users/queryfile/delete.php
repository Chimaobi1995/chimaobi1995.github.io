	<section id="content" class="container">
			<h4 class="page-title block-title">Delete Account</h4>
                                
                <div class="container-fluid">
				
				 <div class="col-md-8">
				                              <div class="card">
                                <div class="card-header card-header-icon" data-background-color="rose">
                                    <i class="fa fa-trash-o fa-3x"></i>
                                </div><br>
                               <?php
                               if(isset($_GET['id'])){
                                   $thisUser =  AdminTools::fetchUser($_GET['id']);
                                   if(in_array("error",$thisUser)){
                                       print $thisUser[0];
                                       goto endl;
                                   }
                               }else{
                                   print "Parameter not set";
                                   goto endl;
                               }
                                   
                               ?>
                                    
                                    <form class="form-horizontal" method="post">
										<div class="row">
                                            <label class="col-md-3 label-on-left">Full Name</label>
                                            <div class="col-md-9">
                                                <div class="form-group label-floating is-empty">
                                                    <label class="control-label"></label>
                                                    <a><?php print $thisUser['firstname']." ".$thisUser['middlename']." ". $thisUser['lastname']; ?></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <label class="col-md-3 label-on-left">Email</label>
                                            <div class="col-md-9">
                                                <div class="form-group label-floating is-empty">
                                                    <label class="control-label"></label>
													
                                                    <a><?php print $thisUser['email']; ?></a><br>
													
                                                </div>
                                            </div>
                                        </div>
										<div class="row">
                                            <label class="col-md-3 label-on-left">Account Number</label>
                                            <div class="col-md-9">
                                                <div class="form-group label-floating is-empty">
                                                    <label class="control-label"></label>
                                                    <a><?php print $thisUser['accountnumber']; ?></a>
                                                </div>
                                            </div>
                                        </div>
										<div class="clearfix"></div>
										<br>
                                       <input type="hidden" name="delid" value="<?php print $thisUser['aid']; ?>"/>
										<input class="btn btn-md" name="delete" value="Delete Account" type="submit">
                                    </form>
                               <?php endl: ?>
                            </div>
                        </div>
						
				
				
                        
                        
                        
                    
                </div>
                
                <hr class="whiter m-t-20">
			</section>
          