<?php
$handler = new AdminTools;
$user = (isset($_GET['user']) ? $_GET['user'] : "");
$myself = $handler->fetchUser($user);
$myself['passport'] = configs::url102."/passports/".$myself['username'].".jpg";
if(in_array("error",$myself)){
	goto domp;
}

?><!-- BEGIN #content -->
<div id="content" class="content p-0">
                <!-- BEGIN profile-header -->
                <div class="profile-header">
                    <!-- BEGIN profile-header-cover -->
                    <div class="profile-header-cover"></div>
                    <!-- END profile-header-cover -->
                    <!-- BEGIN profile-header-content -->
                    <div class="profile-header-content">
                        <!-- BEGIN profile-header-img -->
                        <div class="profile-header-img"> <img width="200px" src="<?php print $myself['passport']; ?>" class="img-responsive" alt="profile picture"> </div>
                        <!-- END profile-header-img -->
                        <!-- BEGIN profile-header-info -->
                        <div class="profile-header-info">
                            <h4>  </h4>
                            <p>
                                                            </p> <!-- <a href="edit_profile.php" class="btn btn-xs btn-primary">Edit Profile</a>  --></div>
                        <!-- END profile-header-info -->
                    </div>
                    <!-- END profile-header-content -->
                    <!-- BEGIN profile-header-tab -->
                    <ul class="profile-header-tab">
                        <li></li>
                    </ul>
                    <!-- END profile-header-tab -->
                </div>
                <!-- END profile-header -->
                <!-- BEGIN profile-container -->
                <div class="profile-container">
                    <!-- BEGIN row -->
                    <div class="row row-space-20">
                        <!-- BEGIN col-8 -->
                        <!-- BEGIN col-4 -->
                        <!-- BEGIN profile-info-list -->
                        <ul class="profile-info-list">
                            <li class="title">
                                <h3>ACCOUNT INFORMATION</h3></li>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Email</b></div>
                                    <div class="value"><?php print $myself['email']; ?>
                                                                            </div>
                                </li>
                                <br>
                                <li>
                                    <div class="field"><b>Phone</b></div>
                                    <div class="value"><?php print $myself['phone']; ?>
                                                                            </div>
                                </li>
                                <br> 
							</div>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Sex</b></div>
                                    <div class="value"><?php print $myself['gender']; ?>
                                                                            </div>
                                </li>
                                <br>
                                <li>
                                    <div class="field"><b>Marital Status</b></div>
                                    <div class="value"><?php print $myself['maritalstatus']; ?>
                                                                            </div>
                                </li>
                                <br> 
							</div>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Date of Birth</b></div>
                                    <div class="value"><?php print $myself['dob']; ?>
                                                                            </div>
                                </li>
                                <br>
                                <li>
                                    <div class="field"><b>Account No</b></div>
                                    <div class="value"><?php print $myself['accountnumber']; ?></div>
                                </li>
                                <br>
							</div>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Account Type</b></div>
                                    <div class="value">
                                         
                                    <?php print $myself['accountype']; ?></div>
                                </li>
                                <br> 
							</div>
                            <div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Address</b></div>
                                    <div class="value"> <address class="m-b-0"><?php print $myself['address']; ?></address> </div>
                                </li>
                                <br> 
							</div>
							<div class="col-md-4 col-xs-6 col-ms-6">
                                <li>
                                    <div class="field"><b>Active Since</b></div>
                                    <div class="value">
                                        
                                    <?php print $myself['registrationdate']; ?></div>
                                </li>
                                <br> 
							</div>
							
							</ul>
							
                        <!-- END profile-info-list -->
                        </div>
                        <!-- END col-4 -->
                    </div>
                    <!-- END row -->
                </div>
                <!-- END profile-container -->

		<?php
		/*
		<section id="content" class="container">
			<h4 class="page-title block-title">Upload Image</h4>
			
			<br>
                        <br>
                        <br>
                             
                <!-- Required Feilds -->
                <div class="block-area" id="required">    
                    
                    
				  <fieldset>
					
					<form action="" method="POST" enctype="multipart/form-data">
					<div class="col-md-2 form-group">
                            <label>Select User</label>
                            <select name="user" class="form-control input-sm validate[required]">
                                <option value="Jone Obi">Jone Obi</option>
                                <option value="Chioma Ony">Chioma Ony</option>
                              
                            </select>
                        </div>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        
						<h4 class="">Please, make sure the image is a '.jpg' file and saved with account username</h4>
						<div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-preview thumbnail form-control"></div>
                        
							<div>
								<span class="btn btn-file btn-alt btn-sm">
									<span class="fileupload-new">Select image</span>
									<span class="fileupload-exists">Change</span>
									<input accept="image/jpeg" name="image" type="file">
								</span>
								<a href="#" class="btn fileupload-exists btn-sm" data-dismiss="fileupload">Remove</a>
							</div>
						</div>
                       
							<input class="btn btn-md fileupload-new" value="Upload Image" type="submit">
                        
                    </form>
					</fieldset>
                        
                </div>
                
                <hr class="whiter m-t-20">
			</section>
          
*/
domp:
?>