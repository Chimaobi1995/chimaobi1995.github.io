<?php
//session_start();
?>			<section id="content" class="container">
			<h4 class="page-title block-title">Transfer Records</h4>
                <div class="block-area" id="tableHover">
				<?php if(isset($_SESSION['msg'])){echo $_SESSION['msg']; unset($_SESSION['msg']);}?>
                    <h3 class="block-title">View All Transfer Records</h3>
                    <div class="table-responsive overflow" style="overflow: hidden;" tabindex="5001">
                        <table class="table table-bordered table-hover tile">
                            <thead>
                                <tr>
                                    <th>#</th>
									<th>Sender</th>
									<th>Amount Transfered</th>
                                    <th>Account Transfered To</th>
                                    <th>Bank</th>
                                    <th>Account Name</th>
                                    <th>Remarks</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                            $transfers = AdminTools::transfers("list");
                            for($i8=0;$i8<count($transfers); $i8++){
                                $thisTransfer = $transfers[$i8];
                                ?>
                                <tr>
                                    <td><?php print $thisTransfer['id']; ?></td>
                                    <td><?php print $thisTransfer['sender']; ?></td>
                                    <td><?php print $thisTransfer['amount']; ?></td>
                                    <td><?php print $thisTransfer['sent_to_number']; ?></td>
                                    <td><?php print $thisTransfer['sent_to_bank']; ?></td>
                                    <td><?php print $thisTransfer['sent_to_name']; ?></td>
                                    <td><?php print $thisTransfer['remarks']; ?></td>
                                    <td><?php print $thisTransfer['date']; //print date("Y-m-d h:i:s",$thisTransfer['date']); ?></td>
                                    
                                </tr>
                                <?php
                            }
                            ?>
	                                
                                  
                               
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <hr class="whiter m-t-20">
			</section>
          
