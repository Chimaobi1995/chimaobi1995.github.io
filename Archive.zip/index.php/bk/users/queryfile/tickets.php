	<section id="content" class="container">
			<h4 class="page-title block-title"> Tickets</h4>
                <div class="block-area" id="tableHover">
                    <h3 class="block-title">View All Opened Tickets</h3>
                    <div class="table-responsive overflow" style="overflow: hidden;" tabindex="5001">
                        <table class="table table-bordered table-hover tile">
                            <thead>
		
                                <tr>
                                    <th>Ticket Number</th>
                                    <th>View Ticket</th>
									<th>Sender</th>
									<th>Subject</th>
                                    <th>Message</th>
                                    <th>Date Opened</th>
                                    <th>Status</th>
                                   
                                </tr>
                            </thead>
                            
                            <tbody>
							<?php
                                $ticketlist = Admintools::Tickets();
                                for($u7 = 0; $u7<count($ticketlist); $u7++){
                                    $thisTicket = $ticketlist[$u7];
                                    ?>

			                        <tr>
                                    <td><?php print $thisTicket['id']; ?> </td>
                                    <td><a class="btn btn-xs btn-default" href="viewticket.php?id=<?php print $thisTicket['id']; ?>">View</a></td>
                                    <td><?php print $thisTicket['owner']; ?></td>
                                    <td><?php print $thisTicket['subject']; ?></td>
                                    <td><?php print $thisTicket['message']; ?></td>
                                    <td><?php print date("Y-m-d h:i",$thisTicket['date']); ?></td>
                                    <td><?php print $thisTicket['status']; ?></td>
                                    
                                </tr>
                                    <?php
                                }
                            ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <hr class="whiter m-t-20">
			</section>
        