<?php
    $manager = new Manager;
    $manager->isLogged();
    if(isset($_GET['id'])){
        $thisPerson = AdminTools::FetchUser($_GET['id']);
        if(in_array("error",$thisPerson)){
            print  $thisPerson[0];
            goto endl;
        }
//print_r($thisPerson);

    }else{
        print "Invalid parameter";
        goto endl;
    }
?>
 <section id="content" class="container">
            <h4 class="page-title block-title">Create Account</h4>

            <!-- Required Feilds -->
            <div class="block-area" id="required">
                <h4 class="">Fill the form accurately</h4>
                <form role="form" class="form-validation-1" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                        <div class="col-md-3 form-group">
                            <label>First Name</label>
                            <input name="fname" value="<?php print($thisPerson['firstname']); ?>" class="input-sm validate[required] form-control" placeholder="First Name" type="text">
                        </div>
                        <div class="col-md-3 form-group">
                            <label>Middle Name (Optional)</label>
                            <input name="mname" value="<?php print $thisPerson['middlename']; ?>"  class="input-sm form-control" placeholder="Middle Name" type="text">
                        </div>
                        <div class="col-md-3 form-group">
                            <label>Last Name</label>
                            <input name="lname"  value="<?php print $thisPerson['lastname']; ?>" class="input-sm validate[required] form-control" placeholder="Last Name" type="text">
                        </div>
                        <div class="col-md-3 form-group">
                            <label>Username</label>
                            <input name="uname" value="<?php print $thisPerson['username']; ?>"  class="input-sm validate[required] form-control" placeholder="Username" type="text">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 form-group">
                            <label>Password</label>
                            <input name="upass" class="input-sm validate[required] form-control" placeholder="Password" type="text"  value="<?php print $thisPerson['password']; ?>" >
                        </div>
                        <div style="display:none" class="col-md-3 form-group">
                            <label>Retype Password</label>
                            <input name="cupass" class="input-sm validate[required] form-control" placeholder="Retype Password" type="password">
                        </div>
                        <div class="col-md-3 form-group">
                            <label>Phone</label>
                            <input name="phone"  value="<?php print $thisPerson['phone']; ?>" class="input-sm validate[required] form-control" placeholder="Phone Number" type="text">
                        </div>
                        <div class="col-md-3 form-group">
                            <label>Email</label>
                            <input name="email"  value="<?php print $thisPerson['email']; ?>" class="input-sm validate[required] form-control" placeholder="Email" type="email">
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-3 form-group">
                            <label>Occupation</label>
                            <input name="work"  value="<?php print $thisPerson['occupation']; ?>"  class="input-sm validate[required] form-control" placeholder="Occupation" type="text">
                        </div>
                        <div class="col-md-2 form-group" id="date-time">

                            <label>Date of Birth</label>
                            <div class="input-icon datetime-pick date-only">
                                <input data-format="dd/MM/yyyy"  value="<?php print $thisPerson['dob']; ?>" name="dob" placeholder="Select Date of Birth" class="form-control input-sm" type="text">
                                <span class="add-on">
                                    <i class="sa-plus icon-calendar"></i>
                                </span>
                            </div>
                        </div>

                        <div class="col-md-2 form-group">
                            <label>Marital Status</label>
                            <select name="marry" class="form-control input-sm validate[required]">
                                <option value="Single">Single</option>
                                <option selected="selected"><?php print $thisPerson['maritalstatus']; ?></option> 
                                <option value="Married">Married</option>
                                <option value="Widowed">Widowed</option>
                                <option value="Divorced">Divorced</option>
                            </select>
                        </div>
                        <div class="col-md-2 form-group">
                            <label>Gender</label>
                            <select name="sex" class="form-control input-sm validate[required]">
                            <option selected="selected"><?php print $thisPerson['gender']; ?></option> 
                                <option value="Male" >Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Address</label>
                            <textarea name="addr" class="input-sm validate[required] form-control" placeholder="House or Office Address"><?php print $thisPerson['address']; ?></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 form-group">
                            <label>Account Type</label>
                            <select name="type" class="form-control input-sm validate[required]">
                            <option selected="selected"><?php print $thisPerson['accountype']; ?></option> 
                                <option value="Savings" selected="selected">Savings</option>
                                <option value="Current">Current</option>
                            </select>
                        </div>
                        <div class="col-md-3 form-group" id="date-time">

                            <label>Registration Date</label>
                            <div class="input-icon datetime-pick date-only">
                                <input data-format="dd/MM/yyyy"  value="<?php print $thisPerson['registrationdate']; ?>"  name="reg_date" placeholder="Select Reg Date" class="form-control input-sm" type="text">
                                <span class="add-on">
                                    <i class="sa-plus icon-calendar"></i>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-3 form-group">
                            <label>Total Balance</label>
                            <input name="t_bal"  value="<?php print $thisPerson['totalbalance']; ?>"  class="input-sm validate[required] form-control" placeholder="Total Balance" type="number">
                        </div>
                        <div class="col-md-3 form-group">
                            <label>Available Balance</label>
                            <input name="a_bal"  value="<?php print $thisPerson['accountbalance']; ?>" class="input-sm validate[required] form-control" placeholder="Available Balance" type="number">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 form-group">
                            <label>Account Number</label>
                            <input name="acc_no" class="input-sm validate[required] form-control" placeholder="Assign Account Number"  value="<?php print $thisPerson['accountnumber']; ?>" type="text">
                        </div>

                        <div class="col-md-3 form-group">
                            <label>Account Currency</label>
                            <select class="input-sm validate[required] form-control" name="currency">
                                <option><?php print $thisPerson['dob']; ?></option>
                                <option value="$" selected="selected">Dollar</option>
                                <option value="£">Pound</option>
                                <option value="€">Euro</option>

                            </select>
                        </div>

                        <div class="col-md-2 form-group">
                            <label>COT Code</label>
                            <input name="cot"  value="<?php print $thisPerson['cotcode']; ?>" class="input-sm validate[required] form-control" placeholder="Assign COT Code" type="text">
                        </div>

                        <div class="col-md-2 form-group">
                            <label>Tax Code</label>
                            <input name="tax" value="<?php print $thisPerson['taxcode']; ?>"  class="input-sm validate[required] form-control" placeholder="Assign Tax Code" type="text">
                        </div>

                        <div class="col-md-2 form-group">
                            <label>IMF Code</label>
                            <input name="imf"  value="<?php print $thisPerson['imfcode']; ?>"  class="input-sm validate[required] form-control" placeholder="Assign Tax Code" type="text">
                        </div>
                    </div>
                    <input type="hidden" name=thisaid value="<?php print $_GET['id']; ?>"/>
                    
           
            <?php endl: ?>
            </div>


            <div class="clearfix"></div>
            <br>
            <input class="btn btn-md " value="Reset" type="reset">
            <button class="btn btn-md" name="create">Update</button>
  </form>
            
            

            <hr class="whiter m-t-20">
        </section>
       
