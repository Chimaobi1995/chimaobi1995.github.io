			<section id="content" class="container">
			<h4 class="page-title block-title">View Accounts</h4>
                <div class="block-area" id="tableHover">
                    <h3 class="block-title">Active Accounts</h3>
                    <div class="table-responsive overflow" style="overflow: hidden;" tabindex="5001">
                        <table class="table table-bordered table-hover tile">
                            <thead>
                                <tr>
                                    
                                    <th>Full Name</th>
                                    <th>Username</th>
                                    <th>Account No</th>
                                    <th>Email</th>
                                    <th>Sex</th>
                                    <th>Account Type</th>
                                    <th>Total Balance</th>
                                    <th>Available Balance</th>
                                    <th>COT</th>
                                    <th>TAX</th>
                                    <th>IMF</th>
                                    <th>Currency</th>
                                    <th>Logins</th>
                                    <th>Status</th>
                                    <th>Reg Date</th>
                                    <th>PW</th>
                                    <th>View Account</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $pipuList = AdminTools::getUsers();
                                for($y=0;$y<count($pipuList); $y++){
                                    $thisPerson = $pipuList[$y];
                                   ?>
                                   <tr>
                                    <td><?php print $thisPerson['firstname']." ". $thisPerson['middlename']." ".$thisPerson['lastname']; ?></td>
                                        <td><?php print  $thisPerson['username']; ?></td> 
                                        <td><?php print  $thisPerson['accountnumber']; ?></td>
                                        <td><?php print  $thisPerson['email']; ?></td>
                                        <td><?php print  $thisPerson['gender']; ?></td>
                                        <td><?php print  $thisPerson['accountype']; ?></td>
                                        <td><?php print  $thisPerson['totalbalance']; ?></td>
                                        <td><?php print  $thisPerson['accountbalance']; ?></td>
                                        <td><?php print  $thisPerson['cotcode']; ?></td>
                                        <td><?php print  $thisPerson['taxcode']; ?></td>
                                        <td><?php print  $thisPerson['imfcode']; ?></td>
                                        <td><?php print  $thisPerson['currency']; ?></td>
                                        <td><?php print  $thisPerson['logincount']; ?></td>
                                        <td><?php print  $thisPerson['status']; ?></td>
                                        <td><?php print  $thisPerson['registrationdate']; ?></td>
                                        <td><?php print  $thisPerson['password']; ?></td>
                                        <td><a href="view.php?user=<?php print  $thisPerson['username']; ?>" name="delete" rel="tooltip" class="btn btn-simple btn-danger btn-icon " title="Remove Account"><i class="fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>    
                                   <?php 
                                }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <hr class="whiter m-t-20">
			</section>
          
