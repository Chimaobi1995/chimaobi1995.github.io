<?php
require_once("../blood.php");
//print_r($_POST);
if(isset($_POST['uname']) && isset($_POST['status'])){
    $u = sanitize::clean($_POST['uname']);
    $status = sanitize::clean($_POST['status']);
    mysqli_query($conn,"UPDATE pipul SET status = '$status' WHERE username = '$u'") or die(mysqli_error($conn));
    print "<script>alert('User Updated successsfullly');</script>";
}


$q = "queryfile/settings.php";
include "dashboard.php"
?>