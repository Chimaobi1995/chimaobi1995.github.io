<?php
session_start();
if(isset($_POST['fname']) && isset($_POST['acc_no'])){
    require "../blood.php";
    function clean($h){
        return sanitize::clean($h);
    }
    function sendEmail($subj,$mesej,$from_,$to){
        $msg = file_get_contents("../../client/emailtemplate.php");
        $content = str_replace("{MAILBODY}",$mesej,$msg);
        $content = str_replace("{SUBJECT}",$subj,$content);
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: $from_" . "\r\n";

        return mail($to,$subj,$content,$headers);

    }
    function sendSMS($mesej,$nomba){
        $curl = curl_init();
        $Q1 = configs::smsAPI;
        $Q1 = str_replace("%%destination%%",urlencode($nomba),$Q1);
        $Q1 = str_replace("%%message%%",urlencode($mesej),$Q1);
        $Q1 = str_replace("%%sender%%",urlencode(configs::smssenderid),$Q1);
        //$Q1 = str_replace("%%sender%%",urlencode(configs::bkname),$Q1);

        //print $Q1;
        //die();
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => $Q1
        ));
        $res_send = curl_exec($curl);
        curl_close($curl);
        // print $res_send;
        //die();


    }

	
    $mname = clean($_POST['mname']);
    $fname = clean($_POST['fname']);
	$lname = clean($_POST['lname']);
	$uname = clean($_POST['uname']);
	$upass = clean($_POST['upass']);
	$phone = clean($_POST['phone']);
	$email = clean($_POST['email']);
	$work = clean($_POST['work']);
	$dob = clean($_POST['dob']);
	$regdate = clean($_POST['reg_date']);
	$marry = clean($_POST['marry']);
	$sex = clean($_POST['sex']);
	$addr = clean($_POST['addr']);
	$type = clean($_POST['type']);
	$t_bal = clean($_POST['t_bal']);
	$a_bal = clean($_POST['a_bal']);
	$acct_no = clean($_POST['acc_no']);
	$currency = clean($_POST['currency']);
	$cot = clean($_POST['cot']);
    $tax = clean($_POST['tax']);
    $imf = clean($_POST['imf']);
	
	$img = "passports/$uname.jpg";
	
	foreach($_POST as $post){
		if($post == ""){
			$_SESSION['msg'] = "Invalid Account Details";
//			print $_SESSION['msg'];
			goto skip;
		}
	}
	$newU = "INSERT INTO `pipul`(`accountnumber`, `username`, `firstname`, `middlename`, `lastname`, `password`, `phone`, `email`, `occupation`, `dob`, `maritalstatus`, `gender`, `address`, `accountype`, `registrationdate`, `totalbalance`, `accountbalance`, `currency`, `cotcode`, `taxcode`, `imfcode`) VALUES ('$acct_no','$uname','$fname','$mname','$lname','$upass','$phone','$email','$work','$dob','$marry','$sex','$addr','$type','$regdate','$t_bal','$a_bal','$currency','$cot','$tax','$imf')";
    mysqli_query($conn,$newU) or die(mysqli_error($conn));
    if(mysqli_affected_rows($conn)>0){

		//copy avartar
		$macopy = @copy("../passports/0.jpg","../passports/$uname.jpg");
		//die($macopy);
        $_SESSION['msg'] = "New Account created successfully";

        $msg = '<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="x-apple-disable-message-reformatting">
    <title></title>
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,600" rel="stylesheet" type="text/css">
<style>
        /* What it does: Remove spaces around the email design added by some email clients. */
        /* Beware: It can remove the padding / margin and add a background color to the compose a reply window. */
        html,
        body {
            margin: 0 auto !important;
            padding: 0 !important;
            height: 100% !important;
            width: 100% !important;
            font-family: "Roboto", sans-serif !important;
            font-size: 14px;
            margin-bottom: 10px;
            line-height: 24px;
            color:#8094ae;
            font-weight: 400;
        }
        * {
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
            margin: 0;
            padding: 0;
        }
        table,
        td {
            mso-table-lspace: 0pt !important;
            mso-table-rspace: 0pt !important;
        }
        table {
            border-spacing: 0 !important;
            border-collapse: collapse !important;
            table-layout: fixed !important;
            margin: 0 auto !important;
        }
        table table table {
            table-layout: auto;
        }
        a {
            text-decoration: none;
        }
        img {
            -ms-interpolation-mode:bicubic;
        }
    </style>

</head>

<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #f5f6fa;">
	<center style="width: 100%; background-color: #f5f6fa;">
        <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#f5f6fa">
            <tr>
               <td style="padding: 40px 0;">
                    <table style="width:100%;max-width:620px;margin:0 auto;">
                        <tbody>
                            <tr>
                                <td style="text-align: center; padding-bottom:25px">
                                    <a href="#"><img style="height: 40px" src="'.configs::logo.'/logo.png" alt="logo"></a>
                                    <p style="font-size: 14px; color: #6576ff; padding-top: 12px;">New Account Creation</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table style="width:100%;max-width:620px;margin:0 auto;background-color:#ffffff;">
                        <tbody>
                            <tr>
                                <td style="padding: 30px 30px 20px">
                                    <p style="margin-bottom: 10px;">Hi '.$fname.',</p>
                                    <p style="margin-bottom: 10px;">We are pleased to inform you that your account has been created successfully.</p>
                                    <p style="margin-bottom: 15px;">We hope you will enjoy the our banking experience, we are here if you have any questions, send us message at <a style="color: #6576ff; text-decoration:none;"> '.configs::email102.' </a> anytime. </p>
                                
								<p>here is your initial login details</p>
								<p>Username: '.$uname.'</p> 
								<p>Password: '.$upass.' </p>
								</td>
                            </tr>
                        </tbody>
                    </table>
                    <table style="width:100%;max-width:620px;margin:0 auto;">
                        <tbody>
                            <tr>
                                <td style="text-align: center; padding:25px 20px 0;">
                                    <p style="font-size: 13px;">© '.configs::bkname.' <br> All rights reserved. </p>
                                    <ul style="margin: 10px -4px 0;padding: 0;">
                                        <li style="display: inline-block; list-style: none; padding: 4px;"><a style="display: inline-block; height: 30px; width:30px;border-radius: 50%; background-color: #ffffff" href="#"><img style="width: 30px" src="'.configs::url.'/img/brand-b.png" alt="brand"></a></li>
                                        <li style="display: inline-block; list-style: none; padding: 4px;"><a style="display: inline-block; height: 30px; width:30px;border-radius: 50%; background-color: #ffffff" href="#"><img style="width: 30px" src="'.configs::url.'/img/brand-e.png" alt="brand"></a></li>
                                        <li style="display: inline-block; list-style: none; padding: 4px;"><a style="display: inline-block; height: 30px; width:30px;border-radius: 50%; background-color: #ffffff" href="#"><img style="width: 30px" src="'.configs::url.'/img/brand-d.png" alt="brand"></a></li>
                                        <li style="display: inline-block; list-style: none; padding: 4px;"><a style="display: inline-block; height: 30px; width:30px;border-radius: 50%; background-color: #ffffff" href="#"><img style="width: 30px" src="'.configs::url.'/img/brand-c.png" alt="brand"></a></li>
                                    </ul>
                                    <p style="padding-top: 15px; font-size: 12px;">This email was sent to you as an Account Owner to <a style="color: #6576ff; text-decoration:none;">'.configs::bkname.'</a></p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
               </td>
            </tr>
        </table>
    </center>
</body>
</html>';

        sendSMS($msg,$phone);
        //sendEmail("Account Creation Notification",str_replace("\n","<br/>",$msg),configs::email102,$email);
         $to = $email;
        $subject = 'Account Creation Notification';
		$headers = "From: ".configs::email102."\r\n";
		$headers .= "Reply-To: ".configs::email102."\r\n";
		//$headers .= "CC: susan@example.com\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
		mail($to, $subject, $msg, $headers);

	}
	skip:
	
}







$q = "queryfile/createaccount.php";
include "dashboard.php"
?>