<?php
$q = "queryfile/tickets.php";
include "dashboard.php"
?>