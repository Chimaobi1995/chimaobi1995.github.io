<?php
$q = "queryfile/pendingaccounts.php";
include "dashboard.php"
?>