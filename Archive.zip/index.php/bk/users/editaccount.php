<?php
if(isset($_POST['fname']) && isset($_POST['acc_no'])){
    require_once("../blood.php");
    function clean($h){
        return sanitize::clean($h);
    }
	
    $mname = clean($_POST['mname']);
    $fname = clean($_POST['fname']);
	$lname = clean($_POST['lname']);
	$uname = clean($_POST['uname']);
	$upass = clean($_POST['upass']);
	$phone = clean($_POST['phone']);
	$email = clean($_POST['email']);
	$work = clean($_POST['work']);
	$dob = clean($_POST['dob']);
	$regdate = clean($_POST['reg_date']);
	$marry = clean($_POST['marry']);
	$sex = clean($_POST['sex']);
	$addr = clean($_POST['addr']);
	$type = clean($_POST['type']);
	$t_bal = clean($_POST['t_bal']);
	$a_bal = clean($_POST['a_bal']);
	$acc_no = clean($_POST['acc_no']);
	$currency = clean($_POST['currency']);
	$cot = clean($_POST['cot']);
    $tax = clean($_POST['tax']);
    $imf = clean($_POST['imf']);
    $thisaid = clean($_POST['thisaid']);
	
	$img = "passports/$uname.jpg";

    //$newU = "INSERT INTO `pipul`(`accountnumber`, `username`, `firstname`, `middlename`, `lastname`, `password`, `phone`, `email`, `occupation`, `dob`, `maritalstatus`, `gender`, `address`, `accountype`, `registrationdate`, `totalbalance`, `accountbalance`, `currency`, `cotcode`, `taxcode`, `imfcode`) VALUES ('$acct_no','$uname','$fname','$mname','$lname','$upass','$phone','$email','$work','$dob','$marry','$sex','$addr','$type','$regdate','$t_bal','$a_bal','$currency','$cot','$tax','$imf')";
    $updU = "UPDATE `pipul` SET `username`='$uname',`accountnumber`='$acc_no',`firstname`='$fname',`middlename`='$mname',`lastname`='$lname',`password`='$upass',`phone`='$phone',`email`='$email',`occupation`='$work',`dob`='$dob',`maritalstatus`='$marry',`gender`='$sex',`address`='$addr',`accountype`='$type',`registrationdate`='$regdate',`totalbalance`='$t_bal',`accountbalance`='$a_bal',`currency`='$currency',`cotcode`='$cot',`taxcode`='$tax',`imfcode`='$imf' WHERE aid='$thisaid'";
    //die($updU);
    mysqli_query($conn,$updU) or die(mysqli_error($conn));
    if(mysqli_affected_rows($conn)>0){
        $_SESSION['msg'] = "Account modified successfully";
    }
}

$q = "queryfile/editaccount.php";
include "dashboard.php"
?>