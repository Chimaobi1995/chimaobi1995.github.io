<?php
require_once("../blood.php");
if(isset($_POST['delid'])){
    $delid = sanitize::clean($_POST['delid']);
    mysqli_query($conn,"DELETE FROM pipul WHERE aid = '$delid' LIMIT 1") OR die(mysqli_error($conn));
    if(mysqli_affected_rows($conn)>0){
        header("Location: update.php");
    }
}
$q = "queryfile/delete.php";
include "dashboard.php"
?>