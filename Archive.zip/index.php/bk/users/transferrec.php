<?php
session_start();
$q = "queryfile/transferrec.php";
include "dashboard.php"
?>