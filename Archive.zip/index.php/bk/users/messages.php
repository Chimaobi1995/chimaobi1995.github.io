<?php
require_once("../blood.php");
if(isset($_POST['sender_name'])){
    $owner = sanitize::clean($_POST['reci_name']);
    $nowunix = strtotime("now");
    $sender = sanitize::clean($_POST['sender_name']);
    $subject = sanitize::clean($_POST['subject']);
    $content = sanitize::clean($_POST['msg']);

    mysqli_query($conn,"INSERT INTO `messages`( `owner`, `date`, `sender`, `subject_`, `content`, `isread`) VALUES ('$owner','$nowunix','$sender','$subject','$content','no')") or die(mysqli_error($conn));
    header("Location: messages.php");
    //die();
}
$q = "queryfile/messages.php";
include "dashboard.php"
?>