<?php
require_once("../blood.php");
$manager = new Manager;
$manager->islogged();

?><!DOCTYPE html>
<!--[if IE 9 ]><html class="ie9"><![endif]-->
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><script async="" src="assets/load"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <meta name="format-detection" content="telephone=no">
        <meta charset="UTF-8">

        <meta name="description" content="">
        <meta name="keywords" content="">
        <link rel="icon" href="img/favicon.png" type="image/x-icon">

        <title><?= configs::bkname; ?> | Admin Panel</title>

        <!-- CSS -->
		<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <link href="assets/bootstrap.css" rel="stylesheet">
        <link href="assets/animate.css" rel="stylesheet">
        <!--link rel="stylesheet" href="assets/font-awesome.css"-->
        <link href="assets/form.css" rel="stylesheet">
        <link href="assets/calendar.css" rel="stylesheet">
        <link href="assets/style.css" rel="stylesheet">
        <link href="assets/icons.css" rel="stylesheet">
        <link href="assets/generics.css" rel="stylesheet"> 
        <link rel="stylesheet" href="fontawesome/css/fontawesome.css"> 
        
    <style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.8);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style></head>
    <body id="skin-blur-kiwi">
        <?php
      // print_r($_SESSION);
        if(isset($_SESSION['msg'])){
            print "<div class='alert alert-danger'>".$_SESSION['msg']."</div>";
            print "<script>alert('".$_SESSION['msg']."');</script>";
            unset($_SESSION['msg']);
        }
        ?>
        <header id="header" class="media">
            <a href="" id="menu-toggle"></a> 
            <a class="logo pull-left" href=""><img src="" class="img-responsive" alt=""></a>

            <div class="media-body">
                <div class="media" id="top-menu">
                    <div class="pull-left tm-icon">
                        <a data-drawer="messages">
                            <i class="sa-top-message"></i>
                            <i class="n-count animated"><?php print systemLogs::messages(); ?>
</i>
                            <span>Tickets</span>
                        </a>
                    </div>
                    <div id="time" class="pull-right">
                        <span id="hours">13</span>
                        :
                        <span id="min">36</span>
                        :
                        <span id="sec">18</span>
                    </div>


                </div>
            </div>
        </header>

        <div class="clearfix"></div>

        <section id="main" class="p-relative" role="main">

            <!-- Sidebar -->
            <aside id="sidebar">

                <!-- Sidbar Widgets -->
                <div class="side-widgets overflow" style="overflow: hidden;" tabindex="5000">
                    <!-- Profile Menu -->
                    <div class="text-center s-widget m-b-25 dropdown" id="profile-menu">
                        <a href="#" data-toggle="dropdown">
                            <!--img class="profile-pic animated" src="assets/htb.jpg" alt="Profile Pic"-->
                        </a>
                        <ul class="dropdown-menu profile-menu">

                            <li><a href="#">Sign Out</a><i class="right fa fa-sign-out fa-2x"></i></li>
                            <li><a href="#edit" data-toggle="modal">Edit Profile</a><i class="right fa fa-edit fa-2x"></i></li>
                        </ul>
                        <h4 class="m-0"><?= configs::bkname; ?></h4>

                    </div>

                    <!-- Calendar -->
                    <div class="s-widget m-b-25">
                        <div id="sidebar-calendar" class="fc fc-ltr"><table class="fc-header" style="width:100%"><tbody><tr><td class="fc-header-left"><span class="fc-header-title"><h2>July 2018</h2></span></td><td class="fc-header-center"></td><td class="fc-header-right"><span class="fc-button fc-button-prev fc-state-default fc-corner-left" unselectable="on" style="-moz-user-select: none;"><span class="fc-text-arrow"><i class="fa fa-angle-left"></i></span></span><span class="fc-button fc-button-today fc-state-default fc-state-disabled" unselectable="on" style="-moz-user-select: none;">Today</span><span class="fc-button fc-button-next fc-state-default fc-corner-right" unselectable="on" style="-moz-user-select: none;"><span class="fc-text-arrow"><i class="fa fa-angle-right"></i></span></span></td></tr></tbody></table><div class="fc-content" style="position: relative;"><div class="fc-view block fc-view-month fc-grid" style="position: relative; -moz-user-select: none;" unselectable="on"><div class="fc-event-container" style="position:absolute;z-index:8;top:0;left:0"></div><table class="fc-border-separate" cellspacing="0"><thead><tr class="fc-first fc-last"><th class="fc-day-header fc-sun fc-widget-header fc-first" style="width: 26px;">Sun</th><th class="fc-day-header fc-mon fc-widget-header" style="width: 26px;">Mon</th><th class="fc-day-header fc-tue fc-widget-header" style="width: 26px;">Tue</th><th class="fc-day-header fc-wed fc-widget-header" style="width: 26px;">Wed</th><th class="fc-day-header fc-thu fc-widget-header" style="width: 26px;">Thu</th><th class="fc-day-header fc-fri fc-widget-header" style="width: 26px;">Fri</th><th class="fc-day-header fc-sat fc-widget-header fc-last">Sat</th></tr></thead><tbody><tr class="fc-week fc-first"><td class="fc-day fc-sun fc-widget-content fc-past fc-first" data-date="2018-07-01"><div style="min-height: 19px;"><div class="fc-day-number">1</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-past" data-date="2018-07-02"><div><div class="fc-day-number">2</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-past" data-date="2018-07-03"><div><div class="fc-day-number">3</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-past" data-date="2018-07-04"><div><div class="fc-day-number">4</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-past" data-date="2018-07-05"><div><div class="fc-day-number">5</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-past" data-date="2018-07-06"><div><div class="fc-day-number">6</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-past fc-last" data-date="2018-07-07"><div><div class="fc-day-number">7</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week"><td class="fc-day fc-sun fc-widget-content fc-past fc-first" data-date="2018-07-08"><div style="min-height: 18px;"><div class="fc-day-number">8</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-past" data-date="2018-07-09"><div><div class="fc-day-number">9</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-past" data-date="2018-07-10"><div><div class="fc-day-number">10</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-past" data-date="2018-07-11"><div><div class="fc-day-number">11</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-today fc-state-highlight" data-date="2018-07-12"><div><div class="fc-day-number">12</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-future" data-date="2018-07-13"><div><div class="fc-day-number">13</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-future fc-last" data-date="2018-07-14"><div><div class="fc-day-number">14</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week"><td class="fc-day fc-sun fc-widget-content fc-future fc-first" data-date="2018-07-15"><div style="min-height: 18px;"><div class="fc-day-number">15</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-future" data-date="2018-07-16"><div><div class="fc-day-number">16</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-future" data-date="2018-07-17"><div><div class="fc-day-number">17</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-future" data-date="2018-07-18"><div><div class="fc-day-number">18</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-future" data-date="2018-07-19"><div><div class="fc-day-number">19</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-future" data-date="2018-07-20"><div><div class="fc-day-number">20</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-future fc-last" data-date="2018-07-21"><div><div class="fc-day-number">21</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week"><td class="fc-day fc-sun fc-widget-content fc-future fc-first" data-date="2018-07-22"><div style="min-height: 18px;"><div class="fc-day-number">22</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-future" data-date="2018-07-23"><div><div class="fc-day-number">23</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-future" data-date="2018-07-24"><div><div class="fc-day-number">24</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-future" data-date="2018-07-25"><div><div class="fc-day-number">25</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-future" data-date="2018-07-26"><div><div class="fc-day-number">26</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-future" data-date="2018-07-27"><div><div class="fc-day-number">27</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-future fc-last" data-date="2018-07-28"><div><div class="fc-day-number">28</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week"><td class="fc-day fc-sun fc-widget-content fc-future fc-first" data-date="2018-07-29"><div style="min-height: 18px;"><div class="fc-day-number">29</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-future" data-date="2018-07-30"><div><div class="fc-day-number">30</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-future" data-date="2018-07-31"><div><div class="fc-day-number">31</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-other-month fc-future" data-date="2018-08-01"><div><div class="fc-day-number">1</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-other-month fc-future" data-date="2018-08-02"><div><div class="fc-day-number">2</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-other-month fc-future" data-date="2018-08-03"><div><div class="fc-day-number">3</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-other-month fc-future fc-last" data-date="2018-08-04"><div><div class="fc-day-number">4</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr><tr class="fc-week fc-last"><td class="fc-day fc-sun fc-widget-content fc-other-month fc-future fc-first" data-date="2018-08-05"><div style="min-height: 22px;"><div class="fc-day-number">5</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-mon fc-widget-content fc-other-month fc-future" data-date="2018-08-06"><div><div class="fc-day-number">6</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-tue fc-widget-content fc-other-month fc-future" data-date="2018-08-07"><div><div class="fc-day-number">7</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-wed fc-widget-content fc-other-month fc-future" data-date="2018-08-08"><div><div class="fc-day-number">8</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-thu fc-widget-content fc-other-month fc-future" data-date="2018-08-09"><div><div class="fc-day-number">9</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-fri fc-widget-content fc-other-month fc-future" data-date="2018-08-10"><div><div class="fc-day-number">10</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td><td class="fc-day fc-sat fc-widget-content fc-other-month fc-future fc-last" data-date="2018-08-11"><div><div class="fc-day-number">11</div><div class="fc-day-content"><div style="position: relative; height: 0px;">&nbsp;</div></div></div></td></tr></tbody></table></div></div></div>
                    </div>

                    <!-- Feeds -->
                    <div class="s-widget m-b-25">
                        <h2 class="tile-title">
                            Developer Info
                        </h2>
                        <div class="">

                            <p><i class="fa fa-skype fa-2x"></i> <a href="mailto:garymorgado02@gmail.com">Black Monsters</a></p>
                        </div>
                        <div class="s-widget-body">
                            <div id="news-feed"></div>
                        </div>
                    </div>

                    <!-- Projects -->

                </div>

                <!-- Side Menu -->
                <ul class="list-unstyled side-menu">
                    <li class="active">
                        <a class="sa-side-home" href="index.php">
                            <span class="menu-item">Dashboard</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a class="sa-list-vcard" href="">
                            <span class="menu-item">Accounts</span>
                        </a>
                        <ul class="list-unstyled menu-item">
                            <li><a href="createaccount.php">Create Account</a></li>
                            <li><a href="viewaccount.php">View Accounts</a></li>
                            <li><a href="update.php">Update Accounts</a></li>
                            <li><a href="upload.php">Upload Image</a></li>
                            <!--li><a href="upload.php"></a></li-->
                        </ul>
                    </li>
                    <li>
                        <a class="sa-list-secret" href="pendingaccounts.php">
                            <span class="menu-item">Pending Accounts</span>
                        </a>
                    </li>
                    <li>
                        <a class="sa-top-message" href="messages.php">
                            <span class="menu-item">Messages</span>
                        </a>
                    </li>
                    <li>
                        <a class="sa-list-comment" href="tickets.php">
                            <span class="menu-item">Tickets</span>
                        </a>
                    </li>
                    <li>
                        <a class="sa-list-database" href="creditdebitlist.php">
                            <span class="menu-item">Credit/Debit History</span>
                        </a>
                    </li>
                    <li>
                        <a class="sa-list-cc" href="transferrec.php">
                            <span class="menu-item">Transaction Records</span>
                        </a>
                    </li>
                    <li>
                        <a class="sa-list-cog" href="settings.php">
                            <span class="menu-item">Settings</span>
                        </a>
                    </li>
                    <li>
                        <a class="sa-list-cog" href="../logout.php">
                            <span class="menu-item">Logout</span>
                        </a>
                    </li>

                </ul>

            </aside>

           
	<?php include $q; ?>

        <!-- Javascript Libraries -->
        <!-- jQuery -->
        <script src="assets/jquery.js"></script> <!-- jQuery Library -->
        <script src="assets/jquery-ui.js"></script> <!-- jQuery UI -->
        <script src="assets/custom.js"></script>
        <!-- Bootstrap -->
        <script src="assets/bootstrap.js"></script>

        <!-- Charts -->


        <script src="assets/sparkline.js"></script> <!-- Sparkline - Tiny charts -->
        <script src="assets/easypiechart.js"></script> <!-- EasyPieChart - Animated Pie Charts -->
        <script src="assets/charts.js"></script> <!-- All the above chart related functions -->
        <script src="assets/datetimepicker.js"></script> <!-- Date & Time Picker -->
        <script src="assets/input-mask.js"></script> <!-- Input Mask -->
        <script src="assets/icheck.js"></script> <!-- Custom Checkbox + Radio -->
        <script src="assets/autosize.js"></script> <!-- Textare autosize -->
        <script src="assets/toggler.js"></script> <!-- Toggler -->
		 <script src="fontawesome/js/fontawesome.js"></script>
        <!-- UX -->
        <script src="assets/scroll.js"></script> <!-- Custom Scrollbar -->

        <!-- Other -->
        <script src="assets/calendar.js"></script> <!-- Calendar -->
        <script src="assets/feeds.js"></script> <!-- News Feeds -->


        <!-- All JS functions -->
        <script src="assets/functions.js"></script>
        <script src="assets/markdown.js"></script> <!-- Markdown Editor -->
        <script type="text/javascript">
            $(document).ready(function() {
                /* Tag Select */
                (function() {
                    /* Limited */
                    $(".tag-select-limited").chosen({
                        max_selected_options: 5
                    });

                    /* Overflow */
                    $('.overflow').niceScroll();
                })();

                /* Input Masking - you can include your own way */
                (function() {
                    $('.mask-date').mask('00/00/0000');
                    $('.mask-time').mask('00:00:00');
                    $('.mask-date_time').mask('00/00/0000 00:00:00');
                    $('.mask-cep').mask('00000-000');
                    $('.mask-phone').mask('0000-0000');
                    $('.mask-phone_with_ddd').mask('(00) 0000-0000');
                    $('.mask-phone_us').mask('(000) 000-0000');
                    $('.mask-mixed').mask('AAA 000-S0S');
                    $('.mask-cpf').mask('000.000.000-00', {reverse: true});
                    $('.mask-money').mask('000,000,000,000,000.00', {reverse: true});
                    $('.mask-money2').mask("#.##0,00", {reverse: true, maxlength: false});
                    $('.mask-ip_address').mask('0ZZ.0ZZ.0ZZ.0ZZ', {translation: {'Z': {pattern: /[0-9]/, optional: true}}});
                    $('.mask-ip_address').mask('099.099.099.099');
                    $('.mask-percent').mask('##0,00%', {reverse: true});
                    $('.mask-credit_card').mask('0000 0000 0000 0000');
                })();

                /* Spinners */
                (function() {
                    //Basic
                    $('.spinner-1').spinedit();

                    //Set Value
                    $('.spinner-2').spinedit('setValue', 100);

                    //Set Minimum                    
                    $('.spinner-3').spinedit('setMinimum', -10);

                    //Set Maximum                    
                    $('.spinner-4').spinedit('setMaxmum', 100);

                    //Set Step
                    $('.spinner-5').spinedit('setStep', 10);

                    //Set Number Of Decimals
                    $('.spinner-6').spinedit('setNumberOfDecimals', 2);
                })();
            });
        </script>
    

<div id="ascrail2000" class="nicescroll-rails" style="width: 6px; z-index: auto; cursor: default; position: absolute; top: 50px; left: 227px; height: 646px; display: none; opacity: 0;"><div style="position: relative; top: 0px; float: right; width: 6px; height: 0px; background-color: rgba(0, 0, 0, 0.7); background-clip: padding-box;"></div></div><div id="ascrail2000-hr" class="nicescroll-rails" style="height: 6px; z-index: auto; top: 690px; left: 45px; position: absolute; cursor: default; display: none; opacity: 0;"><div style="position: relative; top: 0px; height: 6px; width: 0px; background-color: rgba(0, 0, 0, 0.7); background-clip: padding-box; left: 0px;"></div></div><div class="bootstrap-datetimepicker-widget dropdown-menu"><div class="datepicker"><div class="datepicker-days" style="display: block;"><table class="table-condensed"><thead><tr><th class="prev">‹</th><th colspan="5" class="switch">July 2018</th><th class="next">›</th></tr><tr><th class="dow">Su</th><th class="dow">Mo</th><th class="dow">Tu</th><th class="dow">We</th><th class="dow">Th</th><th class="dow">Fr</th><th class="dow">Sa</th></tr></thead><tbody><tr><td class="day old">24</td><td class="day old">25</td><td class="day old">26</td><td class="day old">27</td><td class="day old">28</td><td class="day old">29</td><td class="day old">30</td></tr><tr><td class="day">1</td><td class="day">2</td><td class="day">3</td><td class="day">4</td><td class="day">5</td><td class="day">6</td><td class="day">7</td></tr><tr><td class="day">8</td><td class="day">9</td><td class="day">10</td><td class="day">11</td><td class="day active">12</td><td class="day">13</td><td class="day">14</td></tr><tr><td class="day">15</td><td class="day">16</td><td class="day">17</td><td class="day">18</td><td class="day">19</td><td class="day">20</td><td class="day">21</td></tr><tr><td class="day">22</td><td class="day">23</td><td class="day">24</td><td class="day">25</td><td class="day">26</td><td class="day">27</td><td class="day">28</td></tr><tr><td class="day">29</td><td class="day">30</td><td class="day">31</td><td class="day new">1</td><td class="day new">2</td><td class="day new">3</td><td class="day new">4</td></tr></tbody></table></div><div class="datepicker-months" style="display: none;"><table class="table-condensed"><thead><tr><th class="prev">‹</th><th colspan="5" class="switch">2018</th><th class="next">›</th></tr></thead><tbody><tr><td colspan="7"><span class="month">Jan</span><span class="month">Feb</span><span class="month">Mar</span><span class="month">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month active">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month">Nov</span><span class="month">Dec</span></td></tr></tbody></table></div><div class="datepicker-years" style="display: none;"><table class="table-condensed"><thead><tr><th class="prev">‹</th><th colspan="5" class="switch">2010-2019</th><th class="next">›</th></tr></thead><tbody><tr><td colspan="7"><span class="year old">2009</span><span class="year">2010</span><span class="year">2011</span><span class="year">2012</span><span class="year">2013</span><span class="year">2014</span><span class="year">2015</span><span class="year">2016</span><span class="year">2017</span><span class="year active">2018</span><span class="year">2019</span><span class="year old">2020</span></td></tr></tbody></table></div></div></div><div class="bootstrap-datetimepicker-widget dropdown-menu"><div class="datepicker"><div class="datepicker-days" style="display: block;"><table class="table-condensed"><thead><tr><th class="prev">‹</th><th colspan="5" class="switch">July 2018</th><th class="next">›</th></tr><tr><th class="dow">Su</th><th class="dow">Mo</th><th class="dow">Tu</th><th class="dow">We</th><th class="dow">Th</th><th class="dow">Fr</th><th class="dow">Sa</th></tr></thead><tbody><tr><td class="day old">24</td><td class="day old">25</td><td class="day old">26</td><td class="day old">27</td><td class="day old">28</td><td class="day old">29</td><td class="day old">30</td></tr><tr><td class="day">1</td><td class="day">2</td><td class="day">3</td><td class="day">4</td><td class="day">5</td><td class="day">6</td><td class="day">7</td></tr><tr><td class="day">8</td><td class="day">9</td><td class="day">10</td><td class="day">11</td><td class="day active">12</td><td class="day">13</td><td class="day">14</td></tr><tr><td class="day">15</td><td class="day">16</td><td class="day">17</td><td class="day">18</td><td class="day">19</td><td class="day">20</td><td class="day">21</td></tr><tr><td class="day">22</td><td class="day">23</td><td class="day">24</td><td class="day">25</td><td class="day">26</td><td class="day">27</td><td class="day">28</td></tr><tr><td class="day">29</td><td class="day">30</td><td class="day">31</td><td class="day new">1</td><td class="day new">2</td><td class="day new">3</td><td class="day new">4</td></tr></tbody></table></div><div class="datepicker-months" style="display: none;"><table class="table-condensed"><thead><tr><th class="prev">‹</th><th colspan="5" class="switch">2018</th><th class="next">›</th></tr></thead><tbody><tr><td colspan="7"><span class="month">Jan</span><span class="month">Feb</span><span class="month">Mar</span><span class="month">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month active">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month">Nov</span><span class="month">Dec</span></td></tr></tbody></table></div><div class="datepicker-years" style="display: none;"><table class="table-condensed"><thead><tr><th class="prev">‹</th><th colspan="5" class="switch">2010-2019</th><th class="next">›</th></tr></thead><tbody><tr><td colspan="7"><span class="year old">2009</span><span class="year">2010</span><span class="year">2011</span><span class="year">2012</span><span class="year">2013</span><span class="year">2014</span><span class="year">2015</span><span class="year">2016</span><span class="year">2017</span><span class="year active">2018</span><span class="year">2019</span><span class="year old">2020</span></td></tr></tbody></table></div></div></div><div class="bootstrap-datetimepicker-widget dropdown-menu"><div class="datepicker"><div class="datepicker-days" style="display: block;"><table class="table-condensed"><thead><tr><th class="prev">‹</th><th colspan="5" class="switch">July 2018</th><th class="next">›</th></tr><tr><th class="dow">Su</th><th class="dow">Mo</th><th class="dow">Tu</th><th class="dow">We</th><th class="dow">Th</th><th class="dow">Fr</th><th class="dow">Sa</th></tr></thead><tbody><tr><td class="day old">24</td><td class="day old">25</td><td class="day old">26</td><td class="day old">27</td><td class="day old">28</td><td class="day old">29</td><td class="day old">30</td></tr><tr><td class="day">1</td><td class="day">2</td><td class="day">3</td><td class="day">4</td><td class="day">5</td><td class="day">6</td><td class="day">7</td></tr><tr><td class="day">8</td><td class="day">9</td><td class="day">10</td><td class="day">11</td><td class="day active">12</td><td class="day">13</td><td class="day">14</td></tr><tr><td class="day">15</td><td class="day">16</td><td class="day">17</td><td class="day">18</td><td class="day">19</td><td class="day">20</td><td class="day">21</td></tr><tr><td class="day">22</td><td class="day">23</td><td class="day">24</td><td class="day">25</td><td class="day">26</td><td class="day">27</td><td class="day">28</td></tr><tr><td class="day">29</td><td class="day">30</td><td class="day">31</td><td class="day new">1</td><td class="day new">2</td><td class="day new">3</td><td class="day new">4</td></tr></tbody></table></div><div class="datepicker-months" style="display: none;"><table class="table-condensed"><thead><tr><th class="prev">‹</th><th colspan="5" class="switch">2018</th><th class="next">›</th></tr></thead><tbody><tr><td colspan="7"><span class="month">Jan</span><span class="month">Feb</span><span class="month">Mar</span><span class="month">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month active">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month">Nov</span><span class="month">Dec</span></td></tr></tbody></table></div><div class="datepicker-years" style="display: none;"><table class="table-condensed"><thead><tr><th class="prev">‹</th><th colspan="5" class="switch">2010-2019</th><th class="next">›</th></tr></thead><tbody><tr><td colspan="7"><span class="year old">2009</span><span class="year">2010</span><span class="year">2011</span><span class="year">2012</span><span class="year">2013</span><span class="year">2014</span><span class="year">2015</span><span class="year">2016</span><span class="year">2017</span><span class="year active">2018</span><span class="year">2019</span><span class="year old">2020</span></td></tr></tbody></table></div></div></div><div class="bootstrap-datetimepicker-widget dropdown-menu"><div class="timepicker"><div class="timepicker-picker"><table class="table-condensed" data-hour-format="12"><tbody><tr><td><a href="#" class="btn" data-action="incrementHours"><i class="fa fa-angle-up"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="incrementMinutes"><i class="fa fa-angle-up"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="incrementSeconds"><i class="fa fa-angle-up"></i></a></td><td class="separator"></td></tr><tr><td><span data-action="showHours" data-time-component="hours" class="timepicker-hour">01</span></td> <td class="separator">:</td><td><span data-action="showMinutes" data-time-component="minutes" class="timepicker-minute">34</span></td> <td class="separator">:</td><td><span data-action="showSeconds" data-time-component="seconds" class="timepicker-second">58</span></td><td class="separator"></td><td><button type="button" class="btn" data-action="togglePeriod">PM</button></td></tr><tr><td><a href="#" class="btn" data-action="decrementHours"><i class="fa fa-angle-down"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="decrementMinutes"><i class="fa fa-angle-down"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="decrementSeconds"><i class="fa fa-angle-down"></i></a></td><td class="separator"></td></tr></tbody></table></div><div class="timepicker-hours" data-action="selectHour" style="display: none;"><table class="table-condensed"><tbody><tr><td class="hour">01</td><td class="hour">02</td><td class="hour">03</td><td class="hour">04</td></tr><tr><td class="hour">05</td><td class="hour">06</td><td class="hour">07</td><td class="hour">08</td></tr><tr><td class="hour">09</td><td class="hour">10</td><td class="hour">11</td><td class="hour">12</td></tr></tbody></table></div><div class="timepicker-minutes" data-action="selectMinute" style="display: none;"><table class="table-condensed"><tbody><tr><td class="minute">00</td><td class="minute">03</td><td class="minute">06</td><td class="minute">09</td></tr><tr><td class="minute">12</td><td class="minute">15</td><td class="minute">18</td><td class="minute">21</td></tr><tr><td class="minute">24</td><td class="minute">27</td><td class="minute">30</td><td class="minute">33</td></tr><tr><td class="minute">36</td><td class="minute">39</td><td class="minute">42</td><td class="minute">45</td></tr><tr><td class="minute">48</td><td class="minute">51</td><td class="minute">54</td><td class="minute">57</td></tr></tbody></table></div><div class="timepicker-seconds" data-action="selectSecond" style="display: none;"><table class="table-condensed"><tbody><tr><td class="second">00</td><td class="second">03</td><td class="second">06</td><td class="second">09</td></tr><tr><td class="second">12</td><td class="second">15</td><td class="second">18</td><td class="second">21</td></tr><tr><td class="second">24</td><td class="second">27</td><td class="second">30</td><td class="second">33</td></tr><tr><td class="second">36</td><td class="second">39</td><td class="second">42</td><td class="second">45</td></tr><tr><td class="second">48</td><td class="second">51</td><td class="second">54</td><td class="second">57</td></tr></tbody></table></div></div></div><div class="bootstrap-datetimepicker-widget dropdown-menu"><div class="timepicker"><div class="timepicker-picker"><table class="table-condensed" data-hour-format="12"><tbody><tr><td><a href="#" class="btn" data-action="incrementHours"><i class="fa fa-angle-up"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="incrementMinutes"><i class="fa fa-angle-up"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="incrementSeconds"><i class="fa fa-angle-up"></i></a></td><td class="separator"></td></tr><tr><td><span data-action="showHours" data-time-component="hours" class="timepicker-hour">01</span></td> <td class="separator">:</td><td><span data-action="showMinutes" data-time-component="minutes" class="timepicker-minute">34</span></td> <td class="separator">:</td><td><span data-action="showSeconds" data-time-component="seconds" class="timepicker-second">58</span></td><td class="separator"></td><td><button type="button" class="btn" data-action="togglePeriod">PM</button></td></tr><tr><td><a href="#" class="btn" data-action="decrementHours"><i class="fa fa-angle-down"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="decrementMinutes"><i class="fa fa-angle-down"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="decrementSeconds"><i class="fa fa-angle-down"></i></a></td><td class="separator"></td></tr></tbody></table></div><div class="timepicker-hours" data-action="selectHour" style="display: none;"><table class="table-condensed"><tbody><tr><td class="hour">01</td><td class="hour">02</td><td class="hour">03</td><td class="hour">04</td></tr><tr><td class="hour">05</td><td class="hour">06</td><td class="hour">07</td><td class="hour">08</td></tr><tr><td class="hour">09</td><td class="hour">10</td><td class="hour">11</td><td class="hour">12</td></tr></tbody></table></div><div class="timepicker-minutes" data-action="selectMinute" style="display: none;"><table class="table-condensed"><tbody><tr><td class="minute">00</td><td class="minute">03</td><td class="minute">06</td><td class="minute">09</td></tr><tr><td class="minute">12</td><td class="minute">15</td><td class="minute">18</td><td class="minute">21</td></tr><tr><td class="minute">24</td><td class="minute">27</td><td class="minute">30</td><td class="minute">33</td></tr><tr><td class="minute">36</td><td class="minute">39</td><td class="minute">42</td><td class="minute">45</td></tr><tr><td class="minute">48</td><td class="minute">51</td><td class="minute">54</td><td class="minute">57</td></tr></tbody></table></div><div class="timepicker-seconds" data-action="selectSecond" style="display: none;"><table class="table-condensed"><tbody><tr><td class="second">00</td><td class="second">03</td><td class="second">06</td><td class="second">09</td></tr><tr><td class="second">12</td><td class="second">15</td><td class="second">18</td><td class="second">21</td></tr><tr><td class="second">24</td><td class="second">27</td><td class="second">30</td><td class="second">33</td></tr><tr><td class="second">36</td><td class="second">39</td><td class="second">42</td><td class="second">45</td></tr><tr><td class="second">48</td><td class="second">51</td><td class="second">54</td><td class="second">57</td></tr></tbody></table></div></div></div><div class="bootstrap-datetimepicker-widget dropdown-menu"><div class="timepicker"><div class="timepicker-picker"><table class="table-condensed" data-hour-format="12"><tbody><tr><td><a href="#" class="btn" data-action="incrementHours"><i class="fa fa-angle-up"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="incrementMinutes"><i class="fa fa-angle-up"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="incrementSeconds"><i class="fa fa-angle-up"></i></a></td><td class="separator"></td></tr><tr><td><span data-action="showHours" data-time-component="hours" class="timepicker-hour">01</span></td> <td class="separator">:</td><td><span data-action="showMinutes" data-time-component="minutes" class="timepicker-minute">34</span></td> <td class="separator">:</td><td><span data-action="showSeconds" data-time-component="seconds" class="timepicker-second">58</span></td><td class="separator"></td><td><button type="button" class="btn" data-action="togglePeriod">PM</button></td></tr><tr><td><a href="#" class="btn" data-action="decrementHours"><i class="fa fa-angle-down"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="decrementMinutes"><i class="fa fa-angle-down"></i></a></td><td class="separator"></td><td><a href="#" class="btn" data-action="decrementSeconds"><i class="fa fa-angle-down"></i></a></td><td class="separator"></td></tr></tbody></table></div><div class="timepicker-hours" data-action="selectHour" style="display: none;"><table class="table-condensed"><tbody><tr><td class="hour">01</td><td class="hour">02</td><td class="hour">03</td><td class="hour">04</td></tr><tr><td class="hour">05</td><td class="hour">06</td><td class="hour">07</td><td class="hour">08</td></tr><tr><td class="hour">09</td><td class="hour">10</td><td class="hour">11</td><td class="hour">12</td></tr></tbody></table></div><div class="timepicker-minutes" data-action="selectMinute" style="display: none;"><table class="table-condensed"><tbody><tr><td class="minute">00</td><td class="minute">03</td><td class="minute">06</td><td class="minute">09</td></tr><tr><td class="minute">12</td><td class="minute">15</td><td class="minute">18</td><td class="minute">21</td></tr><tr><td class="minute">24</td><td class="minute">27</td><td class="minute">30</td><td class="minute">33</td></tr><tr><td class="minute">36</td><td class="minute">39</td><td class="minute">42</td><td class="minute">45</td></tr><tr><td class="minute">48</td><td class="minute">51</td><td class="minute">54</td><td class="minute">57</td></tr></tbody></table></div><div class="timepicker-seconds" data-action="selectSecond" style="display: none;"><table class="table-condensed"><tbody><tr><td class="second">00</td><td class="second">03</td><td class="second">06</td><td class="second">09</td></tr><tr><td class="second">12</td><td class="second">15</td><td class="second">18</td><td class="second">21</td></tr><tr><td class="second">24</td><td class="second">27</td><td class="second">30</td><td class="second">33</td></tr><tr><td class="second">36</td><td class="second">39</td><td class="second">42</td><td class="second">45</td></tr><tr><td class="second">48</td><td class="second">51</td><td class="second">54</td><td class="second">57</td></tr></tbody></table></div></div></div></body></html>