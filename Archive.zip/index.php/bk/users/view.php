<?php
$q = "queryfile/view.php";
include "dashboard.php"
?>