<?php
$q = "queryfile/creditdebitlist.php";
include "dashboard.php"
?>