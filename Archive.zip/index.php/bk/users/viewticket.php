<?php
require_once("../blood.php");
if(isset($_POST['reply']) && isset($_GET['id'])){
   $meck =  AdminTools::Tickets($_GET['id'],"reply",$_POST['reply'])[0];
   print ("<script>alert('$meck');</script>");
}

$q = "queryfile/viewticket.php";
include "dashboard.php"
?>