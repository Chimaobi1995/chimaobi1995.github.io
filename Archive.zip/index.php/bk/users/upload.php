<?php
$q = "queryfile/upload.php";
include "dashboard.php"
?>