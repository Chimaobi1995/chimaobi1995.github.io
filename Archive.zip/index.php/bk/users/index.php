<?php
$q = "queryfile/homepage.php";
include "dashboard.php";
?>