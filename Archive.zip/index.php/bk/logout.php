<?php
require_once("blood.php");
session_start();
session_destroy();
header("Location: ./");
//$k = new Manager;
//$k->logout();
?>