<?php
/*
print strtotime("now");
print "<br/>";
$x = strtotime("+2days");
print "$x <br/>";
print date("d",$x);
print "<br/>";
print base64_encode(rand("1","99999"));
print "<br/>";
print base64_decode("Njg5MTY=");
print "<br/>";
*/
// print_r($_SERVER);
// print $_SERVER['SERVER_NAME'];
$site = "localhost";
if(isset($_GET['site'])){
	$site = $_GET['site'];
if(!isset($_GET['expy'])){
	$expy = strtotime("+2days");
}else{
	$expy = $_GET['expy'];
	$expy = strtotime("+$expy days");
}
$eng =  "wu87a2398s".strrev($expy).$site."M3A33";
// print $eng;
// print "<br/>";
$LIC1 = base64_encode(base64_encode($eng));
// print $LIC1;
// PRINT "<br/>";
$LIC2 = $LIC1."=";
// print $LIC2."<BR/>";
$lic3 = substr(md5(rand(10000,99999)),0,6).$LIC2;
$lic3 = str_replace("=","*",$lic3);
$lic3 = strrev($lic3);
PRINT $lic3;
// print "<br/>".base64_decode($lic3);
// print "<hr/>".base64_decode(base64_decode("ZDNVNE4yRXlNems0Y3pJd01EWXdNekl6TlRGM1pXNHVjblZ6ZFdkaGNnPT0="));
}
?>