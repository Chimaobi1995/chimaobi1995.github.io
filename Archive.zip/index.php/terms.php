<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/terms. Date: Mon, 14 Sep 2020 23:39:06 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="content" description="<?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants">
<title><?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants</title>
<link rel="apple-touch-icon" sizes="57x57" href="../assets/landing/images/fav-icon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/landing/images/fav-icon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/landing/images/fav-icon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/landing/images/fav-icon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/landing/images/fav-icon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/landing/images/fav-icon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/landing/images/fav-icon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/landing/images/fav-icon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/landing/images/fav-icon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/../assets/landing/images/fav-iconandroid-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/landing/images/fav-icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/landing/images/fav-icon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/landing/images/fav-icon/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/landing/images/fav-icon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/bootstrap/bootstrap.css" media="screen">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Alegreya:400,400italic,700,900,700italic,900italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="../assets/landing/fonts/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/fonts/flat-icon/flaticon.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/settings.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/layers.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/navigation.css">

<link rel="stylesheet" href="../assets/landing/css/owl.carousel.css">
<link rel="stylesheet" href="../assets/landing/css/owl.theme.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/jquery-css/jquery-ui.css">


<link rel="stylesheet" type="text/css" href="../assets/landing/css/custom/style.css">

<link type="text/css" rel="stylesheet" id="jssDefault" href="../assets/landing/css/custom/theme-2.css" />

<link rel="stylesheet" type="text/css" href="../assets/landing/css/responsive/responsive.css">
<link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/font-awesome.css">
</head>
<body class="home layout_changer">
<!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

<div class="body_wrapper">

<div id="loader-wrapper">
<div id="loader"></div>
</div>


<?php include "topmenu.php"; ?>
<?php include "main_menu.php"; ?>

<section class="inner_banner">
<div class="container">
<div class="banner-title">
<h1>TERMS OF USE</h1>
<span class="decor-equal"></span>
</div>
</div>
</section>


<section class="breadcrumb_sec">
<div class="container">
<div class="row">
<div class="col-lg-8 col-md-6 col-sm-6 col-xs-3">
<h5>Terms</h5>
</div>
<div class="col-lg-4 col-md-6 col-sm-6 col-xs-9" style="text-align:right;">
<ul>
<li><a href="index">Home</a></li>
<li class="dot"></li>
<li>Terms</li>
</ul>
</div>
</div>
</div>
</section>


<div class="news_content_container">
<div class="container">
<div class="row">
<article class="col-lg-9 col-md-8 col-sm-12 col-xs-12 news_post">
<h1>Terms of Service (“Terms”)</h1>
<p>Last updated: June 20, 2018</p>
<p>Please read these Terms of Service (“Terms”, “Terms of Service”) carefully before using the <?php echo $title; ?> (the “Service”) operated by <?php echo $title; ?> financial Solution (“us”, “we”, or “our”).</p>
<p>Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users and others who access or use the Service.</p>
<p>By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you may not access the Service. This Terms of Service agreement for <?php echo $title; ?> financial Solution based on the Terms and Conditions</a>.</p>
<h2>Accounts</h2>
<p>When you create an account with us, you must provide us information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service.</p>
<p>You are responsible for safeguarding the password that you use to access the Service and for any activities or actions under your password, whether your password is with our Service or a third-party service.</p>
<p>You agree not to disclose your password to any third party. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.</p>
<h2>Links To Other Web Sites</h2>
<p>Our Service may contain links to third-party web sites or services that are not owned or controlled by <?php echo $title; ?> financial Solution.</p>
<p><?php echo $title; ?> financial Solution has no control over, and assumes no responsibility for, the content, privacy policies, or practices of any third party web sites or services. You further acknowledge and agree that <?php echo $title; ?> financial Solution shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or services available on or through any such web sites or services.</p>
<p>We strongly advise you to read the terms and conditions and privacy policies of any third-party web sites or services that you visit.</p>
<h2>Termination</h2>
<p>We may terminate or suspend access to our Service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
<p>All provisions of the Terms which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability.</p>
<p>We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>
<p>Upon termination, your right to use the Service will immediately cease. If you wish to terminate your account, you may simply discontinue using the Service.</p>
<p>All provisions of the Terms which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity and limitations of liability.</p>
<h2>Governing Law</h2>
<p>These Terms shall be governed and construed in accordance with the laws of United Kingdom, without regard to its conflict of law provisions.</p>
<p>Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect. These Terms constitute the entire agreement between us regarding our Service, and supersede and replace any prior agreements we might have between us regarding the Service.</p>
<h2>Changes</h2>
<p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.</p>
<p>By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, please stop using the Service.</p>
<h2>Contact Us</h2>
<p>If you have any questions about these Terms, please <a href="contact">contact us.</a></p>
</article> 

<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 blog_aside">
<div class="news_categories">
<div class="title_container">
<h4>Quick Links</h4>
<span class="decor_default"></span>
</div>
<ul>
<li><a href="investment_planning"><i class="fa fa-angle-right"></i>Investment Planning</a></li>
<li><a href="wealth_management"><i class="fa fa-angle-right"></i>Wealth Management</a></li>
<li><a href="commodities_trading"><i class="fa fa-angle-right"></i>Commodities</a></li>
<li><a href="mutual_funds"><i class="fa fa-angle-right"></i>Mutual Funds</a></li>
<li><a href="auth/"><i class="fa fa-angle-right"></i>Private Banking</a></li>
</ul>
</div> 
</div> 
</div> 
</div> 
</div>


<?php include "footer.php"; ?>

<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="../assets/landing/js/jquery-2.1.4.js"></script>
<script src="../assets/landing/ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript" src="../assets/landing/js/bootstrap.min.js"></script>


<script type="text/javascript" src="../assets/landing/js/jQuery.style.switcher.min.js"></script>

<script src="../assets/landing/js/jquery.themepunch.tools.min.js"></script>
<script src="../assets/landing/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.navigation.min.js"></script>

<script src="../assets/landing/js/owl.carousel.min.js"></script>

<script src="../assets/landing/js/jquery.appear.js"></script>

<script type="text/javascript" src="../assets/landing/js/jquery-ui.min.js"></script>

<script src="../assets/landing/js/jquery.countTo.js"></script>
<script src="../assets/landing/js/validate.js"></script>
<script type="text/javascript" src="../assets/landing/js/main.js"></script>
</div> 
</body>

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/terms. Date: Mon, 14 Sep 2020 23:39:07 GMT -->
</html>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5de1747543b1d1fce83/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
