<div class="main_menu">
<div class="container">
<div class="row">
<nav class="navbar navbar-default col-lg-11 col-md-11 col-sm-11 col-xs-12">

<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="false">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>

<div class="collapse navbar-collapse" id="navbar-collapse-1">
<ul class="nav navbar-nav">
<li><a href="index">Home</a><span>Welcome to EFS</span></li>
<li><a href="about_us">About Us</a><span>Know More About Us</span></li>
<li class="dropdown_menu"><a href="services">Services <i class="fa fa-sort-desc"></i></a><span>Valuable Services</span>
<ul class="sub-menu">
<li><a href="investment_planning">Investment Planning</a></li>
<li><a href="childrens_planning">Childrens Planning</a></li>
<li><a href="retirement_planning">Retirement Planning</a></li>
<li><a href="insurance_planning">Insurance Planning</a></li>
<li><a href="tax_planning">Tax Planning</a></li>
<li><a href="commodities_trading">Commodities Trading</a></li>
<li><a href="mutual_funds">Mutual Funds</a></li>
<li><a href="wealth_management">Wealth Management</a></li>
</ul>
</li>
<!--li class="dro"><a href="wealth_management">Wealth Mgt. </a><span>Wealth Management</span-->
<li><a href="retirement_planning">Mortgages</a><span> Our Mortgage Options</span></li>
<li><a href="contact">Contact</a><span>Get Touch With Us</span></li>
<li class=""><a href="en_us/" target="_self">Online Banking</a><span>Online Banking</span>
</li>
<li><a href="apply">Apply Now</a><span>Open an Account</span></li>

</ul>
</div>
</nav> 

</div>
</div>
</div>