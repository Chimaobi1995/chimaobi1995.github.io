<?php
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/about_us. Date: Mon, 14 Sep 2020 23:37:16 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="content" description="<?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants">
<title><?php echo $title; ?> financial Solution || Commercial || Personal Banking || Financial Consultants</title>

<link rel="apple-touch-icon" sizes="57x57" href="../assets/landing/images/fav-icon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/landing/images/fav-icon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/landing/images/fav-icon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/landing/images/fav-icon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/landing/images/fav-icon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/landing/images/fav-icon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/landing/images/fav-icon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/landing/images/fav-icon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/landing/images/fav-icon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/../assets/landing/images/fav-iconandroid-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/landing/images/fav-icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/landing/images/fav-icon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/landing/images/fav-icon/favicon-16x16.png">
<link rel="manifest" href="/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/landing/images/fav-icon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/bootstrap/bootstrap.css" media="screen">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Alegreya:400,400italic,700,900,700italic,900italic' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="../assets/landing/fonts/font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/fonts/flat-icon/flaticon.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/settings.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/layers.css">
<link rel="stylesheet" type="text/css" href="../assets/landing/css/navigation.css">

<link rel="stylesheet" href="../assets/landing/css/owl.carousel.css">
<link rel="stylesheet" href="../assets/landing/css/owl.theme.css">

<link rel="stylesheet" type="text/css" href="../assets/landing/css/jquery-css/jquery-ui.css">


<link rel="stylesheet" type="text/css" href="../assets/landing/css/custom/style.css">

<link type="text/css" rel="stylesheet" id="jssDefault" href="../assets/landing/css/custom/theme-2.css" />

<link rel="stylesheet" type="text/css" href="../assets/landing/css/responsive/responsive.css">
<link rel="stylesheet" type="text/css" href="../assets/font-awesome/css/font-awesome.css">
</head>
<body class="home layout_changer">
<!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

<div class="body_wrapper">

<div id="loader-wrapper">
<div id="loader"></div>
</div>

<?php include "topmenu.php"; ?>
<?php include "main_menu.php"; ?>

<section class="inner_banner">
<div class="container">
<div class="banner-title">
<h1>Who We Are</h1>
<span class="decor-equal"></span>
</div>
</div>
</section>


<section class="breadcrumb_sec">
<div class="container">
<div class="row">
<div class="col-lg-10 col-md-6 col-sm-6 col-xs-5">
<h5>About Us</h5>
</div>
<div class="col-lg-2 col-md-6 col-sm-6 col-xs-7">
<ul>
<li><a href="index">Home</a></li>
<li class="dot"></li>
<li>About us</li>
</ul>
</div>
</div>
</div>
</section>


<section class="our_mission">
<div class="container">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 mission_value pull-right">
<div class="title_container">
<h4>Our Mission & Values</h4>
<span class="decor_default"></span>
</div>
<div>
<div id="carousel-example-vertical" class="carousel vertical slide">
<div class="carousel-inner" role="listbox">
<div class="item active">
<div class="ticker-headline">
<p><?php echo $title; ?> financial Solution is the trading name of North Edinburgh and Castle Credit Union Ltd. Registered office: Blue Navy Con St,San Diego California. Registered under the Credit Unions Act 1979, number 019CUS.</p>
<p>Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority under registration number 213845.
We are covered by the Financial Services Compensation Scheme and Financial Ombudsman Service.
<?php echo $title; ?> financial Solution is committed to responsible lending..</p>
<h5>We Are <?php echo $title; ?> financial Solution, Why We Are Here? To help you Save Time,
<br> Save Money , Grow & Succeed</h5>
<ul>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Longtime Care</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Best Plans</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Customer Satisfaction</a></li>
</ul>
<ul>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Make Difference</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Referesh The World</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Financially Wealthy</a></li>
</ul>
</div>
</div> 
<div class="item">
<div class="ticker-headline">
<p>We are Committed to economical development leading to personal and individual Growth. We aim to provide the best of services (quality services) to all that has business with us. We are a reputable company looking forward to help you grow not just financially but in all areas that will move you forward.
We look forward to having you join us.</p>
<h5>We Are FinancePress, Why We Are Here? For Save Time,<br> Save Money , Grow & Succeed</h5>
<ul>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Longtime Care</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Best Plans</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Customer Satisfaction</a></li>
</ul>
<ul>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Make Difference</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Referesh The World</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Financially Wealthy</a></li>
</ul>
</div>
</div> 
<div class="item">
<div class="ticker-headline">
<p><?php echo $title; ?> financial Solution is the trading name of North Edinburgh and Castle Credit Union Ltd. Registered office: Blue Navy Con St,San Diego California. Registered under the Credit Unions Act 1979, number 019CUS.</p>
<p>Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority under registration number 213845.
We are covered by the Financial Services Compensation Scheme and Financial Ombudsman Service.
<?php echo $title; ?> financial Solution is committed to responsible lending..</p>
<h5>We Are <?php echo $title; ?> financial Solution, Why We Are Here? To help you Save Time,
<br> Save Money , Grow & Succeed</h5>
<ul>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Longtime Care</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Best Plans</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Customer Satisfaction</a></li>
</ul>
<ul>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Make Difference</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Referesh The World</a></li>
<li><i class="fa fa-angle-right"></i> <a href="about_us.html#">Financially Wealthy</a></li>
</ul>
</div>
</div> 
</div> 

<a class="up carousel-control" href="about_us.html#carousel-example-vertical" role="button" data-slide="prev">
<i class="fa fa-angle-up" aria-hidden="true"></i>
<i class="sr-only">Previous</i>
</a>
<a class="down carousel-control" href="about_us.html#carousel-example-vertical" role="button" data-slide="next">
<i class="fa fa-angle-down" aria-hidden="true"></i>
<i class="sr-only">Next</i>
</a>

<ol class="carousel-indicators">
<li data-target="#carousel-example-vertical" data-slide-to="0" class="active">
<span>Mission & Values <img src="../assets/landing/images/about/pop-bg.png" alt=""></span>
</li>
<li data-target="#carousel-example-vertical" data-slide-to="1">
<span>Mission & Values <img src="../assets/landing/images/about/pop-bg.png" alt=""></span>
</li>
<li data-target="#carousel-example-vertical" data-slide-to="2">
<span>Mission & Values <img src="../assets/landing/images/about/pop-bg.png" alt=""></span>
</li>
</ol>
</div>
</div>
</div>
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 mission_gallery pull-left"> 
<img class="img-responsive" src="../assets/landing/images/about/1.jpg" alt="images">
<img class="img-responsive" src="../assets/landing/images/about/2.jpg" alt="images">
<img class="img-responsive" src="../assets/landing/images/about/3.jpg" alt="images">
<img class="img-responsive" src="../assets/landing/images/about/4.jpg" alt="images">
<img class="img-responsive" src="../assets/landing/images/about/5.jpg" alt="images">
</div> 
</div>
</div>
</section>


<section class="container">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 customer-say">
<div class="title_container">
<h4>What Our Customer Say</h4>
<span class="decor_default"></span>
</div>
<div class="slider_container">
<div id="customer-say-slider" class="carousel slide" data-ride="carousel">

<ol class="carousel-indicators">
<li data-target="#customer-say-slider" data-slide-to="0" class="active"></li>
<li data-target="#customer-say-slider" data-slide-to="1"></li>
<li data-target="#customer-say-slider" data-slide-to="2"></li>
</ol>

<div class="carousel-inner inner_slider_container" role="listbox">
<div class="item active">
<span class="icon flaticon-quotes3"></span>
<p class="speach"><?php echo $title; ?> financial Solution got me out of a debt-trap. They helped me pay off expensive short term debts and credit cards and understand how to borrow responsibly</p>
<div class="client_name">
<h6>Marry Christiona</h6>
<span>Marketing Manager @ VK Ltd.</span>
</div>
</div>
<div class="item">
<span class="icon flaticon-quotes3"></span>
<p class="speach">Online banking has never been so effortlessly seamless. It’s as easy as tapping and sending.</p>
<div class="client_name">
<h6>Henry Jaden</h6>
<span>Investment Expert</span>
</div>
</div>
<div class="item">
<span class="icon flaticon-quotes3"></span>
<p class="speach">They provide expert services and has a rich set of very experienced financial advisors.</p>
<div class="client_name">
<h6>Tom Phils</h6>
<span>Trader.</span>
</div>
</div>
</div> 
</div> 
</div> 
</div> 
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 growth_statistics">
<div class="title_container">
<h4>Look at Our Growth Statistics</h4>
<span class="decor_default"></span>
</div>
<div class="graph">
<ul>
<li>Funding</li>
<li>Capitalization</li>
<li>Income</li>
</ul>
<img class="img-responsive" src="../assets/landing/images/about/graph.png" alt="images">
</div>
</div> 
</div> 
</section> 


<section class="experts_services">
<div class="container">
<div class="row">
<div class="title_container" style="text-align:center;">
<h4>Experts Services That You Need</h4>
<span class="decor-equal"></span>
</div>
</div> 
<div class="row">
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 experts_planning">
<h3><span class="icon flaticon-statistics"></span>Investment Planning</h3>
<ul>
<li><a href="about_us.html#">Involves identifying your financial goals throughout your life.</a></li>
<li><a href="about_us.html#">Investment Planning includes buying a house, car, etc...</a></li>
<li><a href="about_us.html#">We help you to decide upon the right investment strategy.</a></li>
<li><a href="about_us.html#">Which suits your particular needs and requirements.</a></li>
</ul>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 experts_planning">
<h3><span class="icon flaticon-money33"></span>Children Planning</h3>
<ul>
<li><a href="about_us.html#">Successful and responsible individual is a dream of every parent</a></li>
<li><a href="about_us.html#">Many parents face lot of hardships to save money their child’s dream.</a></li>
<li><a href="about_us.html#">Involves identifying your financial goals throughout your life.</a></li>
<li><a href="about_us.html#">Investment Planning includes buying a Studies,and Carrier.</a></li>
</ul>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 experts_planning">
<h3><span class="icon flaticon-museum34"></span>Retirement Planning</h3>
<ul>
<li><a href="about_us.html#">We help you to decide upon the right investment strategy.</a></li>
<li><a href="about_us.html#">Which suits your particular needs and requirements.</a></li>
<li><a href="about_us.html#">Successful and responsible individual is a dream of every parent</a></li>
<li><a href="about_us.html#">Many parents face lot of hardships to save money their child’s dream.</a></li>
</ul>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-xs-12 experts_planning">
<h3><span class="icon flaticon-money183"></span>Insurance Planning</h3>
<ul>
<li><a href="about_us.html#">Many parents face lot of hardships to save money their child’s dream.</a></li>
<li><a href="about_us.html#">Investment Planning includes buying a Studies,and Carrier.</a></li>
<li><a href="about_us.html#">Involves identifying your financial goals throughout your life.</a></li>
<li><a href="about_us.html#">Which suits your particular needs and requirements.</a></li>
</ul>
</div>
</div> 
<div class="row" style="text-align:center;">
<a href="services" class="button-main hvr-sweep-to-rightB view_services">View All Services</a>
</div>
</div> 
</section> 

<?php include "footer.php"; ?>


<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="../assets/landing/js/jquery-2.1.4.js"></script>
<script src="../assets/landing/ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript" src="../assets/landing/js/bootstrap.min.js"></script>


<script type="text/javascript" src="../assets/landing/js/jQuery.style.switcher.min.js"></script>

<script src="../assets/landing/js/jquery.themepunch.tools.min.js"></script>
<script src="../assets/landing/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="../assets/landing/js/revolution.extension.navigation.min.js"></script>

<script src="../assets/landing/js/owl.carousel.min.js"></script>

<script src="../assets/landing/js/jquery.appear.js"></script>

<script type="text/javascript" src="../assets/landing/js/jquery-ui.min.js"></script>

<script src="../assets/landing/js/jquery.countTo.js"></script>
<script src="../assets/landing/js/validate.js"></script>
<script type="text/javascript" src="../assets/landing/js/main.js"></script>
</div> 
</body>

<!-- Mirrored by: HTTrack Website Copier/3.x. Site: citifinancettust.com. File: /index.php/home/about_us. Date: Mon, 14 Sep 2020 23:37:27 GMT -->
</html>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5de1747543b1d1fce83/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
